#!/bin/sh
#set -x   # uncomment for a trace

# this script is run after to BitBar is installed

OTHER_BITBAR_INSTALL_EXISTS='false'

# if a BitBar preference exists (so, presumably, BitBar is already installed),
# determine the current plugins folder
if test -f "/Users/${USER}/Library/Preferences/com.matryer.BitBar.plist"
then
	# here we're relying upon the installer to set $USER to the real User, not to
	# the su'd User
	PLUGINS_FOLDER=`/usr/bin/sudo -u "$USER" \
							/usr/bin/defaults read com.matryer.BitBar pluginsDirectory`

	# if a plugins folder exists and is different from the plugins folder we just
	# installed, (also)install the Fan Control plugin there
	if test "$PLUGINS_FOLDER" != '' -a \
			  "$PLUGINS_FOLDER" != '/Applications/BitBar/PlugIns'
	then
		rm -f "${PLUGINS_FOLDER}/FanControlBitBarPlugin.5s.sh"
		/bin/ln -s \
			'/Library/PreferencePanes/FanControl.prefPane/Contents/Resources/FanControlBitBarPlugin.5s.sh' \
																					"$PLUGINS_FOLDER"
		OTHER_BITBAR_INSTALL_EXISTS='true'
	fi
fi

# if required, set BitBar's plugins directory to the "just installed" BitBar
if test "$OTHER_BITBAR_INSTALL_EXISTS" = 'false'
then
	# you would think the following would work ... but it doesn't <grrrr>
	#/usr/bin/sudo -u "$USER" /usr/bin/defaults write com.matryer.BitBar \
	#										pluginsDirectory '/Applications/BitBar/PlugIns'

	# OK, so just copy a default file ...
	/bin/cp 'com.matryer.BitBar.plist' "/Users/${USER}/Library/Preferences"
	chmod 640 "/Users/${USER}/Library/Preferences/com.matryer.BitBar.plist"
	chown "$USER" "/Users/${USER}/Library/Preferences/com.matryer.BitBar.plist"

	# run the "just installed" BitBar application
	/usr/bin/open '/Applications/BitBar/BitBar.app'
fi

echo 'Completed the BitBar install'

exit 0
