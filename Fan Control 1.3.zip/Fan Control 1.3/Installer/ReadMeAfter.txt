Fan Control is installed as a preference pane and, optionally, BitBar is installed in the Applications folder.

Open the Fan Control preference pane (in System Preferences) to adjust your Fan Control settings.


IF YOU INSTALLED (or already use) BitBar ...

... in your menu bar, click on the BitBar entry for Fan Control (the one with the ♨ [hot air rising] symbol beside it) and configure to suit your needs.

If you already had BitBar installed, FanControl's plugin file was installed in your existing BitBar's plugin folder and, if BitBar was not located in the Applications folder, then you should trash the newly installed (and unused) BitBar folder in the Applications folder.  You may also need to (re)launch BitBar and/or select BitBar's "Preferences -> Refresh all" menu to activate the Fan Control plugin.

Note that the BitBar application folder (/Applications/BitBar) can be moved to any location you prefer (after which, it'll ask you for the new plugin-folder location ... which, by default, is the PlugIns folder inside the BitBar application folder).
