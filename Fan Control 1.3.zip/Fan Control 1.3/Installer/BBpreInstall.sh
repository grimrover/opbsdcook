#!/bin/sh
#set -x   # uncomment for a trace

# this script is run before BitBar is installed

echo 'Starting BitBar install'

exit 0
