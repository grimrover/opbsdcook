#!/bin/sh
#set -x   # uncomment for a trace

# this script will remove Fan Control

echo 'Starting Fan Control uninstall'

# ensure that no System Preferences panel is open
if test "`/bin/ps -ax | /usr/bin/fgrep \"System Preferences\" | \
															/usr/bin/sed -e '/fgrep/d'`" != ''
then
	echo 'Closing System Preferences'
	R=`/usr/bin/killall 'System Preferences' 2>&1`
fi

# ensure that the Fan Control daemon is not running
if test -f '/Library/LaunchDaemons/com.derman.FanControlDaemon.plist' -o \
		  "`/bin/ps -ax | /usr/bin/fgrep \"FanControlDaemon\" | \
															/usr/bin/sed -e '/fgrep/d'`" != ''
then
	echo 'Stopping the Fan Control daemon'
	R=`/bin/launchctl unload \
						/Library/LaunchDaemons/com.derman.FanControlDaemon.plist 2>&1`
	R=`/usr/bin/killall FanControlDaemon 2>&1`
fi

sleep 1

# remove the Fan Control preference pane
if test -d '/Library/PreferencePanes/FanControl.prefPane'
then
	echo 'Removing existing Fan Control preference pane'
	/bin/rm -rf '/Library/PreferencePanes/FanControl.prefPane'
fi

# remove the Fan Control launch-daemon file
if test -f '/Library/LaunchDaemons/com.derman.FanControlDaemon.plist'
then
	echo 'Removing the Fan Control launch-daemon file'
	/bin/rm -f '/Library/LaunchDaemons/com.derman.FanControlDaemon.plist'
fi

echo 'Fan Control has been removed'
