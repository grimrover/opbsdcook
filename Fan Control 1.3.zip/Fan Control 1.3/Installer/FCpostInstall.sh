#!/bin/sh
#set -x   # uncomment for a trace


# this script is run after to Fan Control is installed

echo 'Starting the Fan Control daemon'
/bin/launchctl load '/Library/LaunchDaemons/com.derman.FanControlDaemon.plist'

echo 'Completed the Fan Control install'

exit 0
