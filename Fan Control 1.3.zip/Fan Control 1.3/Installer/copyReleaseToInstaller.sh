#!/bin/sh
#set -x   # uncomment for a trace

SIG_NAME=''
HERE=`/usr/bin/dirname "$0"`
ME=`/usr/bin/basename "$0"`
SRC_DIR="$HERE/../Fan Control Source Code"
REL_DIR="$HERE/../Fan Control Source Code/build/Release"
BEL='\007'

# before copying and if it's not already signed, sign the smc utility (easier to
# do it here than in the Makefile)
if test "$SIG_NAME" != ''
then
	if test "`/usr/bin/codesign --verify \"$REL_DIR/smc\" 2>&1 | \
											/usr/bin/fgrep 'is not signed at all'`" != ''
	then
		echo
		echo 'Signing the smc utility/executable ...'
		R=`/usr/bin/codesign -s "$SIG_NAME" "$REL_DIR/smc" 2>&1`

		if test "$R" != ''
		then
			echo "   $R"
		fi

		echo
	fi
fi

# copy the preference pane and copy "stuff" into its Resources directory
echo
echo 'Copying preference pane to installer directory ... '
/bin/rm -rf "$HERE/FanControl.prefPane"
/bin/cp -Rp "$REL_DIR/FanControl.prefPane" "$HERE"

echo
echo 'Copying additional files into the preference pane Resources directory ... '
/bin/cp -p "$HERE/FanControlBitBarPlugin.5s.sh" "$REL_DIR/getFanControlInfo" \
							  "$HERE/setBitBarPref.sh" "$HERE/uninstallFanControl.sh" \
												"$REL_DIR/FanControlDaemon" "$REL_DIR/smc" \
											"$HERE/FanControl.prefPane/Contents/Resources"
echo
echo 'Copies completed'
echo

# sign the scripts that were copied into the preference pane then re-sign the
# preference pane, itslef, since it's been modified
if test "$SIG_NAME" = ''
then
	echo "NOTE: The SIG_NAME variable in $ME is not set, so ..."
	echo '      the smc utility was not signed'
	echo '      the BitBar plugin (FanControlBitBarPlugin.5s.sh) was not signed'
	echo '      the BitBar prefs-setter script (setBitBarPref.sh) was not signed'
	echo '      the Fan Control uninstaller script (uninstallFanControl.sh) was not signed'
	echo '      the preference pane was not (re)signed'"$BEL"
else
	echo 'Signing BitBar and uninstaller shell scripts ...'
	R=`/usr/bin/codesign -s "$SIG_NAME" \
		"$HERE/FanControl.prefPane/Contents/Resources/FanControlBitBarPlugin.5s.sh" \
					"$HERE/FanControl.prefPane/Contents/Resources/setBitBarPref.sh" \
			"$HERE/FanControl.prefPane/Contents/Resources/uninstallFanControl.sh" \
																									2>&1`

	if test "$R" != ''
	then
		echo "$R" | /usr/bin/sed -e 's/.*: //' -e 's/^/   /'
	fi

	echo
	echo 'Re-Signing modified FanControl.prefPane bundle ...'
	R=`/usr/bin/codesign -f -s "$SIG_NAME" "$HERE/FanControl.prefPane" 2>&1`

	if test "$R" != ''
	then
		echo "   $R" | /usr/bin/sed -e 's/.*: //' -e 's/replacing/Replaced/'
	fi

	echo
	echo 'Signings completed'
fi
