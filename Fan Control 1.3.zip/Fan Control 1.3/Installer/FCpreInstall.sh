#!/bin/sh
#set -x   # uncomment for a trace

# this script is run before Fan Control is installed

echo 'Starting Fan Control install'

# ensure that no System Preferences panel is open
if test "`/bin/ps -ax | /usr/bin/fgrep \"System Preferences\" | \
															/usr/bin/sed -e '/fgrep/d'`" != ''
then
	echo 'Closing System Preferences'
	R=`/usr/bin/killall 'System Preferences' 2>&1`
fi

# ensure that an existing Fan Control daemon is not running
if test -f '/Library/LaunchDaemons/com.derman.FanControlDaemon.plist' -o \
		  "`/bin/ps -ax | /usr/bin/fgrep \"FanControlDaemon\" | \
															/usr/bin/sed -e '/fgrep/d'`" != ''
then
	echo 'Stopping the Fan Control daemon'
	R=`/bin/launchctl unload \
						/Library/LaunchDaemons/com.derman.FanControlDaemon.plist 2>&1`
	R=`/usr/bin/killall FanControlDaemon 2>&1`
fi

sleep 1

# remove any pre v1.3 Fan Control startup items
if test -d '/Library/StartupItems/FanControlDaemon'
then
	echo 'Removing obsolete Fan Control startup item'
	/bin/rm -rf '/Library/StartupItems/FanControlDaemon'
fi

# remove any existing Fan Control preference pane
if test -d '/Library/PreferencePanes/FanControl.prefPane'
then
	echo 'Removing existing Fan Control preference pane'
	/bin/rm -rf '/Library/PreferencePanes/FanControl.prefPane'
fi

# remove any existing Fan Control launch-daemon file
if test -f '/Library/LaunchDaemons/com.derman.FanControlDaemon.plist'
then
	echo 'Removing old Fan Control launch-daemon file'
	/bin/rm -f '/Library/LaunchDaemons/com.derman.FanControlDaemon.plist'
fi

exit 0
