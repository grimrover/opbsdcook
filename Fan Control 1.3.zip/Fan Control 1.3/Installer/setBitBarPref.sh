#!/bin/sh
#set -x   ## uncomment for a trace

# this script is used by the Fan Control plug-in for BitBar

BIT_BAR_PREFS_FILE=~/Library/Preferences/com.derman.FanControl.BitBar.txt

# set BitBar preferences -- done by pairs of parameters where, in each pair:
# - the first parameter indicates the item to be set
# - the second parameter supplies the setting as true or false

if test ! -f $BIT_BAR_PREFS_FILE
then
	/usr/bin/touch $BIT_BAR_PREFS_FILE
fi

while (test $# -gt 1)
do
	if test "$1" = 'cpu'  # set showCPUtempInMenuBar preference
	then
		if test "`fgrep 'showCPUtempInMenuBar=' $BIT_BAR_PREFS_FILE`" = ''
		then
			echo "showCPUtempInMenuBar=$2" >> $BIT_BAR_PREFS_FILE
		else
			/usr/bin/sed -i '.buf' \
					-e 's/^showCPUtempInMenuBar=.*$/showCPUtempInMenuBar='"$2"'/' \
																				$BIT_BAR_PREFS_FILE
		fi
	fi

	if test "$1" = 'gpu'  # set showGPUtempInMenuBar preference
	then
		if test "`fgrep 'showGPUtempInMenuBar=' $BIT_BAR_PREFS_FILE`" = ''
		then
			echo "showGPUtempInMenuBar=$2" >> $BIT_BAR_PREFS_FILE
		else
			/usr/bin/sed -i '.buf' \
					-e 's/^showGPUtempInMenuBar=.*$/showGPUtempInMenuBar='"$2"'/' \
																				$BIT_BAR_PREFS_FILE
		fi
	fi

	if test "$1" = 'degF'  # set showTempsAsDegFinBitBar to true
	then
		if test "`fgrep 'showTempsAsDegFinBitBar=' $BIT_BAR_PREFS_FILE`" = ''
		then
			echo "showTempsAsDegFinBitBar=$2" >> $BIT_BAR_PREFS_FILE
		else
			/usr/bin/sed -i '.buf' \
			  -e 's/^showTempsAsDegFinBitBar=.*$/showTempsAsDegFinBitBar='"$2"'/' \
																				$BIT_BAR_PREFS_FILE
		fi
	fi

	if test "$1" = 'fname'  # set showFanNamesInMenuBar preference
	then
		if test "`fgrep 'showFanNamesInMenuBar=' $BIT_BAR_PREFS_FILE`" = ''
		then
			echo "showFanNamesInMenuBar=$2" >> $BIT_BAR_PREFS_FILE
		else
			/usr/bin/sed -i '.buf' \
					-e 's/^showFanNamesInMenuBar=.*$/showFanNamesInMenuBar='"$2"'/' \
																				$BIT_BAR_PREFS_FILE
		fi
	fi

	if test "$1" = 'fspeed'  # set showFanSpeedsInMenuBar preference
	then
		if test "`fgrep 'showFanSpeedsInMenuBar=' $BIT_BAR_PREFS_FILE`" = ''
		then
			echo "showFanSpeedsInMenuBar=$2" >> $BIT_BAR_PREFS_FILE
		else
			/usr/bin/sed -i '.buf' \
				-e 's/^showFanSpeedsInMenuBar=.*$/showFanSpeedsInMenuBar='"$2"'/' \
																				$BIT_BAR_PREFS_FILE
		fi
	fi

	if test "$1" = 'fpercent'  # set showFanPercentsInMenuBar preference
	then
		if test "`fgrep 'showFanPercentsInMenuBar=' $BIT_BAR_PREFS_FILE`" = ''
		then
			echo "showFanPercentsInMenuBar=$2" >> $BIT_BAR_PREFS_FILE
		else
			/usr/bin/sed -i '.buf' \
			 -e 's/^showFanPercentsInMenuBar=.*$/showFanPercentsInMenuBar='"$2"'/'\
																				$BIT_BAR_PREFS_FILE
		fi
	fi

	if test "$1" = 'tname'  # set showTempNamesInMenuBar preference
	then
		if test "`fgrep 'showTempNamesInMenuBar=' $BIT_BAR_PREFS_FILE`" = ''
		then
			echo "showTempNamesInMenuBar=$2" >> $BIT_BAR_PREFS_FILE
		else
			/usr/bin/sed -i '.buf' \
				-e 's/^showTempNamesInMenuBar=.*$/showTempNamesInMenuBar='"$2"'/' \
																				$BIT_BAR_PREFS_FILE
		fi
	fi

	if test "$1" = 'temps'  # set showTempsInMenuBar preference
	then
		if test "`fgrep 'showTempsInMenuBar=' $BIT_BAR_PREFS_FILE`" = ''
		then
			echo "showTempsInMenuBar=$2" >> $BIT_BAR_PREFS_FILE
		else
			/usr/bin/sed -i '.buf' \
							-e 's/^showTempsInMenuBar=.*$/showTempsInMenuBar='"$2"'/' \
																				$BIT_BAR_PREFS_FILE
		fi
	fi

	if test "$1" = 'fans'  # set showFansInMenuBar preference
	then
		if test "`fgrep 'showFansInMenuBar=' $BIT_BAR_PREFS_FILE`" = ''
		then
			echo "showFansInMenuBar=$2" >> $BIT_BAR_PREFS_FILE
		else
			/usr/bin/sed -i '.buf' \
							-e 's/^showFansInMenuBar=.*$/showFansInMenuBar='"$2"'/' \
																				$BIT_BAR_PREFS_FILE
		fi
	fi

	shift 2
done

/bin/rm -f "${BIT_BAR_PREFS_FILE}.buf"
