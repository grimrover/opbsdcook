#!/bin/sh
#set -x   # uncomment for a trace

CWD=`/bin/pwd`
HERE=`/usr/bin/dirname "$0"`
ME=`/usr/bin/basename "$0"`
PREF_PANE_RSRCS="$HERE/FanControl.prefPane/Contents/Resources"
BEL='\007'

echo

if test "$USER" != "root"
then
	echo "ERROR: the script '$ME' must be run with root privileges$BEL"
	exit 1
fi

cd "$HERE"

if test ! -d "$HERE/FanControl.prefPane" -o \
		  ! -e "$PREF_PANE_RSRCS/FanControlBitBarPlugin.5s.sh" -o \
		  ! -e "$PREF_PANE_RSRCS/FanControlDaemon" -o \
		  ! -e "$PREF_PANE_RSRCS/getFanControlInfo" -o \
		  ! -e "$PREF_PANE_RSRCS/setBitBarPref.sh" -o \
		  ! -e "$PREF_PANE_RSRCS/uninstallFanControl.sh"
then
   echo "The FanControl.prefPane does not appear to be built correctly$BEL"
	cd "$CWD"
   exit 1
fi

echo 'Installing FanControl on this system ... '
echo

echo 'Closing System Preferences and stopping FanControlDaemon ... '
R=`/usr/bin/killall 'System Preferences' 2>&1`
R=`/bin/launchctl unload /Library/LaunchDaemons/com.derman.FanControlDaemon.plist 2>&1`
R=`/usr/bin/killall FanControlDaemon 2>&1`
sleep 1

echo
echo 'Removing any existing Fan Control preference pane ... '
/bin/rm -rf '/Library/PreferencePanes/FanControl.prefPane'

echo
echo 'Installing Fan Control preference pane ... '
/bin/cp -R 'FanControl.prefPane' '/Library/PreferencePanes'
/usr/sbin/chown -R root:wheel '/Library/PreferencePanes/FanControl.prefPane'

echo
echo 'Installing the launch-control plist for the FanControlDaemon ... '
/bin/cp 'com.derman.FanControlDaemon.plist' '/Library/LaunchDaemons/'
/usr/sbin/chown root:wheel  \
							'/Library/LaunchDaemons/com.derman.FanControlDaemon.plist'
/bin/chmod 644 '/Library/LaunchDaemons/com.derman.FanControlDaemon.plist'

echo
echo 'Install completed'
echo

echo
echo 'Starting FanControlDaemon ... '
/bin/launchctl load '/Library/LaunchDaemons/com.derman.FanControlDaemon.plist'

echo
echo 'Installed:'
/bin/ls -l '/Library/LaunchDaemons/com.derman.FanControlDaemon.plist'
/bin/ls -ld '/Library/PreferencePanes/FanControl.prefPane'

cd "$CWD"
