-----------
Xcode Stuff
-----------

If you're an Apple developer:
- put your developer certificate name into the SIG_NAME variable in the script
  copyReleaseToInstaller.sh (in the Installer directory)
- setup your developer certificate in Xcode and change the "Build Settings" for
  the Fan Control project and all targets except the "smc utility" target (it's
  signed via the "copyReleaseToInstaller.sh" script in the Installer directory)

Build/Test Cycle for Fan Control ...
---
- if you're an Apple developer, put your developer certificate name into the
  SIG_NAME variable in the script copyReleaseToInstaller.sh
- build FanControl via Xcode
- the built products are found in
  <wherever>Fan Control Source Code/build/Release
- to install in the current/development system:
  + run the script
    <wherever>Fan Control Source Code/Installer/copyReleaseToInstaller.sh
  + run the script
    <wherever>Fan Control Source Code/Installer/installFanControl.sh

BitBar ...
---
- drag-copy (option-drag) the BitBar folder to /Applications or "wherever"
- start BitBar
- the Fan Control plugin is a symbolic link to the plugin within the Fan Conrol
  preference pane
  /Library/PreferencePanes/FanControl.prefPane/Contents/Resources/FanControlBitBarPlugin.5s.sh


---------------
Installer Stuff
---------------

To build the installer, you need the Packages application:
http://s.sudre.free.fr/Software/Packages/about.html

If you're an Apple developer load your installer certificate into the Fan
Control Packages project -- select menu entry "Project -> Set Certificate ..."


To Change the BitBar Version Being Delivered ...
---
- update the BitBar folder in <wherever>Fan Control Source Code/Installer
- start the package-building application -- open/double-click
  <wherever>Fan Control Source Code/Installer/Fan Control.pkgproj
- select the BitBar project in the sidebar and change the "Version" entry


To Change the Fan Control Version Being Delivered ...
---
- start the package-building application -- open/double-click
  <wherever>Fan Control Source Code/Installer/Fan Control.pkgproj
- select the Fan Control project in the sidebar and change the "Version" entry


To Build an Installer Package ...
---
- having built Fan Control and/or updated the BitBar folder in the Installer dir
  + run the script
    <wherever>Fan Control Source Code/Installer/copyReleaseToInstaller.sh
- start the package-building application -- open/double-click
  <wherever>Fan Control Source Code/Installer/Fan Control.pkgproj
- type CMD-B or select the "Build -> Build" menu entry
