What is this
===
This is Fan Control 1.3 modified to run on most, if not all, Intel Macs running OS X 10.6 or later.  See the various ReadMe files in the Installer directory, for more detail.

Fan Control is based entirely upon the (excellent) Fan Control 1.2 source code from http://www.lobotomo.com/products/FanControl/.  All I did was extend Christoph's excellent work.  If you find this useful, you could donate to http://www.lobotomo.com/ and/or https://www.derman.com/.

The reason I did this (aside from the fact that I think Apple should include this or similar capability as part of OS X), is that higher temperatures, all other things being equal, will decrease the life of Mac-system components.  To me, none of the other fan-controlling solutions work as effectively as Fan Control (which I'd used on a MacBook Pro ever since it came out -- that MacBookPro2,2 15", late 2006, had 4 years of hard use and is still regularly used today, 10 years later!).  Wanting to run Fan Control on all our systems, I decided to update it so I could do so.

I hope others in the Mac community will find this useful.  Of course, there's the normal disclaimer that THIS SOFTWARE IS PROVIDED EXPRESSLY WITHOUT ANY WARRANTY OR IMPLIED FITNESS FOR PURPOSE OF ANY KIND AND, BY USING THIS SOFTWARE, YOU ASSUME ANY AND ALL RISK FOR ANY DAMAGES THAT MAY OCCUR.

Enjoy!

---
Bryan Derman
Derman Enterprises Inc.
https://www.derman.com/
