//
// Fan Control
// Copyright 2006 Lobotomo Software
// Modifications by Derman Enterprises, 2016
//
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation; either version 2
// of the License, or (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software
// Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA

#import <unistd.h>
#import "MFDaemon.h"
#import "MFDefinitions.h"
#import "MFProtocol.h"
#import <Cocoa/Cocoa.h>

int main(int argc, const char *argv[])
{
	if (MFdDebug || MFxDebug) {
		freopen(MFdFile, "a+", stderr);  // send debug logging to a file
	}

	if (MFdDebug) NSLog(@"--- Starting FanControlDaemon\n");

	// ignores restart and stop arguments (i.e., only works with "start"/"run")
	// ... and, for some reason, when launched via a LaunchDaemon script, will
	//     only run with the "run" argument (fails silently with the "start" arg)

	// handle "start" argument
	if ((argc == 2) && (strcmp(argv[1], "start") == 0)) {
		if (MFdDebug) NSLog(@"FanControlDaemon starting via 'start' argument\n");

		// fork off daemon
		pid_t pid = fork();

		if (pid == 0) {
			// since Leopard we need to exec immediately after fork (can't use
			// Foundation functionality otherwise) exec ourself again here with
			// argument "startnofork" instead of running the daemon directly here
			execl(argv[0], argv[0], "run", NULL);
		}
	} else if ((argc == 2) && (strcmp(argv[1], "run") == 0)) {
		if (MFdDebug) NSLog(@"FanControlDaemon starting via 'run' argument\n");

		// handling "run" argument -- i.e., exec'd after "start"
		NSAutoreleasePool *pool = [NSAutoreleasePool new];
		MFDaemon *daemon = [MFDaemon new];
		NSConnection *connection = [NSConnection defaultConnection];
		//NSConnection *connection = [[NSConnection new] autorelease]; // no work!

		// register the connection
		[connection setRootObject:daemon];

		if ([connection registerName:MFDaemonRegisteredName]) {
			if (MFdDebug) NSLog(@"--- Started FanControlDaemon\n");
		} else {
			if (MFdDebug) NSLog(@"ERROR: could not start FanControlDaemon\n");

			return -1;
		}

		// start the FanControlDaemon and run it in a runloop
		[daemon start];
		[[NSRunLoop currentRunLoop] run];  // never returns!

		// when the runloop ends, shut everything down to lean up
		[daemon release];
		[pool release];

		if (MFdDebug) NSLog(@"Stopped FanControlDaemon\n");
	}

	return 0;
}
