/*
 * Apple System Management Control (SMC) utility
 * Copyright (C) 2006 devnull
 * Portions Copyright (C) 2013 Michael Wilber
 * Modifications by Derman Enterprises, 2016
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.

 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.	See the
 * GNU General Public License for more details.

 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA
 */

#include <IOKit/IOKitLib.h>

// the following define is uncommented to build the smc command-line utility
//#define CMD_TOOL  // NOTE: this is left uncommented when "make all" fails!!!

// key values
#define SMC_KEY_NUM_FANS		"FNum" // number of fans

#define SMC_KEY_FAN1_ID			"F0ID" // name/ID of fan #1
#define SMC_KEY_FAN1_RPM		"F0Ac" // current fan #1 speed/RPM
#define SMC_KEY_FAN1_RPM_MIN	"F0Mn" // safe minimum speed/RPM for fan #1
#define SMC_KEY_FAN1_RPM_MAX	"F0Mx" // safe maximum speed/RPM for fan #1
#define SMC_KEY_FAN1_RPM_TGT	"F0Tg" // wanted/target speed/RPM for fan #1
#define SMC_KEY_FAN1_SAFE_RPM	"F0Sf" // current fan #1 speed/RPM

#define SMC_KEY_FAN2_ID			"F1ID" // name/ID of fan #2
#define SMC_KEY_FAN2_RPM		"F1Ac" // current fan #2 speed/RPM
#define SMC_KEY_FAN2_RPM_MIN	"F1Mn" // safe minimum speed/RPM for fan #2
#define SMC_KEY_FAN2_RPM_MAX	"F1Mx" // safe maximum speed/RPM for fan #2
#define SMC_KEY_FAN2_RPM_TGT	"F1Tg" // wanted/target speed/RPM for fan #2
#define SMC_KEY_FAN2_SAFE_RPM	"F1Sf" // current fan #2 speed/RPM

#define SMC_KEY_FAN3_ID			"F2ID" // name/ID of fan #3
#define SMC_KEY_FAN3_RPM		"F2Ac" // current fan #3 speed/RPM
#define SMC_KEY_FAN3_RPM_MIN	"F2Mn" // safe minimum speed/RPM for fan #3
#define SMC_KEY_FAN3_RPM_MAX	"F2Mx" // safe maximum speed/RPM for fan #3
#define SMC_KEY_FAN3_RPM_TGT	"F2Tg" // wanted/target speed/RPM for fan #3
#define SMC_KEY_FAN3_SAFE_RPM	"F2Sf" // current fan #3 speed/RPM

// visible types
typedef unsigned char	smcBytes_t[32];
typedef char				UInt32Char_t[5];
typedef struct {
  UInt32Char_t				key;
  UInt32						dataSize;
  UInt32Char_t				dataType;
  smcBytes_t				bytes;
} smcVal_t;

typedef struct {
	char		*name;
	char		*key;
	int		priority;
} smcSensorDefEntry;

typedef struct {
  UInt32Char_t		key;
  int					priority;
} smcTemperatureKeyEntry;

extern const smcSensorDefEntry cpuSensorDefs[];
extern const smcSensorDefEntry gpuSensorDefs[];
extern const int cpuSensorDefsCount;
extern const int gpuSensorDefsCount;

extern smcTemperatureKeyEntry	*theCPUtemperatureKeys;
extern smcTemperatureKeyEntry	*theGPUtemperatureKeys;
extern int cpuTemperatureKeysCount;
extern int gpuTemperatureKeysCount;

// prototypes
kern_return_t smcOpen(io_connect_t *conn);
kern_return_t smcClose(io_connect_t conn);
void smcInitPrioritizedTemperatureKeys(io_connect_t conn);
smcSensorDefEntry smcFindCPUsensorDef(UInt32Char_t key);
smcSensorDefEntry smcFindGPUsensorDef(UInt32Char_t key);
int smcGetNumFans(io_connect_t conn);
void smcGetFanID(char *key, char *fanID, io_connect_t conn);
kern_return_t smcSetMinFanRPM(char *key, int rpm, io_connect_t conn);
kern_return_t smcSetTargetFanRPM(char *key, int rpm, io_connect_t conn);
float smcGetTemperature(char *key, io_connect_t conn);
int smcGetFanRPM(char *key, io_connect_t conn);
