//
// Fan Control Utility
// Copyright 2016 Derman Enterprises
//
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation; either version 2
// of the License, or (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You may have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software
// Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA

// this "quick 'n dirty" little utility was created solely for the purpose of
// making the Fan Control BitBar plugin more efficient -- i.e., instead of
// constantly invoking the smc utility to do a considerable amount of work to
// generate every update, the plugin calls this utility which, in turn, asks the
// FanControlDaemon for the information ... and since the FanControlDaemon's job
// is to constantly maintain this information (and since it does so much more
// efficiently than separate invocations of the smc utility), using this utility
// is much more efficient

#import "MFDaemon.h"
#import "MFDefinitions.h"
#import "MFProtocol.h"
#import "smc.h"
#import <Cocoa/Cocoa.h>

// -----------------------------------------------------------------------------
int main(int argc, const char *argv[])
{
	BOOL						beVerbose = NO;
	BOOL						showTempsAsFahrenheit;
	int						i;
	int						numFans;
	float						currTempC;
	float						currTempF;
	float						lowerTempThreshold;
	float						upperTempThreshold;
	float						cpuTemp;
	float						gpuTemp;
	fanNames					systemFanNames;
	fanSpeeds				minFanSpeeds;
	fanSpeeds				maxFanSpeeds;
	fanSpeeds				currentFanSpeeds;
	smcSensorDefEntry		theSensorDef;
	io_connect_t			conn;

	if ((argc == 2) && (strcmp(argv[1], "-v") == 0)) beVerbose = YES;

	if (MFuDebug || MFxDebug) {
		freopen(MFuFile, "a+", stderr);  // send debug logging to a file
	}

	if (MFuDebug) {
		NSLog(@"=====\n");
		NSLog(@"--- Starting getFanControlInfo\n");
	}

	// connect to Fan Control daemon
	//NSAutoreleasePool *pool = [NSAutoreleasePool new];
	MFDaemon *daemon = [MFDaemon new];

	@try {
		NSConnection *connection =
					[NSConnection
						connectionWithRegisteredName:MFDaemonRegisteredName host:nil];
		daemon = [[connection rootProxy] retain];
		[(id)daemon setProtocolForProxy:@protocol(MFProtocol)];
	} @catch(NSException *theException) {
		if (MFuDebug) {
			NSLog(@"ERROR: could not establish a connection to the Fan Control daemon\n");
			NSLog(@"--- getFanControlInfo completed\n");
		}

		return -1;
	}

	// this is an "expensive" operation (already being done by FanControlDaemon)
	// and is included only because it can be handy for ad-hoc manual queries
	if (beVerbose) {
		smcOpen(&conn);

		printf("The following CPU-related temperature keys are available:\n");
		currTempC = -100.0;

		for (i = 0; i < cpuTemperatureKeysCount; i++) {
			if (theCPUtemperatureKeys[i].priority == 0) continue;

			currTempC = smcGetTemperature(theCPUtemperatureKeys[i].key, conn);

			if (currTempC < 0.0) continue;

			currTempF = (currTempC / 5.0 * 9.0) + 32;
			theSensorDef = smcFindCPUsensorDef(theCPUtemperatureKeys[i].key);

			printf(
			 "smc key: %s  priority: %d  current temperature: %.2f °c / %.1f °f (%s)\n",
					theCPUtemperatureKeys[i].key, theCPUtemperatureKeys[i].priority,
													currTempC, currTempF, theSensorDef.name);
		}

		printf("\n");
		printf("The following GPU-related temperature keys are available:\n");
		currTempC = -100.0;

		for (i = 0; i < gpuTemperatureKeysCount; i++) {
			if (theGPUtemperatureKeys[i].priority == 0) continue;

			currTempC = smcGetTemperature(theGPUtemperatureKeys[i].key, conn);

			if (currTempC < 0.0) continue;

			currTempF = (currTempC / 5.0 * 9.0) + 32;
			theSensorDef = smcFindGPUsensorDef(theGPUtemperatureKeys[i].key);

			printf(
			 "smc key: %s  priority: %d  current temperature: %.2f °c / %.1f °f (%s)\n",
					theGPUtemperatureKeys[i].key, theGPUtemperatureKeys[i].priority,
													currTempC, currTempF, theSensorDef.name);
		}

		smcClose(conn);
		printf("\n");
		printf("NOTE: the above and below temperatures were gathered at different times (so they often differ).\n");
		printf("\n");
	}

	// get the information from the FanControlDaemon
	showTempsAsFahrenheit = [daemon showTempsAsFahrenheit];
	lowerTempThreshold = [daemon lowerTempThreshold];
	upperTempThreshold = [daemon upperTempThreshold];
	cpuTemp = [daemon cpuTemp];
	gpuTemp = [daemon gpuTemp];
	numFans = [daemon numFans];
	systemFanNames = [daemon systemFanNames];
	minFanSpeeds = [daemon minFanSpeeds];
	maxFanSpeeds = [daemon maxFanSpeeds];
	currentFanSpeeds = [daemon currentFanSpeeds];

	// output the information to standard out
	printf("showTempsAsFahrenheit=%s\n",
												showTempsAsFahrenheit ? "true" : "false");
	printf("lowerTempThreshold=%.1f\n", lowerTempThreshold);
	printf("upperTempThreshold=%.1f\n", upperTempThreshold);

	printf("cpuTemp=%f\n", cpuTemp);
	printf("gpuTemp=%f\n", gpuTemp);

	printf("numFans=%d\n", numFans);

	printf("fan1name=%s\n", systemFanNames.fanName[0]);
	if (numFans > 1) printf("fan2name=%s\n", systemFanNames.fanName[1]);
	if (numFans > 2) printf("fan3name=%s\n", systemFanNames.fanName[2]);

	printf("minFan1speed=%d\n", minFanSpeeds.fanRPMs[0]);
	if (numFans > 1) printf("minFan2speed=%d\n", minFanSpeeds.fanRPMs[1]);
	if (numFans > 2) printf("minFan3speed=%d\n", minFanSpeeds.fanRPMs[2]);

	printf("maxFan1speed=%d\n", maxFanSpeeds.fanRPMs[0]);
	if (numFans > 1) printf("maxFan2speed=%d\n", maxFanSpeeds.fanRPMs[1]);
	if (numFans > 2) printf("maxFan3speed=%d\n", maxFanSpeeds.fanRPMs[2]);

	printf("currFan1speed=%d\n", currentFanSpeeds.fanRPMs[0]);
	if (numFans > 1) printf("currFan2speed=%d\n", currentFanSpeeds.fanRPMs[1]);
	if (numFans > 2) printf("currFan3speed=%d\n", currentFanSpeeds.fanRPMs[2]);

	[daemon release];
	//[pool release];

	if (MFuDebug) NSLog(@"--- getFanControlInfo completed\n");

	return 0;
}
