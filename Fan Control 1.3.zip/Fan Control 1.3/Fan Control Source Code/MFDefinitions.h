//
// Fan Control
// Copyright 2006 Lobotomo Software
// Modifications by Derman Enterprises, 2016
//
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation; either version 2
// of the License, or (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software
// Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA

#define MFapplicationIdentifier	"com.derman.FanControl"

#define MFcDebug	0  // Value to turn off(0)/on(1) chart/graph debug logging
#define MFdDebug	0  // Value to turn off(0)/on(1) daemon debug logging
#define MFpDebug	0  // Value to turn off(0)/on(1) pref-pane debug logging
#define MFuDebug	0  // Value to turn off(0)/on(1) utility debug logging
#define MFxDebug	0  // Value to turn off(0)/on(1) ad-hoc debug logging
#define MFdFile	"/var/log/FanControlDaemon.log"  // debug-logfile name
#define MFpFile	"/var/log/FanControlPrefPane.log"  // debug-logfile name
#define MFuFile	"/var/log/FanControlUtility.log"  // debug-logfile name

// value, in seconds, that determines the interval between Fan Control updates
// - use a shorter interval when using faster-responding sensors
// - too long an interval will lead to a oscillating fans
#define MFupdateInterval	3.0

// values that specify the range of temperatures (in degrees Celcius) for which
// Fan Control will compute and set a fan's RPM versus it's sensor's temperature
// NOTE:
// - these values must correspond to the low/high values available via the UI's
//   "Lower Temp Threshold" and "Upper Temp Threshold" slider settings
// - if changing these values, also update the code (in MFPreferencePane.m) that
//   sets the number of tick marks for the sliders -- yes, this could have been
//   computed ... but I was too lazy!  #;-))
//
#define MFlowerTempThresholdBottom	25.0
#define MFlowerTempThresholdTop		55.0
#define MFupperTempThresholdBottom	55.0
#define MFupperTempThresholdTop		95.0

// values that determine the "safe" min/max fan speeds for any fan
#define MFminFanRPM	1200  // used as a "starting point" when daemon is launched
#define MFmaxFanRPM	2400  // overridden by the value supplied by smc

// values that control the speed-stepping of the fans:
// - fans are adjusted in increments of MFspeedStepRPM
// - fans are adjusted to RPMs that target MFspeedStepRPM boundaries
// - each fan-speed adjustment occurs in increments no larger than
//   MFmaxRPMspeedStep to help ensure fan speeds "ramp up/down" more smoothly
//
// NOTE:
// - the UI/slider increments should be set to ensure that the fan settings are
//   are in MFspeedStepRPM increments or a multiple thereof
#define MFspeedStepRPM		50
#define MFmaxRPMspeedStep	250  // increased by 100 for fans w/max RPM over 2500
                                // & that's doubled when highest temp > 70 deg.C

typedef struct {
	int	fanRPMs[3];
} fanSpeeds;

typedef struct {
	char	fanName[3][32];
} fanNames;
