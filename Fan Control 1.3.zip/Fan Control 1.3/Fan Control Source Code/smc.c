/*
 * Apple System Management Control (SMC) utility
 * Copyright (C) 2006 devnull
 * Portions Copyright (C) 2013 Michael Wilber
 * Modifications by Derman Enterprises, 2016
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.

 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.

 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA
 */

#include "smc.h"
#include <stdbool.h>
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <libkern/OSAtomic.h>

#define VERSION					"2016-10"

#define OP_NONE					0
#define OP_LIST_ALL				1
#define OP_READ					2
#define OP_READ_FAN_INFO		3
#define OP_READ_FAN_RPM			4
#define OP_READ_TEMP				5
#define OP_SET_MIN_FAN_SPEED	6
#define OP_SET_TGT_FAN_SPEED	7
//#define OP_WRITE				7  // this can potentially be quite dangerous
#define OP_LIST_CPU				8
#define OP_LIST_GPU				9
#define OP_PRIORITIZED_LIST	10

#define KERNEL_INDEX_SMC		2

#define SMC_CMD_READ_BYTES		5
#define SMC_CMD_WRITE_BYTES	6
#define SMC_CMD_READ_INDEX		8
#define SMC_CMD_READ_KEYINFO	9
#define SMC_CMD_READ_PLIMIT	11
#define SMC_CMD_READ_VERS		12

#define DATATYPE_FP1F			"fp1f"
#define DATATYPE_FP4C			"fp4c"
#define DATATYPE_FP5B			"fp5b"
#define DATATYPE_FP6A			"fp6a"
#define DATATYPE_FP79			"fp79"
#define DATATYPE_FP88			"fp88"
#define DATATYPE_FPA6			"fpa6"
#define DATATYPE_FPC4			"fpc4"
#define DATATYPE_FPE2			"fpe2"

#define DATATYPE_SP1E			"sp1e"
#define DATATYPE_SP3C			"sp3c"
#define DATATYPE_SP4B			"sp4b"
#define DATATYPE_SP5A			"sp5a"
#define DATATYPE_SP69			"sp69"
#define DATATYPE_SP78			"sp78"
#define DATATYPE_SP87			"sp87"
#define DATATYPE_SP96			"sp96"
#define DATATYPE_SPB4			"spb4"
#define DATATYPE_SPF0			"spf0"

#define DATATYPE_UINT8			"ui8 "
#define DATATYPE_UINT16			"ui16"
#define DATATYPE_UINT32			"ui32"

#define DATATYPE_SI8				"si8 "
#define DATATYPE_SI16			"si16"

#define DATATYPE_PWM				"{pwm"

#ifdef CMD_TOOL
static io_connect_t smc_conn = 0;
#endif //for #ifdef CMD_TOOL

typedef struct {
	 char						major;
	 char						minor;
	 char						build;
	 char						reserved[1];
	 UInt16					release;
} smcKeyData_vers_t;

typedef struct {
	 UInt16					version;
	 UInt16					length;
	 UInt32					cpuPLimit;
	 UInt32					gpuPLimit;
	 UInt32					memPLimit;
} smcKeyData_pLimitData_t;

typedef struct {
	 UInt32					dataSize;
	 UInt32					dataType;
	 char						dataAttributes;
} smcKeyData_keyInfo_t;

typedef struct {
	UInt32						key;
	smcKeyData_vers_t			vers;
	smcKeyData_pLimitData_t	pLimitData;
	smcKeyData_keyInfo_t		keyInfo;
	char							result;
	char							status;
	char							data8;
	UInt32						data32;
	smcBytes_t					bytes;
} smcKeyData_t;

// NOTE: the following "sensor maps" are generated from "best available"
//       information (some emperical research plus various "Mr. Google finds"
//       along with some (maybe quite invalid) allowances for multiples of some
//       of the keys -- if Fan Control isn't finding anything, then either
//       something has changed (i.e., in OS X/MacOS and/or the following maps
//       need to be updated so the applicable key(s) can be found

static smcSensorDefEntry noSensorDef = { "", "", 0 };

const int cpuSensorDefsCount = 54;  // UPDATE THIS WHEN UPDATING cpuSensorDefs!!
const smcSensorDefEntry cpuSensorDefs[] =
{
	{"CPU Die",						"TC0D", 1},
	{"CPU Die",						"TC1D", 1},
	{"CPU Die",						"TC2D", 1},
	{"CPU Die",						"TC3D", 1},
	{"CPU Die",						"TC4D", 1},
	{"CPU Package",				"TC0C", 2},
	{"CPU Package",				"TC1C", 2},
	{"CPU Package",				"TC2C", 2},
	{"CPU Package",				"TC3C", 2},
	{"CPU Package",				"TC4C", 2},
	{"CPU Package",				"TCXC", 2},
	{"CPU Package",				"TCAD", 2},
	{"CPU Package",				"TCBD", 2},
	{"CPU",							"TC0E", 2},
	{"CPU",							"TC1E", 2},
	{"CPU",							"TC2E", 2},
	{"CPU",							"TC3E", 2},
	{"CPU",							"TC4E", 2},
	{"CPU",							"TC0F", 2},
	{"CPU",							"TC1F", 2},
	{"CPU",							"TC2F", 2},
	{"CPU",							"TC3F", 2},
	{"CPU",							"TC4F", 2},
	{"CPU Package",				"TCXc", 2},
	{"CPU Heatsink",				"TC0H", 3},
	{"CPU Heatsink",				"TC1H", 3},
	{"CPU Heatsink",				"TC2H", 3},
	{"CPU Heatsink",				"TCAH", 3},
	{"CPU Heatsink",				"TCBH", 3},
	{"PECI SA",						"TCSC", 3},
	{"PECI SA",						"TCSc", 3},
	{"PECI SA",						"TCSA", 3},
	{"CPU Core",					"TC0C", 4},
	{"CPU Core",					"TC1C", 4},
	{"CPU Core",					"TC2C", 4},
	{"CPU Core",					"TC3C", 4},
	{"CPU Core",					"TC4C", 4},
	{"CPU Core",					"TC5C", 4},
	{"CPU Core",					"TC6C", 4},
	{"CPU Core",					"TC7C", 4},
	{"CPU Core",					"TC8C", 4},
	{"CPU Core",					"TC9C", 4},
	{"CPU Core",					"TCAC", 4},
	{"CPU Core",					"TCBC", 4},
	{"CPU Core",					"TCCC", 4},
	{"CPU Core",					"TCDC", 4},
	{"CPU Core",					"TCEC", 4},
	{"CPU Core",					"TCFC", 4},
	{"CPU Proximity",				"TC0P", 5},
	{"CPU Proximity",				"TC1P", 5},
	{"CPU Proximity",				"TC2P", 5},
	{"CPU Ambient",				"TA0P", 6},
	{"CPU Ambient",				"TA1P", 6},
	{"CPU Ambient",				"TA2P", 6},
};

const int gpuSensorDefsCount = 31;  // UPDATE THIS WHEN UPDATING GpuSensorDefs!!
const smcSensorDefEntry gpuSensorDefs[] =
{
	{"GPU Die",								"TG0D", 1},
	{"GPU Die",								"TG1D", 1},
	{"GPU Die",								"TG2D", 1},
	{"GPU Heatsink",						"TG0H", 2},
	{"GPU Heatsink",						"TG1H", 2},
	{"GPU Heatsink",						"TG2H", 2},
	{"PECI GPU",							"TCGC", 3},
	{"PECI GPU",							"TCGc", 3},
	{"GPU Proximity",						"TG0p", 4},
	{"GPU Proximity",						"TG1p", 4},
	{"GPU Proximity",						"TG2p", 4},
	{"GPU Memory",							"TG0M", 5},
	{"GPU Memory",							"TG1M", 5},
	{"GPU Memory",							"TG2M", 5},
	{"Northbridge Die",					"TN0D", 6},
	{"Northbridge Die",					"TN1D", 6},
	{"Northbridge Die",					"TN2D", 6},
	{"Platform Controller Die",		"TP0D", 6},
	{"Platform Controller Die",		"TPCD", 6},
	{"Northbridge Proximity",			"TN0P", 7},
	{"Northbridge Proximity",			"TN1P", 7},
	{"Northbridge Proximity",			"TN2P", 7},
	{"Platform Controller Proximity","TP0P", 7},
	{"Heatpipe",							"Th0H", 7},
	{"Heatpipe",							"Th1H", 7},
	{"Heatpipe",							"Th2H", 7},
	{"CPU GFX",								"TC0G", 8},
	{"CPU GFX",								"TC1G", 8},
	{"CPU GFX",								"TC2G", 8},
	{"CPU GFX",								"TC3G", 8},
	{"CPU GFX",								"TC4G", 8},
};

static smcTemperatureKeyEntry noTemperatureKey = { "", 0 };

static smcTemperatureKeyEntry	cpuTemperatureKeys[64] = {
	{ "", 0 }, { "", 0 }, { "", 0 }, { "", 0 }, { "", 0 }, { "", 0 }, { "", 0 },
	{ "", 0 }, { "", 0 }, { "", 0 }, { "", 0 }, { "", 0 }, { "", 0 }, { "", 0 },
	{ "", 0 }, { "", 0 }, { "", 0 }, { "", 0 }, { "", 0 }, { "", 0 }, { "", 0 },
	{ "", 0 }, { "", 0 }, { "", 0 }, { "", 0 }, { "", 0 }, { "", 0 }, { "", 0 },
	{ "", 0 }, { "", 0 }, { "", 0 }, { "", 0 }, { "", 0 }, { "", 0 }, { "", 0 },
	{ "", 0 }, { "", 0 }, { "", 0 }, { "", 0 }, { "", 0 }, { "", 0 }, { "", 0 },
	{ "", 0 }, { "", 0 }, { "", 0 }, { "", 0 }, { "", 0 }, { "", 0 }, { "", 0 },
	{ "", 0 }, { "", 0 }, { "", 0 }, { "", 0 }, { "", 0 }, { "", 0 }, { "", 0 },
	{ "", 0 }, { "", 0 }, { "", 0 }, { "", 0 }, { "", 0 }, { "", 0 }, { "", 0 },
	{ "", 0 }
};

static smcTemperatureKeyEntry	gpuTemperatureKeys[64] = {
	{ "", 0 }, { "", 0 }, { "", 0 }, { "", 0 }, { "", 0 }, { "", 0 }, { "", 0 },
	{ "", 0 }, { "", 0 }, { "", 0 }, { "", 0 }, { "", 0 }, { "", 0 }, { "", 0 },
	{ "", 0 }, { "", 0 }, { "", 0 }, { "", 0 }, { "", 0 }, { "", 0 }, { "", 0 },
	{ "", 0 }, { "", 0 }, { "", 0 }, { "", 0 }, { "", 0 }, { "", 0 }, { "", 0 },
	{ "", 0 }, { "", 0 }, { "", 0 }, { "", 0 }, { "", 0 }, { "", 0 }, { "", 0 },
	{ "", 0 }, { "", 0 }, { "", 0 }, { "", 0 }, { "", 0 }, { "", 0 }, { "", 0 },
	{ "", 0 }, { "", 0 }, { "", 0 }, { "", 0 }, { "", 0 }, { "", 0 }, { "", 0 },
	{ "", 0 }, { "", 0 }, { "", 0 }, { "", 0 }, { "", 0 }, { "", 0 }, { "", 0 },
	{ "", 0 }, { "", 0 }, { "", 0 }, { "", 0 }, { "", 0 }, { "", 0 }, { "", 0 },
	{ "", 0 }
};

smcTemperatureKeyEntry	*theCPUtemperatureKeys = cpuTemperatureKeys;  // extern
smcTemperatureKeyEntry	*theGPUtemperatureKeys = gpuTemperatureKeys;  // extern

int cpuTemperatureKeysCount = 0;  // extern
int gpuTemperatureKeysCount = 0;  // extern
static int onlyReturnNum = 0;

// Cache the keyInfo to lower the energy impact of smcReadKey() & smcReadKey2()
#define KEY_INFO_CACHE_SIZE 2048

static int smc_keyInfoCacheCount = 0;
static OSSpinLock smc_keyInfoSpinLock = 0;

static struct {
	UInt32 key;
	smcKeyData_keyInfo_t keyInfo;
} smc_keyInfoCache[KEY_INFO_CACHE_SIZE];

//==============================================================================
#pragma mark C Helpers

//------------------------------------------------------------------------------
UInt32 _strtoul(char	*str,
					 int	size,
					 int	base)
{
	UInt32	total = 0;
	int		i;

	for (i = 0; i < size; i++)
	{
		if (base == 16) total += str[i] << (size - 1 - i) * 8;
		else total += ((unsigned char) (str[i]) << (size - 1 - i) * 8);
	}

	return total;
}

//------------------------------------------------------------------------------
void _ultostr(char	*str,
				  UInt32	val)
{
	str[0] = '\0';
	sprintf(str,
			  "%c%c%c%c",
			  (unsigned int) val >> 24,
			  (unsigned int) val >> 16,
			  (unsigned int) val >> 8,
			  (unsigned int) val);
}

//------------------------------------------------------------------------------
float _strtof(unsigned char *str,
				  int size,
				  int e)
{
	float	total = 0;
	int	i;

	for (i = 0; i < size; i++)
	{
		if (i == (size - 1)) total += (str[i] & 0xff) >> e;
		else total += str[i] << (size - 1 - i) * (8 - e);
	}

	total += (str[size-1] & 0x03) * 0.25;
	return total;
}

//------------------------------------------------------------------------------
// Printers for various data types
void printFP1F(smcVal_t val)
{
	printf("%.5f", ntohs(*(UInt16*)val.bytes) / 32768.0);
}

void printFP4C(smcVal_t val)
{
	printf("%.5f", ntohs(*(UInt16*)val.bytes) / 4096.0);
}

void printFP5B(smcVal_t val)
{
	printf("%.5f", ntohs(*(UInt16*)val.bytes) / 2048.0);
}

void printFP6A(smcVal_t val)
{
	printf("%.4f", ntohs(*(UInt16*)val.bytes) / 1024.0);
}

void printFP79(smcVal_t val)
{
	printf("%.4f", ntohs(*(UInt16*)val.bytes) / 512.0);
}

void printFP88(smcVal_t val)
{
	printf("%.3f", ntohs(*(UInt16*)val.bytes) / 256.0);
}

void printFPA6(smcVal_t val)
{
	printf("%.2f", ntohs(*(UInt16*)val.bytes) / 64.0);
}

void printFPC4(smcVal_t val)
{
	printf("%.2f", ntohs(*(UInt16*)val.bytes) / 16.0);
}

void printFPE2(smcVal_t val)
{
	printf("%.2f", ntohs(*(UInt16*)val.bytes) / 4.0);
}

void printUInt(smcVal_t val)
{
	printf("%u", (unsigned int) _strtoul((char *)val.bytes, val.dataSize, 10));
}

void printSP1E(smcVal_t val)
{
	printf("%.5f", ((SInt16)ntohs(*(UInt16*)val.bytes)) / 16384.0);
}

void printSP3C(smcVal_t val)
{
	printf("%.5f", ((SInt16)ntohs(*(UInt16*)val.bytes)) / 4096.0);
}

void printSP4B(smcVal_t val)
{
	printf("%.4f", ((SInt16)ntohs(*(UInt16*)val.bytes)) / 2048.0);
}

void printSP5A(smcVal_t val)
{
	printf("%.4f", ((SInt16)ntohs(*(UInt16*)val.bytes)) / 1024.0);
}

void printSP69(smcVal_t val)
{
	printf("%.3f", ((SInt16)ntohs(*(UInt16*)val.bytes)) / 512.0);
}

void printSP78(smcVal_t val)
{
	printf("%.3f", ((SInt16)ntohs(*(UInt16*)val.bytes)) / 256.0);
}

void printSP87(smcVal_t val)
{
	printf("%.3f", ((SInt16)ntohs(*(UInt16*)val.bytes)) / 128.0);
}

void printSP96(smcVal_t val)
{
	printf("%.2f", ((SInt16)ntohs(*(UInt16*)val.bytes)) / 64.0);
}

void printSPB4(smcVal_t val)
{
	printf("%.2f", ((SInt16)ntohs(*(UInt16*)val.bytes)) / 16.0);
}

void printSPF0(smcVal_t val)
{
	printf("%.0f", (float)ntohs(*(UInt16*)val.bytes));
}

void printSI8(smcVal_t val)
{
	printf("%d", (signed char)*val.bytes);
}

void printSI16(smcVal_t val)
{
	printf("%d", ntohs(*(SInt16*)val.bytes));
}

void printPWM(smcVal_t val)
{
	printf("%.1f%%", ntohs(*(UInt16*)val.bytes) * 100 / 65536.0);
}

void printBytesHex(smcVal_t val)
{
	int i;
	printf("(bytes");

	for (i = 0; i < val.dataSize; i++) printf(" %02x",
															(unsigned char) val.bytes[i]);
	printf(")\n");
}

//------------------------------------------------------------------------------
void printVal(smcVal_t val)
{
	if (onlyReturnNum != 1) {
		printf(" %-4s [%-4s]  ", val.key, val.dataType);
	}

	if (val.dataSize > 0) {
		if ((strcmp(val.dataType, DATATYPE_UINT8) == 0) ||
			 (strcmp(val.dataType, DATATYPE_UINT16) == 0) ||
			 (strcmp(val.dataType, DATATYPE_UINT32) == 0)) printUInt(val);
		else if (strcmp(val.dataType, DATATYPE_FP1F) == 0 && val.dataSize == 2)
			printFP1F(val);
		else if (strcmp(val.dataType, DATATYPE_FP4C) == 0 && val.dataSize == 2)
			printFP4C(val);
		else if (strcmp(val.dataType, DATATYPE_FP5B) == 0 && val.dataSize == 2)
			printFP5B(val);
		else if (strcmp(val.dataType, DATATYPE_FP6A) == 0 && val.dataSize == 2)
			printFP6A(val);
		else if (strcmp(val.dataType, DATATYPE_FP79) == 0 && val.dataSize == 2)
			printFP79(val);
		else if (strcmp(val.dataType, DATATYPE_FP88) == 0 && val.dataSize == 2)
			printFP88(val);
		else if (strcmp(val.dataType, DATATYPE_FPA6) == 0 && val.dataSize == 2)
			printFPA6(val);
		else if (strcmp(val.dataType, DATATYPE_FPC4) == 0 && val.dataSize == 2)
			printFPC4(val);
		else if (strcmp(val.dataType, DATATYPE_FPE2) == 0 && val.dataSize == 2)
			printFPE2(val);
		else if (strcmp(val.dataType, DATATYPE_SP1E) == 0 && val.dataSize == 2)
			printSP1E(val);
		else if (strcmp(val.dataType, DATATYPE_SP3C) == 0 && val.dataSize == 2)
			printSP3C(val);
		else if (strcmp(val.dataType, DATATYPE_SP4B) == 0 && val.dataSize == 2)
			printSP4B(val);
		else if (strcmp(val.dataType, DATATYPE_SP5A) == 0 && val.dataSize == 2)
			printSP5A(val);
		else if (strcmp(val.dataType, DATATYPE_SP69) == 0 && val.dataSize == 2)
			printSP69(val);
		else if (strcmp(val.dataType, DATATYPE_SP78) == 0 && val.dataSize == 2)
			printSP78(val);
		else if (strcmp(val.dataType, DATATYPE_SP87) == 0 && val.dataSize == 2)
			printSP87(val);
		else if (strcmp(val.dataType, DATATYPE_SP96) == 0 && val.dataSize == 2)
			printSP96(val);
		else if (strcmp(val.dataType, DATATYPE_SPB4) == 0 && val.dataSize == 2)
			printSPB4(val);
		else if (strcmp(val.dataType, DATATYPE_SPF0) == 0 && val.dataSize == 2)
			printSPF0(val);
		else if (strcmp(val.dataType, DATATYPE_SI8) == 0 && val.dataSize == 1)
			printSI8(val);
		else if (strcmp(val.dataType, DATATYPE_SI16) == 0 && val.dataSize == 2)
			printSI16(val);
		else if (strcmp(val.dataType, DATATYPE_PWM) == 0 && val.dataSize == 2)
			printPWM(val);

		if (onlyReturnNum != 1) {
			printf(" ");
			printBytesHex(val);
		}
	}
	else printf("Error: no data\n");
}

//==============================================================================
#pragma mark shared smc functions

//------------------------------------------------------------------------------
kern_return_t smcOpen(io_connect_t *conn)
{
	kern_return_t	result;
	mach_port_t		masterPort;
	io_iterator_t	iterator;
	io_object_t		device;

	IOMasterPort(MACH_PORT_NULL, &masterPort);

	CFMutableDictionaryRef matchingDictionary = IOServiceMatching("AppleSMC");
	result =
		IOServiceGetMatchingServices(masterPort, matchingDictionary, &iterator);

	if (result != kIOReturnSuccess) {
		printf("Error: IOServiceGetMatchingServices() = %08x\n", result);
		return 1;
	}

	device = IOIteratorNext(iterator);
	IOObjectRelease(iterator);

	if (device == 0) {
		printf("Error: Apple's SMC service was not found\n");
		return 1;
	}

	result = IOServiceOpen(device, mach_task_self(), 0, conn);
	IOObjectRelease(device);

	if (result != kIOReturnSuccess) {
		printf("Error: IOServiceOpen() = %08x\n", result);
		return 1;
	}

	return kIOReturnSuccess;
}

//------------------------------------------------------------------------------
kern_return_t smcClose(io_connect_t conn)
{
	return IOServiceClose(conn);
}

//------------------------------------------------------------------------------
kern_return_t smcCall2(int				index,
							  smcKeyData_t	*inputStructure,
							  smcKeyData_t	*outputStructure,
							  io_connect_t	conn)
{
	size_t	 structureInputSize;
	size_t	 structureOutputSize;

	structureInputSize = sizeof(smcKeyData_t);
	structureOutputSize = sizeof(smcKeyData_t);

	return IOConnectCallStructMethod(conn,
												index,
												inputStructure,
												structureInputSize,
												outputStructure,
												&structureOutputSize);
}

//------------------------------------------------------------------------------
kern_return_t smcCall(int				index,
							 smcKeyData_t	*inputStructure,
							 smcKeyData_t	*outputStructure,
							 io_connect_t	conn)
{
	return smcCall2(index, inputStructure, outputStructure, conn);
}

//------------------------------------------------------------------------------
// Provides key info, using a cache to dramatically improve the energy impact of
// Fan Control
kern_return_t smcGetKeyInfo(UInt32						key,
									 smcKeyData_keyInfo_t	*keyInfo,
									 io_connect_t				conn)
{
	smcKeyData_t	inputStructure;
	smcKeyData_t	outputStructure;
	kern_return_t	result = kIOReturnSuccess;
	int				i;

	OSSpinLockLock(&smc_keyInfoSpinLock);

	for (i = 0; i < smc_keyInfoCacheCount; ++i)
	{
		if (key == smc_keyInfoCache[i].key) {
			*keyInfo = smc_keyInfoCache[i].keyInfo;
			break;
		}
	}

	if (i == smc_keyInfoCacheCount) {
		// Not in cache, must look it up.
		memset(&inputStructure, 0, sizeof(inputStructure));
		memset(&outputStructure, 0, sizeof(outputStructure));

		inputStructure.key = key;
		inputStructure.data8 = SMC_CMD_READ_KEYINFO;

		result = smcCall2(KERNEL_INDEX_SMC,
								&inputStructure,
								&outputStructure,
								conn);

		if (result == kIOReturnSuccess) {
			*keyInfo = outputStructure.keyInfo;

			if (smc_keyInfoCacheCount < KEY_INFO_CACHE_SIZE) {
				smc_keyInfoCache[smc_keyInfoCacheCount].key = key;
				smc_keyInfoCache[smc_keyInfoCacheCount].keyInfo =
																		outputStructure.keyInfo;
				++smc_keyInfoCacheCount;
			}
		}
	}

	OSSpinLockUnlock(&smc_keyInfoSpinLock);

	return result;
}

//------------------------------------------------------------------------------
kern_return_t smcReadKey2(UInt32Char_t	key,
								  smcVal_t		*val,
								  io_connect_t	conn)
{
	kern_return_t	result;
	smcKeyData_t	inputStructure;
	smcKeyData_t	outputStructure;

	memset(&inputStructure, 0, sizeof(smcKeyData_t));
	memset(&outputStructure, 0, sizeof(smcKeyData_t));
	memset(val, 0, sizeof(smcVal_t));

	inputStructure.key = _strtoul(key, 4, 16);
	sprintf(val->key, key);

	result = smcGetKeyInfo(inputStructure.key, &outputStructure.keyInfo, conn);

	if (result != kIOReturnSuccess) return result;

	val->dataSize = outputStructure.keyInfo.dataSize;
	_ultostr(val->dataType, outputStructure.keyInfo.dataType);
	inputStructure.keyInfo.dataSize = val->dataSize;
	inputStructure.data8 = SMC_CMD_READ_BYTES;

	result = smcCall2(KERNEL_INDEX_SMC, &inputStructure, &outputStructure, conn);

	if (result != kIOReturnSuccess) return result;

	memcpy(val->bytes, outputStructure.bytes, sizeof(outputStructure.bytes));

	return kIOReturnSuccess;
}

//------------------------------------------------------------------------------
kern_return_t smcReadKey(UInt32Char_t	key,
								 smcVal_t		*val,
								 io_connect_t	conn)
{
	return smcReadKey2(key, val, conn);
}

//------------------------------------------------------------------------------
UInt32 smcReadIndexCount(io_connect_t conn)
{
	smcVal_t		val;

	smcReadKey("#KEY", &val, conn);
	return _strtoul((char *)val.bytes, val.dataSize, 10);
}

//------------------------------------------------------------------------------
kern_return_t smcWriteKey2(smcVal_t			writeVal,
									io_connect_t	conn)
{
	kern_return_t	result;
	smcKeyData_t	inputStructure;
	smcKeyData_t	outputStructure;
	smcVal_t			readVal;

	result = smcReadKey2(writeVal.key, &readVal, conn);

	if (result != kIOReturnSuccess) return result;
	if (readVal.dataSize != writeVal.dataSize) return kIOReturnError;

	memset(&inputStructure, 0, sizeof(smcKeyData_t));
	memset(&outputStructure, 0, sizeof(smcKeyData_t));

	inputStructure.key = _strtoul(writeVal.key, 4, 16);
	inputStructure.data8 = SMC_CMD_WRITE_BYTES;
	inputStructure.keyInfo.dataSize = writeVal.dataSize;
	memcpy(inputStructure.bytes, writeVal.bytes, sizeof(writeVal.bytes));
	result = smcCall2(KERNEL_INDEX_SMC, &inputStructure, &outputStructure, conn);

	if (result != kIOReturnSuccess) return result;

	return kIOReturnSuccess;
}

//------------------------------------------------------------------------------
float smcGetTemperature(char				*key,
								io_connect_t	conn)
{
	smcVal_t			val;
	kern_return_t	result;

	result = smcReadKey2(key, &val, conn);

	if (result == kIOReturnSuccess) {
		// read succeeded - check returned value
		if (val.dataSize > 0) {
			if (strcmp(val.dataType, DATATYPE_SP78) == 0) {
				// convert sp78 value to temperature
				return ((SInt16)ntohs(*(UInt16*)val.bytes)) / 256.0;
			}
		}
	}

	return -100.0;  // smc read failed
}

//------------------------------------------------------------------------------
int smcGetNumFans(io_connect_t conn)
{
	smcVal_t			val;
	kern_return_t	result;

	result = smcReadKey2(SMC_KEY_NUM_FANS, &val, conn);

	if (result != kIOReturnSuccess) return -1;  // smc read failed

	return (unsigned int) _strtoul((char *)val.bytes, val.dataSize, 10);
}

//------------------------------------------------------------------------------
void smcGetFanID(char			*key,
					 char				*fanID,
					 io_connect_t	conn)
{
	kern_return_t	result;
	smcVal_t			val;

	result = smcReadKey(key, &val, conn);

	if (result != kIOReturnSuccess) {
		sprintf(fanID, "%s", "");
		return;
	}

	sprintf(fanID, "%s", val.bytes+4);
}

//------------------------------------------------------------------------------
int smcGetFanRPM(char			*key,
					  io_connect_t	conn)
{
	smcVal_t			val;
	kern_return_t	result;

	result = smcReadKey2(key, &val, conn);

	if (result == kIOReturnSuccess) {
		// read succeeded - check returned value
		if (val.dataSize > 0) {
			if (strcmp(val.dataType, DATATYPE_FPE2) == 0) {
				// convert FPE2 value to int value
				return (int)(roundf(ntohs(*(UInt16*)val.bytes) / 4.0));
			}
		}
	}

	return -1;  // smc read failed
}

//------------------------------------------------------------------------------
kern_return_t smcSetMinFanRPM(char				*key,
										int				rpm,
										io_connect_t	conn)
{
	smcVal_t		val;

	strcpy(val.key, key);
	val.bytes[0] = (rpm << 2) / 256;
	val.bytes[1] = (rpm << 2) % 256;
	val.dataSize = 2;
	return smcWriteKey2(val, conn);
}

//------------------------------------------------------------------------------
kern_return_t smcSetTargetFanRPM(char				*key,
											int				rpm,
											io_connect_t	conn)
{
	smcVal_t		val;

	strcpy(val.key, key);
	val.bytes[0] = (rpm << 2) / 256;
	val.bytes[1] = (rpm << 2) % 256;
	val.dataSize = 2;
	return smcWriteKey2(val, conn);
}

//------------------------------------------------------------------------------
void sortCPUemperatureKeysByPriority() {
	int							i;
	int							j;
	smcTemperatureKeyEntry	temp;
	bool							swapped = false;

	for(i = 0; i < cpuTemperatureKeysCount - 1; i++)
	{
		swapped = false;

		// loop through the array, "falling ahead"
		for(j = 0; j < cpuTemperatureKeysCount - 1 - i; j++) {
			//printf("Items compared: [%d, %d] ",
			//	cpuTemperatureKeys[j].priority, cpuTemperatureKeys[j + 1].priority);

			// if next entry's priority is less than current priority, swap the
			// entries (i.e., "bubble up" the higher priority entry)
			if(cpuTemperatureKeys[j].priority > cpuTemperatureKeys[j+1].priority) {
				strcpy(temp.key, cpuTemperatureKeys[j].key);
				temp.priority = cpuTemperatureKeys[j].priority;
				strcpy(cpuTemperatureKeys[j].key, cpuTemperatureKeys[j + 1].key);
				cpuTemperatureKeys[j].priority = cpuTemperatureKeys[j + 1].priority;
				strcpy(cpuTemperatureKeys[j + 1].key, temp.key);
				cpuTemperatureKeys[j + 1].priority = temp.priority;
				swapped = true;
				//printf(" => swapped [%d, %d]\n", cpuTemperatureKeys[j].priority,
				//											cpuTemperatureKeys[j+1].priority);
			}
		}

		// if no entry was swapped, the array is sorted -- break the loop
		if(!swapped) break;
	}
}

//------------------------------------------------------------------------------
void sortGPUemperatureKeysByPriority() {
	int							i;
	int							j;
	smcTemperatureKeyEntry	temp;
	bool							swapped = false;

	for(i = 0; i < gpuTemperatureKeysCount - 1; i++)
	{
		swapped = false;

		// loop through the array, "falling ahead"
		for(j = 0; j < gpuTemperatureKeysCount - 1 - i; j++) {
			//printf("Items compared: [%d, %d] ",
			//	gpuTemperatureKeys[j].priority, gpuTemperatureKeys[j + 1].priority);

			// if next entry's priority is less than current priority, swap the
			// entries (i.e., "bubble up" the higher priority entry)
			if(gpuTemperatureKeys[j].priority > gpuTemperatureKeys[j+1].priority) {
				strcpy(temp.key, gpuTemperatureKeys[j].key);
				temp.priority = gpuTemperatureKeys[j].priority;
				strcpy(gpuTemperatureKeys[j].key, gpuTemperatureKeys[j + 1].key);
				gpuTemperatureKeys[j].priority = gpuTemperatureKeys[j + 1].priority;
				strcpy(gpuTemperatureKeys[j + 1].key, temp.key);
				gpuTemperatureKeys[j + 1].priority = temp.priority;
				swapped = true;
				//printf(" => swapped [%d, %d]\n", gpuTemperatureKeys[j].priority,
				//											gpuTemperatureKeys[j+1].priority);
			}
		}

		// if no entry was swapped, the array is sorted -- break the loop
		if(!swapped) break;
	}
}

//------------------------------------------------------------------------------
// search the cpuSensorDefs[] for the key
// - if it exists, return its smcSensorDefEntry
// - if it doesn't exist, return noSensorDef
smcSensorDefEntry smcFindCPUsensorDef(UInt32Char_t key)
{
	int				i;
	UInt32Char_t	cpuKey;

	for (i = 0; i < cpuSensorDefsCount; i++)
	{
		strcpy(cpuKey, cpuSensorDefs[i].key);

		if (strcmp(key, cpuKey) == 0) return cpuSensorDefs[i];
	}

	return noSensorDef;
}

//------------------------------------------------------------------------------
// search the gpuSensorDefs[] for the key
// - if it exists, return its smcSensorDefEntry
// - if it doesn't exist, return noSensorDef
smcSensorDefEntry smcFindGPUsensorDef(UInt32Char_t key)
{
	int				i;
	UInt32Char_t	gpuKey;

	for (i = 0; i < gpuSensorDefsCount; i++)
	{
		strcpy(gpuKey, gpuSensorDefs[i].key);

		if (strcmp(key, gpuKey) == 0) return gpuSensorDefs[i];
	}

	return noSensorDef;
}

//------------------------------------------------------------------------------
// search the cpuTemperatureKeys[] for the key
// - if it exists, return its smcTemperatureKeyEntry
// - if it doesn't exist, return noTemperatureKey
smcTemperatureKeyEntry findCPUtemperatureKey(UInt32Char_t key)
{
	int				i;
	UInt32Char_t	cpuKey;

	for (i = 0; i < cpuTemperatureKeysCount; i++)
	{
		strcpy(cpuKey, cpuTemperatureKeys[i].key);

		if (strcmp(key, cpuKey) == 0) return cpuTemperatureKeys[i];
	}

	return noTemperatureKey;
}

//------------------------------------------------------------------------------
// search the gpuTemperatureKeys[] for the key
// - if it exists, return its smcTemperatureKeyEntry
// - if it doesn't exist, return noTemperatureKey
smcTemperatureKeyEntry findGPUtemperatureKey(UInt32Char_t key)
{
	int				i;
	UInt32Char_t	gpuKey;

	for (i = 0; i < gpuTemperatureKeysCount; i++)
	{
		strcpy(gpuKey, gpuTemperatureKeys[i].key);

		if (strcmp(key, gpuKey) == 0) return gpuTemperatureKeys[i];
	}

	return noTemperatureKey;
}

//------------------------------------------------------------------------------
// initializes the array of prioritized CPU temperature-sensor keys
// NOTE: the array must only be initialized once!
void smcInitPrioritizedCPUtemperatureKeys(io_connect_t conn)
{
	kern_return_t			result;
	smcKeyData_t			inputStructure;
	smcKeyData_t			outputStructure;
	int						i;
	int						totalNumKeys;
	UInt32Char_t			key;
	smcSensorDefEntry		theCPUsensorDefEntry;
	smcVal_t					val;

	onlyReturnNum = 0;
	totalNumKeys = smcReadIndexCount(conn);

	for (i = 0; i < totalNumKeys; i++)
	{
		memset(&inputStructure, 0, sizeof(smcKeyData_t));
		memset(&outputStructure, 0, sizeof(smcKeyData_t));
		memset(&val, 0, sizeof(smcVal_t));

		inputStructure.data8 = SMC_CMD_READ_INDEX;
		inputStructure.data32 = i;

		result = smcCall(KERNEL_INDEX_SMC,
							  &inputStructure,
							  &outputStructure,
							  conn);

		if (result != kIOReturnSuccess) continue;

		_ultostr(key, outputStructure.key);
		theCPUsensorDefEntry = smcFindCPUsensorDef(key);
		//printf("key = '%s'  found = '%s'\n", key, theCPUsensorDefEntry.key);

		if (strcmp(key, theCPUsensorDefEntry.key) == 0) {
			if (smcGetTemperature(key, conn) < 0.0) continue;

			strcpy(cpuTemperatureKeys[cpuTemperatureKeysCount].key,
					 theCPUsensorDefEntry.key);
			cpuTemperatureKeys[cpuTemperatureKeysCount].priority =
																theCPUsensorDefEntry.priority;
			cpuTemperatureKeysCount++;
		}
	}

	sortCPUemperatureKeysByPriority();
}

//------------------------------------------------------------------------------
// initializes the array of prioritized GPU temperature-sensor keys
// NOTE: the array must only be initialized once!
void smcInitPrioritizedGPUtemperatureKeys(io_connect_t conn)
{
	kern_return_t			result;
	smcKeyData_t			inputStructure;
	smcKeyData_t			outputStructure;
	int						i;
	int						totalNumKeys;
	UInt32Char_t			key;
	smcSensorDefEntry		theGPUsensorDefEntry;
	smcVal_t					val;

	onlyReturnNum = 0;
	totalNumKeys = smcReadIndexCount(conn);

	for (i = 0; i < totalNumKeys; i++)
	{
		memset(&inputStructure, 0, sizeof(smcKeyData_t));
		memset(&outputStructure, 0, sizeof(smcKeyData_t));
		memset(&val, 0, sizeof(smcVal_t));

		inputStructure.data8 = SMC_CMD_READ_INDEX;
		inputStructure.data32 = i;

		result = smcCall(KERNEL_INDEX_SMC,
							  &inputStructure,
							  &outputStructure,
							  conn);

		if (result != kIOReturnSuccess) continue;

		_ultostr(key, outputStructure.key);
		theGPUsensorDefEntry = smcFindGPUsensorDef(key);
		//printf("key = '%s'  found = '%s'\n", key, theGPUsensorDefEntry.key);

		if (strcmp(key, theGPUsensorDefEntry.key) == 0) {
			if (smcGetTemperature(key, conn) < 0.0) continue;

			strcpy(gpuTemperatureKeys[gpuTemperatureKeysCount].key,
					 theGPUsensorDefEntry.key);
			gpuTemperatureKeys[gpuTemperatureKeysCount].priority =
																theGPUsensorDefEntry.priority;
			gpuTemperatureKeysCount++;
		}
	}

	sortGPUemperatureKeysByPriority();
}

//------------------------------------------------------------------------------
// initializes both the CPU & GPU arrays of prioritized temperature-sensor keys
// NOTE: theese arrays must only be initialized once!
void smcInitPrioritizedTemperatureKeys(io_connect_t conn)
{
	smcInitPrioritizedCPUtemperatureKeys(conn);
	smcInitPrioritizedGPUtemperatureKeys(conn);
}

//==============================================================================
#pragma mark Command line only

// Exclude command-line only code from Fan Control UI
#ifdef CMD_TOOL

//------------------------------------------------------------------------------
void smc_init(){
	smcOpen(&smc_conn);
}

void smc_close(){
	smcClose(smc_conn);
}

//------------------------------------------------------------------------------
kern_return_t smcWriteKey(smcVal_t writeVal)
{
printf("smcWriteKey(): val.key = '%s', val.bytes = '%X%X'\n", writeVal.key, writeVal.bytes[0], writeVal.bytes[1]);
	return smcWriteKey2(writeVal, smc_conn);
}

//------------------------------------------------------------------------------
kern_return_t smcPrintCPUkeys(void)
{
	kern_return_t			result;
	smcKeyData_t			inputStructure;
	smcKeyData_t			outputStructure;
	int						i;
	int						totalNumKeys;
	UInt32Char_t			key;
	smcSensorDefEntry		theCPUsensorDefEntry;
	smcVal_t					val;

	onlyReturnNum = 0;
	totalNumKeys = smcReadIndexCount(smc_conn);

	for (i = 0; i < totalNumKeys; i++)
	{
		memset(&inputStructure, 0, sizeof(smcKeyData_t));
		memset(&outputStructure, 0, sizeof(smcKeyData_t));
		memset(&val, 0, sizeof(smcVal_t));

		inputStructure.data8 = SMC_CMD_READ_INDEX;
		inputStructure.data32 = i;

		result = smcCall(KERNEL_INDEX_SMC,
							  &inputStructure,
							  &outputStructure,
							  smc_conn);

		if (result != kIOReturnSuccess) continue;

		_ultostr(key, outputStructure.key);

		theCPUsensorDefEntry = smcFindCPUsensorDef(key);
		//printf("key = '%s'  found = '%s'\n", key, theCPUsensorDefEntry.key);

		if (strcmp(key, theCPUsensorDefEntry.key) == 0) {
			smcReadKey(key, &val, smc_conn);
			printVal(val);
		}
	}

	return kIOReturnSuccess;
}

//------------------------------------------------------------------------------
kern_return_t smcPrintGPUkeys(void)
{
	kern_return_t			result;
	smcKeyData_t			inputStructure;
	smcKeyData_t			outputStructure;
	int						i;
	int						totalNumKeys;
	UInt32Char_t			key;
	smcSensorDefEntry		theGPUsensorDefEntry;
	smcVal_t					val;

	onlyReturnNum = 0;
	totalNumKeys = smcReadIndexCount(smc_conn);

	for (i = 0; i < totalNumKeys; i++)
	{
		memset(&inputStructure, 0, sizeof(smcKeyData_t));
		memset(&outputStructure, 0, sizeof(smcKeyData_t));
		memset(&val, 0, sizeof(smcVal_t));

		inputStructure.data8 = SMC_CMD_READ_INDEX;
		inputStructure.data32 = i;

		result = smcCall(KERNEL_INDEX_SMC,
							  &inputStructure,
							  &outputStructure,
							  smc_conn);

		if (result != kIOReturnSuccess) continue;

		_ultostr(key, outputStructure.key);

		theGPUsensorDefEntry = smcFindGPUsensorDef(key);
		//printf("key = '%s'  found = '%s'\n", key, theGPUsensorDefEntry.key);

		if (strcmp(key, theGPUsensorDefEntry.key) == 0) {
			smcReadKey(key, &val, smc_conn);
			printVal(val);
		}
	}

	return kIOReturnSuccess;
}

//------------------------------------------------------------------------------
kern_return_t smcPrintAll(void)
{
	kern_return_t	result;
	smcKeyData_t	inputStructure;
	smcKeyData_t	outputStructure;

	int				i;
	int				totalNumKeys;
	UInt32Char_t	key;
	smcVal_t	val;

	onlyReturnNum = 0;
	totalNumKeys = smcReadIndexCount(smc_conn);

	for (i = 0; i < totalNumKeys; i++)
	{
		memset(&inputStructure, 0, sizeof(smcKeyData_t));
		memset(&outputStructure, 0, sizeof(smcKeyData_t));
		memset(&val, 0, sizeof(smcVal_t));

		inputStructure.data8 = SMC_CMD_READ_INDEX;
		inputStructure.data32 = i;

		result = smcCall(KERNEL_INDEX_SMC,
							  &inputStructure,
							  &outputStructure,
							  smc_conn);

		if (result != kIOReturnSuccess) continue;

		_ultostr(key, outputStructure.key);
		smcReadKey(key, &val, smc_conn);
		printVal(val);
	}

	return kIOReturnSuccess;
}

//------------------------------------------------------------------------------
kern_return_t smcPrintFans(void)
{
	int				i;
	int				totalFans;
	UInt32Char_t	key;
	kern_return_t	result;
	smcVal_t			val;

	result = smcReadKey("FNum", &val, smc_conn);

	if (result != kIOReturnSuccess) return kIOReturnError;

	totalFans = _strtoul((char *)val.bytes, val.dataSize, 10);
	printf("Total fans in system: %d\n", totalFans);

	for (i = 0; i < totalFans; i++)
	{
		printf("\nFan #%d:\n", i);
		sprintf(key, "F%dID", i);
		smcReadKey(key, &val, smc_conn);
		printf(" Fan ID       : %s\n", val.bytes+4);
		sprintf(key, "F%dMx", i);
		smcReadKey(key, &val, smc_conn);
		printf(" Maximum speed: %.0f\n", _strtof(val.bytes, val.dataSize, 2));
		sprintf(key, "F%dMn", i);
		smcReadKey(key, &val, smc_conn);
		printf(" Minimum speed: %.0f\n", _strtof(val.bytes, val.dataSize, 2));
		sprintf(key, "F%dSf", i);
		smcReadKey(key, &val, smc_conn);
		printf(" Safe speed   : %.0f\n", _strtof(val.bytes, val.dataSize, 2));
		sprintf(key, "F%dTg", i);
		smcReadKey(key, &val, smc_conn);
		printf(" Target speed : %.0f\n", _strtof(val.bytes, val.dataSize, 2));
		sprintf(key, "F%dAc", i);
		smcReadKey(key, &val, smc_conn);
		printf(" Actual speed : %.0f\n", _strtof(val.bytes, val.dataSize, 2));
		smcReadKey("FS! ", &val, smc_conn);

		if ((_strtoul((char *)val.bytes, 2, 16) &
			 (1 << i)) == 0) printf(" Mode         : auto\n");
		else printf(" Mode         : forced\n");
	}

	return kIOReturnSuccess;
}

//------------------------------------------------------------------------------
void usage(char* prog)
{
	printf("Apple System Management Control (SMC) utility %s\n", VERSION);
	printf("Usage:\n");
	printf("%s [options]\n", prog);
	printf(" -1         : prioritized list of 1st-tier (CPU) temperature sensors and their values (decoded)\n");
	printf(" -2         : prioritized list of 2nd-tier (GPU, etc.) temperature sensors and their values (decoded)\n");
	printf(" -f         : list all fan info (decoded)\n");
	printf(" -g         : get fan RPM via a given key\n");
	printf(" -h or -?   : show help for the smc command\n");
	printf(" -k <key>   : key to manipulate\n");
	printf(" -l         : list all keys and their values (decoded)\n");
	printf(" -n         : only return the numeric value for -g, -r and -t\n");
	printf(" -p         : get list of 1st/2nd-tier temperature sensor keys and their priority\n");
	printf(" -r         : read the value of a given key\n");
	printf(" -s <value> : set the specified RPM for a given fan-speed key (needs privileges)\n");
	printf(" -t         : get a temperature via a given key\n");
	printf(" -v         : show version for the smc command\n");
	printf(" -w <key>   : set the specified wanted/target RPM for a given fan-speed key (needs privileges)\n");
	//printf(" -w <value> : write the specified value to a given key\n");
	printf("\n");
}

//------------------------------------------------------------------------------
int main(int	argc,
			char	*argv[])
{
	extern char		*optarg;
	kern_return_t	result;
	int				c;
	int				fanRPMresult;
	int				op = OP_NONE;
	int				rpm;
	float				theTemperature;
	UInt32Char_t	key = { 0 };
	smcVal_t			val;

	onlyReturnNum = 0;

	//while ((c = getopt(argc, argv, "fgk:lnrw:s:tvh?")) != -1)
	while ((c = getopt(argc, argv, "12fgk:lnprs:tvw:h?")) != -1)
	{
		switch(c)
		{
			case '1':
				op = OP_LIST_CPU;
				break;

			case '2':
				op = OP_LIST_GPU;
				break;

			case 'f':
				op = OP_READ_FAN_INFO;
				break;

			case 'g':
				op = OP_READ_FAN_RPM;
				break;

			case 'k':
				strncpy(key, optarg, sizeof(key));  // fix for buffer overflow
				key[sizeof(key) - 1] = '\0';
				break;

			case 'l':
				op = OP_LIST_ALL;
				break;

			case 'n':
				onlyReturnNum = 1;
				break;

			case 'p':
				op = OP_PRIORITIZED_LIST;
				break;

			case 'r':
				op = OP_READ;
				break;

			case 's':
				op = OP_SET_MIN_FAN_SPEED;
				rpm = atoi(optarg);
				break;

			case 't':
				op = OP_READ_TEMP;
				break;

			case 'w':
				op = OP_SET_TGT_FAN_SPEED;
				rpm = atoi(optarg);
				break;

			/* this can potentially be quite dangerous
			case 'w':
				op = OP_WRITE;
				{
					int i;
					char c[3];

					for (i = 0; i < strlen(optarg); i++)
					{
						sprintf(c, "%c%c", optarg[i * 2], optarg[(i * 2) + 1]);
						val.bytes[i] = (int)strtol(c, NULL, 16);
					}

					val.dataSize = i / 2;

					if ((val.dataSize * 2) != strlen(optarg)) {
						printf("Error: value is not valid\n");
						return 1;
					}
				}

				break;
			*/

			case 'v':
				printf("%s\n", VERSION);
				return 0;
				break;

			case 'h':
			case '?':
				op = OP_NONE;
				break;
		}
	}

	if (op == OP_NONE)
	{
		usage(argv[0]);
		return 1;
	}

	smc_init();

	switch(op)
	{
		case OP_LIST_CPU:
			result = smcPrintCPUkeys();

			if (result != kIOReturnSuccess) {
				printf("Error: smcPrintCPU() = %08x\n", result);
			}

			break;

		case OP_LIST_GPU:
			result = smcPrintGPUkeys();

			if (result != kIOReturnSuccess) {
				printf("Error: smcPrintGPU() = %08x\n", result);
			}

			break;

		case OP_LIST_ALL:
			result = smcPrintAll();

			if (result != kIOReturnSuccess) {
				printf("Error: smcPrintAll() = %08x\n", result);
			}

			break;

		case OP_PRIORITIZED_LIST:
			{
				int					i;
				int					thePriority;
				UInt32Char_t		theKey;
				smcSensorDefEntry	theSensorDef;

				onlyReturnNum = 1;
				smcInitPrioritizedCPUtemperatureKeys(smc_conn);

				for (i = 0; i < cpuTemperatureKeysCount; i++) {
					thePriority = theCPUtemperatureKeys[i].priority;

					if (thePriority == 0) continue;

					strcpy(theKey, theCPUtemperatureKeys[i].key);
					theSensorDef = smcFindCPUsensorDef(theKey);
					theTemperature = smcGetTemperature(theKey, smc_conn);

					if (theTemperature < 0) continue;

					printf("CPU key %s  %.3f  [priority %d]",
														theKey, theTemperature, thePriority);

					if (theSensorDef.priority != 0)  printf("  %s\n",
																				theSensorDef.name);
					else printf("\n");
				}

				printf("\n");
				smcInitPrioritizedGPUtemperatureKeys(smc_conn);

				for (i = 0; i < gpuTemperatureKeysCount; i++) {
					thePriority = theGPUtemperatureKeys[i].priority;

					if (thePriority == 0) continue;

					strcpy(theKey, theGPUtemperatureKeys[i].key);
					theSensorDef = smcFindGPUsensorDef(theKey);
					theTemperature = smcGetTemperature(theKey, smc_conn);

					if (theTemperature < 0) continue;

					printf("GPU key %s  %.3f  [priority %d]",
														theKey, theTemperature, thePriority);

					if (theSensorDef.priority != 0)  printf("  %s\n",
																				theSensorDef.name);
					else printf("\n");
				}
			}

			break;

		case OP_READ:
			if (strlen(key) > 0) {
				result = smcReadKey(key, &val, smc_conn);

				if (result != kIOReturnSuccess) {
					printf("Error: smcReadKey() = %08x\n", result);
				}
				else printVal(val);
			}
			else printf("Error: specify a key to read\n");

			break;

		case OP_READ_FAN_RPM:
			if (strlen(key) > 0) {
				fanRPMresult = smcGetFanRPM(key, smc_conn);

				if (fanRPMresult == -1) {
					printf("Error: smcGetFanRPM(%-4s) = %d (invalid key?)\n",
																				key, fanRPMresult);
				}
				else {
					if (onlyReturnNum != 1) {
						printf("Fan RPM (for key '%-4s') = %d\n", key, fanRPMresult);
					} else printf("%d\n", fanRPMresult);
				}
			}
			else printf("Error: specify a key to read\n");

			break;

		case OP_READ_FAN_INFO:
			result = smcPrintFans();

			if (result != kIOReturnSuccess) {
				printf("Error: smcPrintFans() = %08x\n", result);
			}

			break;

		case OP_READ_TEMP:
			if (strlen(key) > 0) {
				theTemperature = smcGetTemperature(key, smc_conn);

				if (theTemperature == -100.0) {
					printf("Error: smcGetTemperature(%-4s) = %.1f (invalid key?)\n",
							 key,
							 theTemperature);
				}
				else {
					if (onlyReturnNum != 1) {
						printf("Temperature (for key '%-4s') = %.3f\n",
																			key, theTemperature);
					} else printf("%.3f\n", theTemperature);
				}
			}
			else printf("Error: specify a key to read\n");

			break;

		case OP_SET_MIN_FAN_SPEED:
			if (strlen(key) > 0) {
				result = smcSetMinFanRPM(&key, rpm, smc_conn);

				if (result != kIOReturnSuccess) {
					printf("Error: smcSetMinFanRPM() = %08x\n", result);
				}
			}
			else printf("Error: specify a key to write\n");

			break;

		case OP_SET_TGT_FAN_SPEED:
			if (strlen(key) > 0) {
				result = smcSetTargetFanRPM(&key, rpm, smc_conn);

				if (result != kIOReturnSuccess) {
					printf("Error: smcSetTargetFanRPM() = %08x\n", result);
				}
			}
			else printf("Error: specify a key to write\n");

			break;

		/* this can potentially be quite dangerous
		case OP_WRITE:
			if (strlen(key) > 0) {
				sprintf(val.key, key);
				result = smcWriteKey(val);

				if (result != kIOReturnSuccess) {
					printf("Error: smcWriteKey() = %08x\n", result);
				}
			}
			else printf("Error: specify a key to write\n");

			break;
		*/
	}

	smc_close();
	return 0;
}

#endif //for #ifdef CMD_TOOL
