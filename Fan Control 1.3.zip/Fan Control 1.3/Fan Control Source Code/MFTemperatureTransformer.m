//
// Fan Control
// Copyright 2006 Lobotomo Software
// Modifications by Derman Enterprises, 2016
//
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation; either version 2
// of the License, or (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software
// Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA

#import "MFTemperatureTransformer.h"
#import "MFDefinitions.h"

@implementation MFTemperatureTransformer

// -----------------------------------------------------------------------------
+ (Class)transformedValueClass
{
	return [NSString class];
}

// -----------------------------------------------------------------------------
+ (BOOL)allowsReverseTransformation
{
	return NO;
}

// -----------------------------------------------------------------------------
// converter
- (id)transformedValue:(id)beforeObject
{
	if (MFpDebug) NSLog(@"--- TemperatureTransformer 'transformedValue' run\n");

	float degrees = [beforeObject floatValue];
	unichar c = 0x00b0;
	NSString *degreeChar = [NSString stringWithCharacters:&c length:1];

	if (showTempsAsFahrenheit) {
		degrees = (degrees / 5.0 * 9.0) + 32;  // more paranthesis cause failure!?
		return [NSString stringWithFormat:@"%.0f %@F", degrees, degreeChar];
	}

	return [NSString stringWithFormat:@"%.1f %@C", degrees, degreeChar];
}

// -----------------------------------------------------------------------------
// accessor & setter
- (BOOL)showTempsAsFahrenheit
{
	if (MFpDebug) {
		NSLog(@"--- TemperatureTransformer 'showTempsAsFahrenheit' run\n");
	}

	return showTempsAsFahrenheit;
}

- (void)setShowTempsAsFahrenheit:(BOOL)newShowTempsAsFahrenheit
{
	if (MFpDebug) {
		NSLog(@"--- TemperatureTransformer 'setShowTempsAsFahrenheit' run\n");
	}

	showTempsAsFahrenheit = newShowTempsAsFahrenheit;
}

@end
