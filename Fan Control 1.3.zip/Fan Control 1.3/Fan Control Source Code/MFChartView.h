//
// Fan Control
// Copyright 2006 Lobotomo Software
// Modifications by Derman Enterprises, 2016
//
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation; either version 2
// of the License, or (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software
// Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA

#import <Cocoa/Cocoa.h>
#import "MFDefinitions.h"

@interface MFChartView : NSView {
	// temperature threshold settings used to compute the wanted/target fan RPMs
	float lowerTempThreshold;
	float upperTempThreshold;

	// the current/highest CPU/GPU-related temperatures
	float cpuTemp;
	float gpuTemp;

	BOOL showTempsAsFahrenheit;  // whether all temps are shown in Fahrenheit

	// the number of fans in this system
	int numFans;

	// the slowest/lower-limit for fan speeds/RPMs
	fanSpeeds minFanSpeeds;

	// the maximum fan speeds/RPMs reported via smc
	fanSpeeds maxFanSpeeds;

	// the computed wanted/target fan speeds/RPMs based upon the pref settings
	fanSpeeds targetFanSpeeds;

	// the current fan speeds/RPMs
	fanSpeeds currentFanSpeeds;
}

// setters
- (void)setLowerTempThreshold:(float)newLowerTempThreshold;
- (void)setUpperTempThreshold:(float)newUpperTempThreshold;

- (void)setCPUtemp:(float)newCPUtemp;
- (void)setGPUtemp:(float)newGPUtemp;

- (void)setShowTempsAsFahrenheit:(BOOL)newShowTempsAsFahrenheit;

- (void)setNumFans:(int)newNumFans;

- (void)setTargetFanSpeeds:(fanSpeeds)newTargetFanSpeeds;

- (void)setCurrentFanSpeeds:(fanSpeeds)newcurrentFanSpeeds;

- (void)setMinFanSpeeds:(fanSpeeds)newMinFanSpeeds;
- (void)setMaxFanSpeeds:(fanSpeeds)newMaxFanSpeeds;

@end
