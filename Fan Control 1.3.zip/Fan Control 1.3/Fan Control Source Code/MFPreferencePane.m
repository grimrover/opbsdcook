//
// Fan Control
// Copyright 2006 Lobotomo Software
// Modifications by Derman Enterprises, 2016
//
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation; either version 2
// of the License, or (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software
// Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA

#import "MFChartView.h"
#import "MFPreferencePane.h"
#import "MFProtocol.h"
#import "MFTemperatureTransformer.h"

@implementation MFPreferencePane

static BOOL daemonIsWorking = YES;  // whether FanControlDaemon is working
static BOOL isShowingCelcius = YES;
static int	prevNumFans = 0;
static int	numFans = 0;
static int	minFanRPMs[3] = { -1, -1, -1 };

// -----------------------------------------------------------------------------
- (id)initWithBundle:(NSBundle *)bundle
{
	if (self = [super initWithBundle:bundle])
	{
		// if debugging pref pane &/or chart/graph code, send debug log to a file
		if (MFpDebug || MFcDebug || MFxDebug) freopen(MFpFile, "a+", stderr);

		if (MFpDebug) {
			NSLog(@"=====\n");
			NSLog(@"--- PrefPane 'init' started\n");
		}

		transformer = [MFTemperatureTransformer new];
		[NSValueTransformer
			setValueTransformer:transformer forName:@"MFTemperatureTransformer"];

		if (MFpDebug) NSLog(@"--- PrefPane 'init' completed\n");
	}

	return self;
}

// -----------------------------------------------------------------------------
- (void)dealloc
{
	if (MFpDebug) NSLog(@"--- PrefPane 'dealloc' started\n");

	[transformer release];
	[super dealloc];

	if (MFpDebug) NSLog(@"--- PrefPane 'dealloc' completed\n");
}

// -----------------------------------------------------------------------------
// update the preference-pane display
- (void)updateDisplay:(NSTimer *)aTimer
{
	if (MFpDebug) NSLog(@"--- PrefPane 'updateDisplay' started\n");

	char				fanIDs[3][32];
	char				theName[32];
	float				cpuTemp = -100.0;  // -100.0 = none/failure
	float				gpuTemp = -100.0;  // -100.0 = none/failure
	int				currFanRPMs[3] = { -1, -1, -1 };  // -1 = none/failure
	int				highestMaxFanRPM;
	int				maxFanRPMs[3] = { -1, -1, -1 };
	int				numSliderTicks;
	int				sliderMaxRPM;
	int				targetFanRPMs[3] = { -1, -1, -1 };
	BOOL				showTempsAsFahrenheit = NO;
	fanSpeeds		currentFanSpeeds;
	fanSpeeds		maxFanSpeeds;
	fanSpeeds		minFanSpeeds;
	fanSpeeds		targetFanSpeeds;
	fanNames			originalFanNames;

	currentFanSpeeds.fanRPMs[0] = -1;
	currentFanSpeeds.fanRPMs[1] = -1;
	currentFanSpeeds.fanRPMs[2] = -1;

	if (!daemonIsWorking) {
		prevNumFans = 0;
		[self awakeFromNib];  // attempt to connect to daemon
	}

	// get the # of fans, their speed(s) & current CPU/GPU-related temperatures
	@try {
		numFans = [daemon numFans];
		cpuTemp = [daemon cpuTemp];
		gpuTemp = [daemon gpuTemp];
		currentFanSpeeds = [daemon currentFanSpeeds];

		currFanRPMs[0] = currentFanSpeeds.fanRPMs[0];

		if (numFans > 1 ) currFanRPMs[1] = currentFanSpeeds.fanRPMs[1];
		if (numFans > 2 ) currFanRPMs[2] = currentFanSpeeds.fanRPMs[2];

		if ((cpuTemp == -100.0) || (gpuTemp == -100.0) || (numFans < 1) ||
			 (currFanRPMs[0] == -1) ||
			 ((numFans > 1) && (currFanRPMs[1] == -1)) ||
			 ((numFans > 2) && (currFanRPMs[2] == -1))) {
			[errorMsgField
				setStringValue:@"ERROR: either the Fan Control daemon is not running or this application is not compatible with this system"];
			daemonIsWorking = NO;

			if (MFpDebug) {
				NSLog(@"ERROR: either the Fan Control daemon is not running or this application is not compatible with this system\n");
			}
		}
	} @catch(NSException *theException) {
		[errorMsgField
			setStringValue:
			 @"ERROR: could not establish a connection to the Fan Control daemon"];
		daemonIsWorking = NO;

		if (MFpDebug) {
			NSLog(@"ERROR: could not establish a connection to the Fan Control daemon\n");
		}
	}

	if (!daemonIsWorking) {
		prevNumFans = 0;

		if (MFpDebug) NSLog(@"--- PrefPane 'updateDisplay' completed\n");

		return;
	}

	// get the current "asked for" fan speed/RPM(s)
	targetFanSpeeds = [daemon targetFanSpeeds];
	targetFanRPMs[0] = targetFanSpeeds.fanRPMs[0];

	if (numFans > 1 ) targetFanRPMs[1] = targetFanSpeeds.fanRPMs[1];
	if (numFans > 2 ) targetFanRPMs[2] = targetFanSpeeds.fanRPMs[2];

	// get the minimum fan speed/RPM(s)
	minFanSpeeds = [daemon minFanSpeeds];
	minFanRPMs[0] = minFanSpeeds.fanRPMs[0];

	if (numFans > 1 ) minFanRPMs[1] = minFanSpeeds.fanRPMs[1];
	if (numFans > 2 ) minFanRPMs[2] = minFanSpeeds.fanRPMs[2];

	// get the maximum fan speed/RPM(s)
	maxFanSpeeds = [daemon maxFanSpeeds];
	maxFanRPMs[0] = maxFanSpeeds.fanRPMs[0];

	if (numFans > 1 ) maxFanRPMs[1] = maxFanSpeeds.fanRPMs[1];
	if (numFans > 2 ) maxFanRPMs[2] = maxFanSpeeds.fanRPMs[2];

	// determine the highest maximum fan speed/RPM
	highestMaxFanRPM = maxFanRPMs[0];

	if (maxFanRPMs[1] > highestMaxFanRPM) highestMaxFanRPM = maxFanRPMs[1];
	if (maxFanRPMs[2] > highestMaxFanRPM) highestMaxFanRPM = maxFanRPMs[2];

	// determine whether temperatures are shown in degrees Fahrenheit
	showTempsAsFahrenheit = [daemon showTempsAsFahrenheit];

	// if required, adjust the upper/lower threshold slider modes (i.e., # ticks)
	if (isShowingCelcius && showTempsAsFahrenheit) {
		[lowerTempThresholdSlider setNumberOfTickMarks:55];
		[upperTempThresholdSlider setNumberOfTickMarks:73];
		isShowingCelcius = NO;
	} else if (!isShowingCelcius && !showTempsAsFahrenheit) {
		[lowerTempThresholdSlider setNumberOfTickMarks:31];
		[upperTempThresholdSlider setNumberOfTickMarks:41];
		isShowingCelcius = YES;
	}

	if (MFpDebug) {
		NSLog(@"cpuTemp = %.3f\n", cpuTemp);
		NSLog(@"gpuTemp = %.3f\n", gpuTemp);
		NSLog(@"prevNumFans = %d\n", prevNumFans);
		NSLog(@"numFans = %d\n", numFans);
		NSLog(@"targetFanRPMs[0] = %d\n", targetFanRPMs[0]);

		if (numFans > 1) NSLog(@"targetFanRPMs[1] = %d\n", targetFanRPMs[1]);
		if (numFans > 2) NSLog(@"targetFanRPMs[2] = %d\n", targetFanRPMs[2]);

		NSLog(@"currFanRPMs[0] = %d\n", currFanRPMs[0]);

		if (numFans > 1) NSLog(@"currFanRPMs[1] = %d\n", currFanRPMs[1]);
		if (numFans > 2) NSLog(@"currFanRPMs[2] = %d\n", currFanRPMs[2]);

		NSLog(@"minFanRPMs[0] = %d\n", minFanRPMs[0]);

		if (numFans > 1) NSLog(@"minFanRPMs[1] = %d\n", minFanRPMs[1]);
		if (numFans > 2) NSLog(@"minFanRPMs[2] = %d\n", minFanRPMs[2]);

		NSLog(@"maxFanRPMs[0] = %d\n", maxFanRPMs[0]);

		if (numFans > 1) NSLog(@"maxFanRPMs[1] = %d\n", maxFanRPMs[1]);
		if (numFans > 2) NSLog(@"maxFanRPMs[2] = %d\n", maxFanRPMs[2]);

		NSLog(@"highestMaxFanRPM = %d\n", highestMaxFanRPM);
		NSLog(@"showTempsAsFahrenheit = %@\n",
													showTempsAsFahrenheit ? @"Yes" : @"No");
		NSLog(@"isShowingCelcius = %@\n", isShowingCelcius ? @"Yes" : @"No");
	}

	// if the number of fans has changed, the UI needs to be re-jiggered
	if (numFans != prevNumFans) {
		// get the names/IDs of the fans
		originalFanNames = [daemon systemFanNames];
		strcpy(fanIDs[0], originalFanNames.fanName[0]);
		strcpy(fanIDs[1], originalFanNames.fanName[1]);
		strcpy(fanIDs[2], originalFanNames.fanName[2]);

		if (MFpDebug) {
			NSLog(@"fanIDs[0] = '%s'\n", fanIDs[0]);
			NSLog(@"fanIDs[1] = '%s'\n", fanIDs[1]);
			NSLog(@"fanIDs[2] = '%s'\n", fanIDs[2]);
		}

		if (MFpDebug) {
			if (numFans == 3) {
				NSLog(@"fanIDs[0] = '%s'\n", fanIDs[0]);
				NSLog(@"fanIDs[1] = '%s'\n", fanIDs[1]);
				NSLog(@"fanIDs[2] = '%s'\n", fanIDs[2]);
			} else if (numFans == 2) {
				NSLog(@"fanIDs[0] = '%s'\n", fanIDs[0]);
				NSLog(@"fanIDs[1] = '%s'\n", fanIDs[1]);
			} else NSLog(@"fanIDs[0] = '%s'\n", fanIDs[0]);
		}

		// set the label and visibility on the "Min. Fan Speed" slider items

		// when 3 fans are present, all 3 of the "Min. Fan Speed" sliders are used
		if (numFans == 3) {
			// label/show the top "Min. Fan Speed" slider
			sprintf(theName, "Min. %s Fan Speed:", fanIDs[0]);
			[fan1minRPMsliderLabelfield setStringValue:
			  [NSString stringWithCString:theName encoding:NSASCIIStringEncoding]];
			[fan1minRPMsliderLabelfield setTextColor:[NSColor // red
								colorWithDeviceRed:0.625 green:0.0 blue:0.0 alpha:1.0]];
			[fan1minRPMsliderLabelfield setHidden:NO];
			[fan1minRPMslider setHidden:NO];
			[fan1minRPMsliderValueField setHidden:NO];
			[fan1minRPMsliderUnitsField setHidden:NO];

			// label/show the middle "Min. Fan Speed" slider
			sprintf(theName, "Min. %s Fan Speed:", fanIDs[1]);
			[fan2minRPMsliderLabelfield setStringValue:
			  [NSString stringWithCString:theName encoding:NSASCIIStringEncoding]];
			[fan2minRPMsliderLabelfield setTextColor:[NSColor // blue
								colorWithDeviceRed:0.0 green:0.0 blue:0.625 alpha:1.0]];
			[fan2minRPMsliderLabelfield setHidden:NO];
			[fan2minRPMslider setHidden:NO];
			[fan2minRPMsliderValueField setHidden:NO];
			[fan2minRPMsliderUnitsField setHidden:NO];

			// label/show the bottom "Min. Fan Speed" slider
			sprintf(theName, "Min. %s Fan Speed:", fanIDs[2]);
			[fan3minRPMsliderLabelfield setStringValue:
			  [NSString stringWithCString:theName encoding:NSASCIIStringEncoding]];
			[fan3minRPMsliderLabelfield setTextColor:[NSColor // green
								colorWithDeviceRed:0.0 green:0.625 blue:0.0 alpha:1.0]];
			[fan3minRPMsliderLabelfield setHidden:NO];
			[fan3minRPMslider setHidden:NO];
			[fan3minRPMsliderValueField setHidden:NO];
			[fan3minRPMsliderUnitsField setHidden:NO];
		}

		// when 2 fans are present, the bottom 2 "Min. Fan Speed" sliders are used
		if (numFans == 2) {
			// hide the top "Min. Fan Speed" slider
			[fan1minRPMsliderLabelfield setHidden:YES];
			[fan1minRPMslider setHidden:YES];
			[fan1minRPMsliderValueField setHidden:YES];
			[fan1minRPMsliderUnitsField setHidden:YES];

			// label/show the middle "Min. Fan Speed" slider
			sprintf(theName, "Min. %s Fan Speed:", fanIDs[0]);
			[fan2minRPMsliderLabelfield setStringValue:
			  [NSString stringWithCString:theName encoding:NSASCIIStringEncoding]];
			[fan2minRPMsliderLabelfield setTextColor:[NSColor // red
								colorWithDeviceRed:0.625 green:0.0 blue:0.0 alpha:1.0]];
			[fan2minRPMsliderLabelfield setHidden:NO];
			[fan2minRPMslider setHidden:NO];
			[fan2minRPMsliderValueField setHidden:NO];
			[fan2minRPMsliderUnitsField setHidden:NO];

			// label/show the bottom "Min. Fan Speed" slider
			sprintf(theName, "Min. %s Fan Speed:", fanIDs[1]);
			[fan3minRPMsliderLabelfield setStringValue:
			  [NSString stringWithCString:theName encoding:NSASCIIStringEncoding]];
			[fan3minRPMsliderLabelfield setTextColor:[NSColor // blue
								colorWithDeviceRed:0.0 green:0.0 blue:0.625 alpha:1.0]];
			[fan3minRPMsliderLabelfield setHidden:NO];
			[fan3minRPMslider setHidden:NO];
			[fan3minRPMsliderValueField setHidden:NO];
			[fan3minRPMsliderUnitsField setHidden:NO];
		}

		// when only 1 fan is present, the middle "Min. Fan Speed" slider is used
		if (numFans == 1) {
			// hide the top "Min. Fan Speed" slider
			[fan1minRPMsliderLabelfield setHidden:YES];
			[fan1minRPMslider setHidden:YES];
			[fan1minRPMsliderValueField setHidden:YES];
			[fan1minRPMsliderUnitsField setHidden:YES];

			// label/show the middle "Min. Fan Speed" slider
			sprintf(theName, "Min. %s Fan Speed:", fanIDs[0]);
			[fan2minRPMsliderLabelfield setStringValue:
			  [NSString stringWithCString:theName encoding:NSASCIIStringEncoding]];
			[fan2minRPMsliderLabelfield setTextColor:[NSColor blackColor]];
			[fan2minRPMsliderLabelfield setHidden:NO];
			[fan2minRPMslider setHidden:NO];
			//[fan2minRPMslider setEnabled:YES];
			[fan2minRPMsliderValueField setHidden:NO];
			[fan2minRPMsliderUnitsField setHidden:NO];

			// hide the bottom "Min. Fan Speed" slider
			[fan3minRPMsliderLabelfield setHidden:YES];
			[fan3minRPMslider setHidden:YES];
			[fan3minRPMsliderValueField setHidden:YES];
			[fan3minRPMsliderUnitsField setHidden:YES];
		}

		// set the label and visibility on the "Fan Speeds" info items

		// when 3 fans are present, all 3 of the "Fan Speeds" info rows are used
		if (numFans == 3) {
			// label/show the top "Fan Speeds" info item
			sprintf(theName, "%s Fan:", fanIDs[0]);
			[fan1RPMlabelField setStringValue:
			  [NSString stringWithCString:theName encoding:NSASCIIStringEncoding]];
			[fan1RPMlabelField setTextColor:[NSColor // red
								colorWithDeviceRed:0.625 green:0.0 blue:0.0 alpha:1.0]];

			// label/show the middle "Fan Speeds" info item
			sprintf(theName, "%s Fan:", fanIDs[1]);
			[fan2RPMlabelField setStringValue:
			  [NSString stringWithCString:theName encoding:NSASCIIStringEncoding]];
			[fan2RPMlabelField setTextColor:[NSColor // blue
								colorWithDeviceRed:0.0 green:0.0 blue:0.625 alpha:1.0]];
			[fan2RPMlabelField setHidden:NO];
			[fan2maxRPMfield setHidden:NO];
			[fan2slash1Field setHidden:NO];
			[fan2targetRPMfield setHidden:NO];
			[fan2slash2Field setHidden:NO];
			[fan2percentField setHidden:NO];
			[fan2percentCharField setHidden:NO];
			[fan2currRPMfield setHidden:NO];
			[fan2unitsField setHidden:NO];

			// label/show the bottom "Fan Speeds" info item
			sprintf(theName, "%s Fan:", fanIDs[2]);
			[fan3RPMlabelField setStringValue:
			  [NSString stringWithCString:theName encoding:NSASCIIStringEncoding]];
			[fan3RPMlabelField setTextColor:[NSColor // green
								colorWithDeviceRed:0.0 green:0.625 blue:0.0 alpha:1.0]];
			[fan3RPMlabelField setHidden:NO];
			[fan3maxRPMfield setHidden:NO];
			[fan3slash1Field setHidden:NO];
			[fan3targetRPMfield setHidden:NO];
			[fan3slash2Field setHidden:NO];
			[fan3percentField setHidden:NO];
			[fan3percentCharField setHidden:NO];
			[fan3currRPMfield setHidden:NO];
			[fan3unitsField setHidden:NO];
		}

		// when 2 fans are present, the bottom 2 "Fan Speeds" info rows are used
		if (numFans == 2) {
			// label/show the top "Fan Speeds" info item
			sprintf(theName, "%s Fan:", fanIDs[0]);
			[fan1RPMlabelField setStringValue:
			  [NSString stringWithCString:theName encoding:NSASCIIStringEncoding]];
			[fan1RPMlabelField setTextColor:[NSColor // red
								colorWithDeviceRed:0.625 green:0.0 blue:0.0 alpha:1.0]];

			// label/show the middle "Fan Speeds" info item
			sprintf(theName, "%s Fan:", fanIDs[1]);
			[fan2RPMlabelField setStringValue:
			  [NSString stringWithCString:theName encoding:NSASCIIStringEncoding]];
			[fan2RPMlabelField setTextColor:[NSColor // blue
								colorWithDeviceRed:0.0 green:0.0 blue:0.625 alpha:1.0]];
			[fan2RPMlabelField setHidden:NO];
			[fan2maxRPMfield setHidden:NO];
			[fan2slash1Field setHidden:NO];
			[fan2targetRPMfield setHidden:NO];
			[fan2slash2Field setHidden:NO];
			[fan2percentField setHidden:NO];
			[fan2percentCharField setHidden:NO];
			[fan2currRPMfield setHidden:NO];
			[fan2unitsField setHidden:NO];

			// hide the bottom "Fan Speeds" info item
			[fan3RPMlabelField setHidden:YES];
			[fan3maxRPMfield setHidden:YES];
			[fan3slash1Field setHidden:YES];
			[fan3targetRPMfield setHidden:YES];
			[fan3slash2Field setHidden:YES];
			[fan3percentField setHidden:YES];
			[fan3percentCharField setHidden:YES];
			[fan3currRPMfield setHidden:YES];
			[fan3unitsField setHidden:YES];
		}

		// when only 1 fan is present, the top "Fan Speeds" info row is used
		if (numFans == 1) {
			// label/show the top "Fan Speeds" info item
			sprintf(theName, "%s Fan:", fanIDs[0]);
			[fan1RPMlabelField setStringValue:
			  [NSString stringWithCString:theName encoding:NSASCIIStringEncoding]];
			[fan1RPMlabelField setTextColor:[NSColor blackColor]];

			// hide the middle "Fan Speeds" info item
			[fan2RPMlabelField setHidden:YES];
			[fan2maxRPMfield setHidden:YES];
			[fan2slash1Field setHidden:YES];
			[fan2targetRPMfield setHidden:YES];
			[fan2slash2Field setHidden:YES];
			[fan2percentField setHidden:YES];
			[fan2percentCharField setHidden:YES];
			[fan2currRPMfield setHidden:YES];
			[fan2unitsField setHidden:YES];

			// hide the bottom "Fan Speeds" info item
			[fan3RPMlabelField setHidden:YES];
			[fan3maxRPMfield setHidden:YES];
			[fan3slash1Field setHidden:YES];
			[fan3targetRPMfield setHidden:YES];
			[fan3slash2Field setHidden:YES];
			[fan3percentField setHidden:YES];
			[fan3percentCharField setHidden:YES];
			[fan3currRPMfield setHidden:YES];
			[fan3unitsField setHidden:YES];
		}

		// compute/set the "Min. Fan Speed" sliders' max values & number of ticks

		// set max value and # of ticks on top-most slider -- this slider is used
		// only when there are 3 fans and it controls the first fan (0-index)
		if (numFans == 3) {
			sliderMaxRPM =
					((maxFanRPMs[0] / 100) - 1) * 100;  // the first 100-RPM < maxRPM

			// ticks: if max RPM > 2500, 100-RPM intervals else 50-RPM intervals
			if (sliderMaxRPM > 2500) {
				numSliderTicks = ((sliderMaxRPM - MFminFanRPM) / 100) + 1;
			} else numSliderTicks = ((sliderMaxRPM - MFminFanRPM) / 50) + 1;

			[fan1minRPMslider setMaxValue:sliderMaxRPM];
			[fan1minRPMslider setNumberOfTickMarks:numSliderTicks];

			if (MFpDebug) {
				NSLog(@"--- for %s slider\n", fanIDs[0]);
				NSLog(@"sliderMaxRPM = %d\n", sliderMaxRPM);
				NSLog(@"numSliderTicks = %d\n", numSliderTicks);
			}
		}

		// set max value and # of ticks on middle slider -- this slider is used
		// when there are 1, 2 or 3 fans:
		// - for 1 or 2 fans, it controls the first fan (0-index)
		// - for 3 fans, it controls the second fan (1-index)
		//if ((numFans == 1) || (numFans == 2) || (numFans == 3)) {
			if (numFans == 3) {
				sliderMaxRPM =
					((maxFanRPMs[1] / 100) - 1) * 100;  // the first 100-RPM < maxRPM
			} else {
				sliderMaxRPM =
					((maxFanRPMs[0] / 100) - 1) * 100;  // the first 100-RPM < maxRPM
			}

			// ticks: if max RPM > 2500, 100-RPM intervals else 50-RPM intervals
			if (sliderMaxRPM > 2500) {
				numSliderTicks = ((sliderMaxRPM - MFminFanRPM) / 100) + 1;
			} else numSliderTicks = ((sliderMaxRPM - MFminFanRPM) / 50) + 1;

			[fan2minRPMslider setMaxValue:sliderMaxRPM];
			[fan2minRPMslider setNumberOfTickMarks:numSliderTicks];

			if (MFpDebug) {
				NSLog(@"--- for %s slider\n", fanIDs[1]);
				NSLog(@"sliderMaxRPM = %d\n", sliderMaxRPM);
				NSLog(@"numSliderTicks = %d\n", numSliderTicks);
			}
		//}

		// set max value and # of ticks on bottom slider -- this slider is used
		// only when there are 2 or 3 fans:
		// - for 2 fans, it controls the second fan (1-index)
		// - for 3 fans, it controls the third fan (2-index)
		if ((numFans == 2) || (numFans == 3)) {
			if (numFans == 2) {
				sliderMaxRPM =
					((maxFanRPMs[1] / 100) - 1) * 100;  // the first 100-RPM < maxRPM
			} else {
				sliderMaxRPM =
					((maxFanRPMs[2] / 100) - 1) * 100;  // the first 100-RPM < maxRPM
			}

			// ticks: if max RPM > 2500, 100-RPM intervals else 50-RPM intervals
			if (sliderMaxRPM > 2500) {
				numSliderTicks = ((sliderMaxRPM - MFminFanRPM) / 100) + 1;
			} else numSliderTicks = ((sliderMaxRPM - MFminFanRPM) / 50) + 1;

			[fan3minRPMslider setMaxValue:sliderMaxRPM];
			[fan3minRPMslider setNumberOfTickMarks:numSliderTicks];

			// to set the current slider value, you'd also do ...
			//fan3minRPMslider.doubleValue = 1500.0;
			//then maybe [self setMinFanSpeeds ...

			if (MFpDebug) {
				NSLog(@"--- for %s slider\n", fanIDs[2]);
				NSLog(@"sliderMaxRPM = %d\n", sliderMaxRPM);
				NSLog(@"numSliderTicks = %d\n", numSliderTicks);
			}
		}

		prevNumFans = numFans;

		// force a display update to get things updated after a daemon failure
		[self updateDisplay:nil];
		[fileOwnerController setContent:nil];
		[fileOwnerController setContent:self];

		if (MFpDebug) {
			NSLog(@"prevNumFans = %d\n", prevNumFans);
		}
	}

	// update the "Fan Speeds" fields containing the current & target fan speeds

	// top fan-speed info row
	[fan1maxRPMfield setIntValue:maxFanRPMs[0]];
	[fan1targetRPMfield setIntValue:targetFanRPMs[0]];
	[fan1percentField setIntValue:
					roundf(((float)currFanRPMs[0] / (float)maxFanRPMs[0]) * 100.0)];
	[fan1currRPMfield setIntValue:currFanRPMs[0]];

	// middle fan-speed info row
	if (numFans > 1) {
		[fan2maxRPMfield setIntValue:maxFanRPMs[1]];
		[fan2targetRPMfield setIntValue:targetFanRPMs[1]];
		[fan2percentField setIntValue:
					roundf(((float)currFanRPMs[1] / (float)maxFanRPMs[1]) * 100.0)];
		[fan2currRPMfield setIntValue:currFanRPMs[1]];
	}

	// bottom fan-speed info row
	if (numFans > 2) {
		[fan3maxRPMfield setIntValue:maxFanRPMs[2]];
		[fan3targetRPMfield setIntValue:targetFanRPMs[2]];
		[fan3percentField setIntValue:
					roundf(((float)currFanRPMs[2] / (float)maxFanRPMs[2]) * 100.0)];
		[fan3currRPMfield setIntValue:currFanRPMs[2]];
	}

	// update the fields containing the current CPU/GPU-related temperatures
	[cpuTempField setStringValue:
				[transformer transformedValue:[NSNumber numberWithFloat:cpuTemp]]];
	[gpuTempField setStringValue:
				[transformer transformedValue:[NSNumber numberWithFloat:gpuTemp]]];

	// update the graph/chart info
	[chartView setLowerTempThreshold:[daemon lowerTempThreshold]];
	[chartView setUpperTempThreshold:[daemon upperTempThreshold]];
	[chartView setShowTempsAsFahrenheit:showTempsAsFahrenheit];
	[chartView setNumFans:numFans];
	[chartView setMinFanSpeeds:minFanSpeeds];
	[chartView setMaxFanSpeeds:maxFanSpeeds];
	[chartView setTargetFanSpeeds:targetFanSpeeds];
	[chartView setCurrentFanSpeeds:currentFanSpeeds];
	[chartView setCPUtemp:cpuTemp];
	[chartView setGPUtemp:gpuTemp];

	if (MFpDebug) NSLog(@"--- PrefPane 'updateDisplay' completed\n");
}

// -----------------------------------------------------------------------------
- (void)awakeFromNib
{
	if (MFpDebug) NSLog(@"--- PrefPane 'awakeFromNib' started\n");

	daemonIsWorking = YES;

	// clear the message in the error-message field
	[errorMsgField setStringValue:@""];

	// connect to Fan Control daemon
	@try {
		NSConnection *connection =
					[NSConnection
						connectionWithRegisteredName:MFDaemonRegisteredName host:nil];
		daemon = [[connection rootProxy] retain];
		[(id)daemon setProtocolForProxy:@protocol(MFProtocol)];
	} @catch(NSException *theException) {
		[errorMsgField
			setStringValue:
			 @"ERROR: could not establish a connection to the Fan Control daemon"];
		daemonIsWorking = NO;

		if (MFpDebug) {
			NSLog(@"ERROR: could not establish a connection to the Fan Control daemon\n");
			NSLog(@"--- PrefPane 'awakeFromNib' completed\n");
		}

		return;
	}

	// set Celcius/Fahrenheit converter mode
	[transformer setShowTempsAsFahrenheit:[daemon showTempsAsFahrenheit]];

	// connect to object controller
	[fileOwnerController setContent:self];

	if (MFpDebug) NSLog(@"--- PrefPane 'awakeFromNib' completed\n");
}

// -----------------------------------------------------------------------------
// message sent before preference pane is displayed (starts udpate the timer)
- (void)willSelect
{
	if (MFpDebug) NSLog(@"--- PrefPane 'willSelect' started\n");

	// update display immediately, then every MFupdateInterval seconds
	[self updateDisplay:nil];
	timer = [NSTimer scheduledTimerWithTimeInterval:MFupdateInterval
						  target:self selector:@selector(updateDisplay:)
						  userInfo:nil repeats:YES];

	if (MFpDebug) NSLog(@"--- PrefPane 'willSelect' completed\n");
}

// -----------------------------------------------------------------------------
// message sent after preference pane is ordered out
- (void)didUnselect
{
	if (MFpDebug) NSLog(@"--- PrefPane 'didUnselect' started\n");

	// stop updates
	[timer invalidate];
	timer = nil;

	if (MFpDebug) NSLog(@"--- PrefPane 'didUnselect' completed\n");
}

//==============================================================================
// getters and setters

// -----------------------------------------------------------------------------
- (float)lowerTempThreshold
{
	if (MFpDebug) NSLog(@"--- PrefPane 'lowerTempThreshold' run\n");

	if (!daemonIsWorking) return -100.0;

	return [daemon lowerTempThreshold];
}

- (void)setLowerTempThreshold:(float)newLowerTempThreshold
{
	if (MFpDebug) NSLog(@"--- PrefPane 'setLowerTempThreshold' run\n");

	[chartView setLowerTempThreshold:newLowerTempThreshold];

	if (daemonIsWorking) {
		[daemon setLowerTempThreshold:newLowerTempThreshold];
	}
}

// -----------------------------------------------------------------------------
- (float)upperTempThreshold
{
	if (MFpDebug) NSLog(@"--- PrefPane 'upperTempThreshold' run\n");

	if (!daemonIsWorking) return -100.0;

	return [daemon upperTempThreshold];
}

- (void)setUpperTempThreshold:(float)newUpperTempThreshold
{
	if (MFpDebug) NSLog(@"--- PrefPane 'setUpperTempThreshold' run\n");

	[chartView setUpperTempThreshold:newUpperTempThreshold];

	if (daemonIsWorking) {
		[daemon setUpperTempThreshold:newUpperTempThreshold];
	}
}

// -----------------------------------------------------------------------------
- (float)cpuTemp
{
	if (MFpDebug) NSLog(@"--- PrefPane 'cpuTemp' run\n");

	if (!daemonIsWorking) return -100.0;

	return [daemon cpuTemp];
}

- (float)gpuTemp
{
	if (MFpDebug) NSLog(@"--- PrefPane 'cpuTemp' run\n");

	if (!daemonIsWorking) return -100.0;

	return [daemon gpuTemp];
}

// -----------------------------------------------------------------------------
- (BOOL)showTempsAsFahrenheit
{
	if (MFpDebug) NSLog(@"--- PrefPane 'showTempsAsFahrenheit' run\n");

	if (!daemonIsWorking) return NO;

	return [daemon showTempsAsFahrenheit];
}

- (void)setShowTempsAsFahrenheit:(BOOL)newShowTempsAsFahrenheit
{
	if (MFpDebug) NSLog(@"--- PrefPane 'setShowTempsAsFahrenheit' run\n");

	if (daemonIsWorking) {
		[daemon setShowTempsAsFahrenheit:newShowTempsAsFahrenheit];
	}

	[transformer setShowTempsAsFahrenheit:newShowTempsAsFahrenheit];

	// force display update
	[self updateDisplay:nil];

	[fileOwnerController setContent:nil];
	[fileOwnerController setContent:self];
}

// -----------------------------------------------------------------------------
- (fanSpeeds)minFanSpeeds
{
	if (MFpDebug) NSLog(@"--- PrefPane 'minFanSpeeds' run\n");

	if (!daemonIsWorking) {
		fanSpeeds	minFanSpeeds;

		minFanSpeeds.fanRPMs[0] = minFanRPMs[0];
		minFanSpeeds.fanRPMs[1] = minFanRPMs[1];
		minFanSpeeds.fanRPMs[2] = minFanRPMs[2];

		return minFanSpeeds;
	}

	return [daemon minFanSpeeds];
}

- (void)setMinFanSpeeds:(fanSpeeds)newMinFanSpeeds
{
	if (MFpDebug) NSLog(@"--- PrefPane 'setMinFanSpeeds' run\n");

	[chartView setMinFanSpeeds:newMinFanSpeeds];

	if (daemonIsWorking) [daemon setMinFanSpeeds:newMinFanSpeeds];
}

// -----------------------------------------------------------------------------
// the top "Min. Fan Speed" slider is only used when there are 3 fans and it
// controls the first fan (0-index)
- (int)fan1minRPM
{
	if (MFpDebug) NSLog(@"--- PrefPane 'fan1minRPM' run\n");

	if (!daemonIsWorking) return minFanRPMs[0];

	fanSpeeds	minFanSpeeds = [daemon minFanSpeeds];

	return minFanSpeeds.fanRPMs[0];
}

- (void)setFan1minRPM:(int)newFan1minRPM
{
	if (MFpDebug) NSLog(@"--- PrefPane 'setFan1minRPM' run\n");

	fanSpeeds	minFanSpeeds = [daemon minFanSpeeds];

	minFanSpeeds.fanRPMs[0] = newFan1minRPM;

	[self setMinFanSpeeds:minFanSpeeds];
}

// -----------------------------------------------------------------------------
// the middle "Min. Fan Speed" slider is used when there are 1, 2 or 3 fans
// - for 1 or 2 fans, it controls the first fan (0-index)
// - for 3 fans, it controls the second fan (1-index)
- (int)fan2minRPM
{
	if (MFpDebug) NSLog(@"--- PrefPane 'fan2minRPM' run\n");

	if (!daemonIsWorking) {
		if (numFans < 3) return minFanRPMs[0];  // there are 1 or 2 fans

		return minFanRPMs[1];  // there's 3 fans
	}

	fanSpeeds	minFanSpeeds = [daemon minFanSpeeds];

	if (numFans < 3) return minFanSpeeds.fanRPMs[0];  // there are 1 or 2 fans

	return minFanSpeeds.fanRPMs[1];  // there's 3 fans
}

- (void)setFan2minRPM:(int)newFan2minRPM
{
	if (MFpDebug) NSLog(@"--- PrefPane 'setFan2minRPM' run\n");

	fanSpeeds	minFanSpeeds = [daemon minFanSpeeds];

	if (numFans < 3) minFanSpeeds.fanRPMs[0] = newFan2minRPM;
	else minFanSpeeds.fanRPMs[1] = newFan2minRPM;  // there are 3 fans

	[self setMinFanSpeeds:minFanSpeeds];
}

// -----------------------------------------------------------------------------
// the bottom "Min. Fan Speed" slider is used when there are 2 or 3 fans
// - for 2 fans, it controls the second fan (1-index)
// - for 3 fans, it controls the third fan (2-index)
- (int)fan3minRPM
{
	if (MFpDebug) NSLog(@"--- PrefPane 'fan3minRPM' run\n");

	if (!daemonIsWorking) {
		if (numFans == 2) return minFanRPMs[1];

		return minFanRPMs[2];  // there are 3 fans
	}

	fanSpeeds	minFanSpeeds = [daemon minFanSpeeds];

	if (numFans == 2) return minFanSpeeds.fanRPMs[1];

	return minFanSpeeds.fanRPMs[2];  // there are 3 fans
}

- (void)setFan3minRPM:(int)newFan3minRPM
{
	if (MFpDebug) NSLog(@"--- PrefPane 'setFan3minRPM' run\n");

	fanSpeeds	minFanSpeeds = [daemon minFanSpeeds];

	if (numFans == 2) minFanSpeeds.fanRPMs[1] = newFan3minRPM;
	else minFanSpeeds.fanRPMs[2] = newFan3minRPM;  // there are 3 fans

	[self setMinFanSpeeds:minFanSpeeds];
}

@end
