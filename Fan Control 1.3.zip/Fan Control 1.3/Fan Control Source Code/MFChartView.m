//
// Fan Control
// Copyright 2006 Lobotomo Software
// Modifications by Derman Enterprises, 2016
//
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation; either version 2
// of the License, or (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software
// Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA

#import "MFChartView.h"

#define MFfirstFtempLabel	70.0  // first Fahrenheit temp label shown on graph
#define MFlastFtempLabel	210.0  // last Fahrenheit temp label shown on graph
#define MFgraphMinTemp	20.0  // minimum Celcius temperature shown on graph
#define MFgraphMaxTemp	100.0  // maximum Celcius temperature shown on graph
#define MFgraphMinRPM	1000  // minimum RPM shown on graph

static int chartHeight;
static int chartWidth;
static float pixelsPerDegree;  // in degrees Celcius
static float pixelsPerRPM;
static int graphMaxRPM;
static NSPoint graphOrigin;

@implementation MFChartView

// -----------------------------------------------------------------------------
- (id)initWithFrame:(NSRect)frame
{
	if (self = [super initWithFrame:frame])
	{
		if (MFcDebug) NSLog(@"--- ChartView 'init' started\n");

		chartWidth = [self frame].size.width - 12;  // room for highest temp label
		chartHeight = [self frame].size.height - 6;  // room for highest TPM label

		if (MFcDebug) {
			NSLog(@"chartWidth = %d\n", chartWidth);
			NSLog(@"chartHeight = %d\n", chartHeight);
			NSLog(@"--- ChartView 'init' completed\n");
		}
	}

	return self;
}

// -----------------------------------------------------------------------------
// compute a point on the graph (i.e., inside the labelled/axis-bordered area)
// for a given temperature/RPM pair
- (NSPoint)pointOnGraph:(float)theTemp theRPM:(int)theRPM
{
	NSPoint coordinate = graphOrigin; //[self bounds].origin;
	coordinate.x += roundf((theTemp - MFgraphMinTemp) * pixelsPerDegree);
	coordinate.y += roundf((theRPM - MFgraphMinRPM) * pixelsPerRPM);
	return coordinate;
}

// -----------------------------------------------------------------------------
- (void)drawRect:(NSRect)rect
{
	if (MFcDebug) NSLog(@"--- ChartView 'drawRect' started\n");

	CGFloat	slopedLineDash[2] = { 7.5, 7.5};
	CGFloat	xLineDash[2] = { 5, 5};
	float		highTemp;
	float		offsetLowerTempThreshold;
	int 		currFanRPMs[3] = { 0, 0, 0 };  // 0 = unused
	int		maxFanRPMs[3] = { 0, 0, 0 };  // 0 = unused
	int		minFanRPMs[3] = { 0, 0, 0 };  // 0 = unused
	int		targetFanRPMs[3] = { 0, 0, 0 };  // 0 = unused

	int axisYlabelWidth = 32;  // width of Y-axis labels area, in pixels
	int axisXlabelHeight = 14;  // height of X-axis labels area, in pixels

	// set the graphing-area's point of origin -- it's the lower-left corner of
	// the overall chart area, minus the "indent" required to allow graph labels
	graphOrigin = NSMakePoint(axisYlabelWidth, axisXlabelHeight);

	// load shorter-named arrays to shorten the name lengths <lazy typist/reader>
	currFanRPMs[0] =  currentFanSpeeds.fanRPMs[0];
	currFanRPMs[1] =  currentFanSpeeds.fanRPMs[1];
	currFanRPMs[2] =  currentFanSpeeds.fanRPMs[2];
	maxFanRPMs[0] =  maxFanSpeeds.fanRPMs[0];
	maxFanRPMs[1] =  maxFanSpeeds.fanRPMs[1];
	maxFanRPMs[2] =  maxFanSpeeds.fanRPMs[2];
	minFanRPMs[0] =  minFanSpeeds.fanRPMs[0];
	minFanRPMs[1] =  minFanSpeeds.fanRPMs[1];
	minFanRPMs[2] =  minFanSpeeds.fanRPMs[2];
	targetFanRPMs[0] =  targetFanSpeeds.fanRPMs[0];
	targetFanRPMs[1] =  targetFanSpeeds.fanRPMs[1];
	targetFanRPMs[2] =  targetFanSpeeds.fanRPMs[2];

	// determine the maximum fan speed/RPM that needs to be on the graph
	graphMaxRPM = maxFanRPMs[0];

	if ((numFans > 1) &&
		 (maxFanRPMs[1] > graphMaxRPM)) graphMaxRPM = maxFanRPMs[1];
	if ((numFans > 2) &&
		 (maxFanRPMs[2] > graphMaxRPM)) graphMaxRPM = maxFanRPMs[2];

	// determine the highest/fan-controlling temperature
	if (cpuTemp > gpuTemp) highTemp = cpuTemp; else highTemp = gpuTemp;

	//graphMaxRPM = graphMaxRPM + 50;  // add a bit to ensure gaphing lines show

	// determine the pixel to degree (Celcius) and RPM ratios
	pixelsPerDegree =
				(chartWidth - axisYlabelWidth) / (MFgraphMaxTemp - MFgraphMinTemp);
	pixelsPerRPM =
	 	 (chartHeight - axisXlabelHeight) / (float)(graphMaxRPM - MFgraphMinRPM);

	if (MFcDebug) {
		NSLog(@"graphMaxRPM = %d\n", graphMaxRPM);
		NSLog(@"axisXlabelHeight = %d\n", axisXlabelHeight);
		NSLog(@"axisYlabelWidth = %d\n", axisYlabelWidth);
		NSLog(@"pixelsPerDegree = %.7f\n", pixelsPerDegree);
		NSLog(@"pixelsPerRPM = %.7f\n", pixelsPerRPM);
		NSLog(@"showTempsAsFahrenheit = %@\n",
													showTempsAsFahrenheit ? @"Yes" : @"No");
	}

	// define various chart-drawing values
	NSArray *subViews = [self subviews];
	NSFont *font = [NSFont userFontOfSize:10];
	NSBezierPath *path;
	float axisXstart = graphOrigin.x;  // X-axis is indented to allow for labels
	float axisYstart = graphOrigin.y;  // Y-axis is indented to allow for labels
	int graphWidth = chartWidth - axisXstart;
	int graphHeight = chartHeight - axisYstart;

	if (MFcDebug) {
		NSLog(@"axisXstart = %.7f\n", axisXstart);
		NSLog(@"axisYstart = %.7f\n", axisYstart);
		NSLog(@"graphWidth = %d\n", graphWidth);
		NSLog(@"graphHeight = %d\n", graphHeight);
	}

	// perform pre-drawing cleanup
	for (int j = 0; j < [subViews count];)
	{
		[[subViews objectAtIndex:0] removeFromSuperview];
	}

	// draw chart's background and border
	//[[NSColor whiteColor] set];
	//NSRectFill([self bounds]);
	//[[NSColor blackColor] set];
	//path = [NSBezierPath bezierPathWithRect:[self bounds]];
	//[path stroke];

	// define various label-graphing values
	int labelValue;
	int numLabels;
	int numMarkers;
	int textHeight;
	int textWidth;
	float axisPosition;
	float firstLabelOffset;  // offset of first label from start of axis
	float lastLabelOffset;  // offset of last label from end of axis
	float interLabelSpace;
	float firstMarkerOffset;  // offset of first marker from start of axis
	float lastMarkerOffset;  // offset of last marker from end of axis
	float interMarkerSpace;

	// draw the graph's X-axis
	path = [NSBezierPath bezierPath];
	//[path moveToPoint:graphOrigin];
	[path moveToPoint:NSMakePoint(graphOrigin.x - 3, graphOrigin.y)];
	[path lineToPoint:NSMakePoint(chartWidth, axisXlabelHeight)];
	[[NSColor blackColor] set];
	[path setLineWidth: 1.4];
	[path stroke];

	// draw the graph's Y-axis
	path = [NSBezierPath bezierPath];
	//[path moveToPoint:graphOrigin];
	[path moveToPoint:NSMakePoint(graphOrigin.x, graphOrigin.y - 3)];
	[path lineToPoint:NSMakePoint(axisYlabelWidth, chartHeight)];
	[[NSColor blackColor] set];
	[path setLineWidth: 1.4];
	[path stroke];

	// draw the graph's X-axis/temperature markers/ticks
	if (showTempsAsFahrenheit) {
		numMarkers = 15;  // 15x Fahrenheit markers at 10-degree intervals

		// compute the Fahrenheit-scale marker offsets
		// (assumes MFgraphMinTemp is < MFfirstFtempLabel in degrees Celcius and
		//  MFlastFtempLabel in degrees Celcius < MFgraphMaxTemp)
		firstMarkerOffset =
			(((MFfirstFtempLabel - 32.0) * (5.0 / 9.0)) // i.e., in degrees Celcius
														- MFgraphMinTemp) * pixelsPerDegree;
		lastMarkerOffset = (MFgraphMaxTemp -
			((MFlastFtempLabel - 32.0) * (5.0 / 9.0))) // i.e., in degrees Celcius
																				* pixelsPerDegree;
	} else {
		numMarkers = 17;  // 17x Celcius markers at 5-degree intervals
		firstMarkerOffset = 0.0;
		lastMarkerOffset = 0.0;
	}

	interMarkerSpace =
				(chartWidth - (axisXstart + firstMarkerOffset + lastMarkerOffset)) /
																					(numMarkers - 1);

	if (MFcDebug) {
		NSLog(@"... for X-axis/temperature markers/ticks\n");
		NSLog(@"numMarkers = %d\n", numMarkers);
		NSLog(@"firstMarkerOffset = %.7f\n", firstMarkerOffset);
		NSLog(@"lastMarkerOffset = %.7f\n", lastMarkerOffset);
		NSLog(@"interMarkerSpace = %.7f\n", interMarkerSpace);
	}

	for (int i = 0; i < numMarkers; i++)
	{
		axisPosition = axisXstart - (textWidth / 2) + firstMarkerOffset +
																			(i * interMarkerSpace);
		path = [NSBezierPath bezierPath];
		[path moveToPoint:NSMakePoint(axisPosition, axisYstart - 3)];
		[path lineToPoint:NSMakePoint(axisPosition, axisYstart + 3)];
		[[NSColor blackColor] set];
		[path setLineWidth: 1.0];
		[path stroke];
	}

	// draw the graph's Y-axis/RPM markers/ticks
	numMarkers =
		((graphMaxRPM - MFgraphMinRPM) / 100) + 1; // markers at 100-RPM intervals
	firstMarkerOffset = 0.0;
	lastMarkerOffset =
			(graphMaxRPM - MFgraphMinRPM - ((numMarkers -1) * 100)) * pixelsPerRPM;
	interMarkerSpace =
			(chartHeight - (axisYstart + firstMarkerOffset + lastMarkerOffset)) /
																					(numMarkers - 1);

	if (MFcDebug) {
		NSLog(@"... for Y-axis/RPM markers/ticks\n");
		NSLog(@"numMarkers = %d\n", numMarkers);
		NSLog(@"firstMarkerOffset = %.7f\n", firstMarkerOffset);
		NSLog(@"lastMarkerOffset = %.7f\n", lastMarkerOffset);
		NSLog(@"interMarkerSpace = %.7f\n", interMarkerSpace);
	}

	for (int i = 0; i < numMarkers; i++)
	{
		axisPosition = axisYstart - (textHeight / 2) + firstMarkerOffset +
																			(i * interMarkerSpace);
		path = [NSBezierPath bezierPath];
		[path moveToPoint:NSMakePoint(axisXstart - 3, axisPosition)];
		[path lineToPoint:NSMakePoint(axisXstart + 3, axisPosition)];
		[[NSColor blackColor] set];
		[path setLineWidth: 1.0];
		[path stroke];
	}

	// draw the graph's X-axis/temperature labels
	if (showTempsAsFahrenheit) {
		numLabels = 8;  // 8x Fahrenheit labels at 20-degree intervals
		labelValue = (int)MFfirstFtempLabel;

		// compute the Fahrenheit-scale label offsets
		// (assumes MFgraphMinTemp is < MFfirstFtempLabel in degrees Celcius and
		//  MFlastFtempLabel in degrees Celcius < MFgraphMaxTemp)
		firstLabelOffset =
			(((MFfirstFtempLabel - 32.0) * (5.0 / 9.0)) // i.e., in degrees Celcius
														- MFgraphMinTemp) * pixelsPerDegree;
		lastLabelOffset = (MFgraphMaxTemp -
			((MFlastFtempLabel - 32.0) * (5.0 / 9.0))) // i.e., in degrees Celcius
																				* pixelsPerDegree;
		textWidth = 30;
		textHeight = 24;
	} else {
		numLabels = 9;  // 9x Celcius labels at 10-degree intervals
		labelValue = (int)MFgraphMinTemp;
		firstLabelOffset = 0.0;
		lastLabelOffset = 0.0;
		textWidth = 30;
		textHeight = 24;
	}

	interLabelSpace =
				(chartWidth - (axisXstart + firstLabelOffset + lastLabelOffset)) /
																					(numLabels - 1);

	if (MFcDebug) {
		NSLog(@"... for X-axis/temperature labels\n");
		NSLog(@"numLabels = %d\n", numLabels);
		NSLog(@"firstLabelOffset = %.7f\n", firstLabelOffset);
		NSLog(@"lastLabelOffset = %.7f\n", lastLabelOffset);
		NSLog(@"textWidth = %d\n", textWidth);
		NSLog(@"textHeight = %d\n", textHeight);
		NSLog(@"interLabelSpace = %.7f\n", interLabelSpace);
	}

	for (int i = 0; i < numLabels; i++)
	{
		NSTextField *tField =
			[[NSTextField alloc]
				initWithFrame:NSMakeRect(
					axisXstart - (textWidth / 2) + firstLabelOffset +
																			(i * interLabelSpace),
					axisYstart - (textHeight + 2),
					textWidth,
					textHeight)];
		[tField setFont:font];
		[tField setAlignment:NSCenterTextAlignment];
		[tField setEditable:NO];
		[tField setBordered:NO];
		[tField setDrawsBackground:NO];
		[tField setStringValue:[NSString stringWithFormat:@"%d", labelValue]];
		[tField setTextColor:[NSColor blackColor]];
		//[tField setFrameRotation:90];
		[self addSubview:tField];

		if (showTempsAsFahrenheit) labelValue += 20; else labelValue += 10;
	}

	// draw the graph's Y-axis/RPM labels
	numLabels =
		((graphMaxRPM - MFgraphMinRPM) / 500) + 1;  // label at 500-RPM intervals
	labelValue = (int)MFgraphMinRPM;
	firstLabelOffset = 0.0;
	lastLabelOffset =
			(graphMaxRPM - MFgraphMinRPM - ((numLabels -1) * 500)) * pixelsPerRPM;
	interLabelSpace =
				(chartHeight - (axisYstart + firstLabelOffset + lastLabelOffset)) /
																					(numLabels - 1);
	textWidth = axisYlabelWidth;
	textHeight = axisXlabelHeight;

	if (MFcDebug) {
		NSLog(@"... for Y-axis/RPM labels\n");
		NSLog(@"numLabels = %d\n", numLabels);
		NSLog(@"firstLabelOffset = %.7f\n", firstLabelOffset);
		NSLog(@"lastLabelOffset = %.7f\n", lastLabelOffset);
		NSLog(@"textWidth = %d\n", textWidth);
		NSLog(@"textHeight = %d\n", textHeight);
		NSLog(@"interLabelSpace = %.7f\n", interLabelSpace);
	}

	for (int i = 0; i < numLabels; i++)
	{
		NSTextField *tField =
			[[NSTextField alloc]
				initWithFrame:NSMakeRect(
					axisXstart - textWidth,
					axisYstart - (textHeight / 2) + firstLabelOffset +
																			(i * interLabelSpace),
					textWidth,
					textHeight)];
		[tField setFont:font];
		[tField setAlignment:NSCenterTextAlignment];
		[tField setEditable:NO];
		[tField setBordered:NO];
		[tField setDrawsBackground:NO];
		[tField setStringValue:[NSString stringWithFormat:@"%d", labelValue]];
		[tField setTextColor:[NSColor blackColor]];
		[self addSubview:tField];

		labelValue += 500;
	}

	// for each fan, draw the fan's RPM vs temperature control-path
	// NOTE: the offsetLowerTempThreshold takes into account the User's setting
	// for the "Min. Fan Speed" -- i.e., this will maintain the slope of the line
	// to which Fan Control is trying to keep things adjusted

	// draw the temperature control-path for the first fan
	offsetLowerTempThreshold = lowerTempThreshold +
												(((float)(minFanRPMs[0] - MFminFanRPM) / 
												  (float)(maxFanRPMs[0] - MFminFanRPM)) *
												 (upperTempThreshold - lowerTempThreshold));

	if (MFxDebug) {
		NSLog(@"minFanRPMs[0] = %d\n", minFanRPMs[0]);
		NSLog(@"lowerTempThreshold = %.2f\n", lowerTempThreshold);
		NSLog(@"offsetLowerTempThreshold = %.2f\n", offsetLowerTempThreshold);
	}

	[[NSColor // red
						colorWithDeviceRed:0.625 green:0.0 blue:0.0 alpha:1.0] set];
	path = [NSBezierPath bezierPath];

	if (numFans > 1) [path setLineDash:slopedLineDash count:2 phase:0.0];

	[path moveToPoint:[self pointOnGraph:MFgraphMinTemp theRPM:minFanRPMs[0]]];
	[path lineToPoint:[self
						pointOnGraph:offsetLowerTempThreshold theRPM:minFanRPMs[0]]];
	[path lineToPoint:[self
								pointOnGraph:upperTempThreshold theRPM:maxFanRPMs[0]]];
	[path lineToPoint:[self pointOnGraph:MFgraphMaxTemp theRPM:maxFanRPMs[0]]];
	[path setLineWidth:2.0];
	[path stroke];

	// draw the temperature control-path for the second fan
	if (numFans > 1) {
		offsetLowerTempThreshold = lowerTempThreshold +
												(((float)(minFanRPMs[1] - MFminFanRPM) / 
												  (float)(maxFanRPMs[1] - MFminFanRPM)) *
												 (upperTempThreshold - lowerTempThreshold));

		if (MFxDebug) {
			NSLog(@"minFanRPMs[1] = %d\n", minFanRPMs[1]);
			NSLog(@"lowerTempThreshold = %.2f\n", lowerTempThreshold);
			NSLog(@"offsetLowerTempThreshold = %.2f\n", offsetLowerTempThreshold);
		}

		[[NSColor // blue
						colorWithDeviceRed:0.0 green:0.0 blue:0.625 alpha:1.0] set];
		path = [NSBezierPath bezierPath];

		if (numFans == 2) [path setLineDash:slopedLineDash count:2 phase:7.5];
		else [path setLineDash:slopedLineDash count:2 phase:2.5];

		[path moveToPoint:[self
									pointOnGraph:MFgraphMinTemp theRPM:minFanRPMs[1]]];
		[path lineToPoint:[self
						pointOnGraph:offsetLowerTempThreshold theRPM:minFanRPMs[1]]];
		[path lineToPoint:[self
								pointOnGraph:upperTempThreshold theRPM:maxFanRPMs[1]]];
		[path lineToPoint:[self
									pointOnGraph:MFgraphMaxTemp theRPM:maxFanRPMs[1]]];
		[path setLineWidth:2.0];
		[path stroke];
	}

	// draw the temperature control-path for the third fan
	if (numFans > 2) {
		offsetLowerTempThreshold = lowerTempThreshold +
												(((float)(minFanRPMs[2] - MFminFanRPM) / 
												  (float)(maxFanRPMs[2] - MFminFanRPM)) *
												 (upperTempThreshold - lowerTempThreshold));

		if (MFxDebug) {
			NSLog(@"minFanRPMs[2] = %d\n", minFanRPMs[2]);
			NSLog(@"lowerTempThreshold = %.2f\n", lowerTempThreshold);
			NSLog(@"offsetLowerTempThreshold = %.2f\n", offsetLowerTempThreshold);
		}

		[[NSColor // green
						colorWithDeviceRed:0.0 green:0.625 blue:0.0 alpha:1.0] set];
		path = [NSBezierPath bezierPath];
		[path setLineDash:slopedLineDash count:2 phase:5.0];
		[path moveToPoint:[self
									pointOnGraph:MFgraphMinTemp theRPM:minFanRPMs[2]]];
		[path lineToPoint:[self
						pointOnGraph:offsetLowerTempThreshold theRPM:minFanRPMs[2]]];
		[path lineToPoint:[self
								pointOnGraph:upperTempThreshold theRPM:maxFanRPMs[2]]];
		[path lineToPoint:[self
									pointOnGraph:MFgraphMaxTemp theRPM:maxFanRPMs[2]]];
		[path setLineWidth:2.0];
		[path stroke];
	}

	// for each fan, draw the fan's current/horizontal RPM-marker line
	if (numFans == 1) [[NSColor // light green
						colorWithDeviceRed:0.0 green:0.3765 blue:0.0 alpha:1.0] set];
	else [[NSColor // red
						colorWithDeviceRed:0.625 green:0.0 blue:0.0 alpha:1.0] set];

	path = [NSBezierPath bezierPath];

	if (numFans == 2) [path setLineDash:xLineDash count:2 phase:0.0];

	[path moveToPoint:[self pointOnGraph:MFgraphMinTemp theRPM:currFanRPMs[0]]];
	[path lineToPoint:[self pointOnGraph:MFgraphMaxTemp theRPM:currFanRPMs[0]]];
	[path setLineWidth:1.0];
	[path stroke];

	if (numFans > 1) {
		[[NSColor // blue
						colorWithDeviceRed:0.0 green:0.0 blue:0.625 alpha:1.0] set];
		path = [NSBezierPath bezierPath];

		if (numFans == 2) [path setLineDash:xLineDash count:2 phase:5.0];

		[path moveToPoint:[self
									pointOnGraph:MFgraphMinTemp theRPM:currFanRPMs[1]]];
		[path lineToPoint:[self
									pointOnGraph:MFgraphMaxTemp theRPM:currFanRPMs[1]]];
		[path setLineWidth:1.0];
		[path stroke];
	}

	if (numFans > 1) {
		[[NSColor // green
						colorWithDeviceRed:0.0 green:0.625 blue:0.0 alpha:1.0] set];
		path = [NSBezierPath bezierPath];
		[path moveToPoint:[self
									pointOnGraph:MFgraphMinTemp theRPM:currFanRPMs[2]]];
		[path lineToPoint:[self
									pointOnGraph:MFgraphMaxTemp theRPM:currFanRPMs[2]]];
		[path setLineWidth:1.0];
		[path stroke];
	}

	// draw the current/vertical temperature-marker line
	if (numFans == 1) [[NSColor // light green
						colorWithDeviceRed:0.0 green:0.3765 blue:0.0 alpha:1.0] set];
	else [[NSColor // gray
							colorWithDeviceRed:0.4 green:0.4 blue:0.4 alpha:1.0] set];

	path = [NSBezierPath bezierPath];
	[path moveToPoint:[self pointOnGraph:highTemp theRPM:MFgraphMinRPM]];
	[path lineToPoint:[self pointOnGraph:highTemp theRPM:graphMaxRPM]];
	[path setLineWidth:1.0];
	[path stroke];

	// for each fan, draw the fan's wanted/target RPM vs temp. target-indicator
	if (numFans == 1) [[NSColor // light green
						colorWithDeviceRed:0.0 green:0.3765 blue:0.0 alpha:1.0] set];
	else [[NSColor // red
						colorWithDeviceRed:0.625 green:0.0 blue:0.0 alpha:1.0] set];

	path = [NSBezierPath bezierPath];
	[path appendBezierPathWithArcWithCenter:
									[self pointOnGraph:highTemp theRPM:targetFanRPMs[0]]
									radius:5.0
									startAngle:0.0
									endAngle:360.0];
	[path setLineWidth:1.4];
	[path stroke];

	if (numFans > 1) {
		[[NSColor // blue
						colorWithDeviceRed:0.0 green:0.0 blue:0.625 alpha:1.0] set];
		path = [NSBezierPath bezierPath];
		[path appendBezierPathWithArcWithCenter:
									[self pointOnGraph:highTemp theRPM:targetFanRPMs[1]]
									radius:5.0
									startAngle:0.0
									endAngle:360.0];
		[path setLineWidth:1.4];
		[path stroke];
	}

	if (numFans > 2) {
		[[NSColor // green
						colorWithDeviceRed:0.0 green:0.625 blue:0.0 alpha:1.0] set];
		path = [NSBezierPath bezierPath];
		[path appendBezierPathWithArcWithCenter:
									[self pointOnGraph:highTemp theRPM:targetFanRPMs[2]]
									radius:5.0
									startAngle:0.0
									endAngle:360.0];
		[path setLineWidth:1.4];
		[path stroke];
	}

	if (MFcDebug) NSLog(@"--- ChartView 'drawRect' completed\n");
}

//==============================================================================
// getters and setters

// -----------------------------------------------------------------------------
- (void)setLowerTempThreshold:(float)newLowerTempThreshold
{
	if (MFpDebug) NSLog(@"--- ChartView 'setLowerTempThreshold' run\n");

	lowerTempThreshold = newLowerTempThreshold;
	[self setNeedsDisplay:YES];
}

- (void)setUpperTempThreshold:(float)newUpperTempThreshold
{
	if (MFpDebug) NSLog(@"--- ChartView 'setUpperTempThreshold' run\n");

	upperTempThreshold = newUpperTempThreshold;
	[self setNeedsDisplay:YES];
}

// -----------------------------------------------------------------------------
- (void)setCPUtemp:(float)newCPUtemp
{
	if (MFpDebug) NSLog(@"--- ChartView 'setCPUtemp' run\n");

	cpuTemp = newCPUtemp;
	[self setNeedsDisplay:YES];
}

- (void)setGPUtemp:(float)newGPUtemp
{
	if (MFpDebug) NSLog(@"--- ChartView 'setGPUtemp' run\n");

	gpuTemp = newGPUtemp;
	[self setNeedsDisplay:YES];
}

// -----------------------------------------------------------------------------
- (void)setShowTempsAsFahrenheit:(BOOL)newShowTempsAsFahrenheit
{
	if (MFpDebug) NSLog(@"--- ChartView 'setShowTempsAsFahrenheit' run\n");

	showTempsAsFahrenheit = newShowTempsAsFahrenheit;
	[self setNeedsDisplay:YES];
}

// -----------------------------------------------------------------------------
- (void)setNumFans:(int)newNumFans
{
	if (MFpDebug) NSLog(@"--- ChartView 'setNumFans' run\n");

	numFans = newNumFans;
	[self setNeedsDisplay:YES];
}

// -----------------------------------------------------------------------------
- (void)setTargetFanSpeeds:(fanSpeeds)newTargetFanSpeeds
{
	if (MFpDebug) NSLog(@"--- ChartView 'setTargetFanSpeeds' run\n");

	targetFanSpeeds = newTargetFanSpeeds;
	[self setNeedsDisplay:YES];
}

// -----------------------------------------------------------------------------
- (void)setCurrentFanSpeeds:(fanSpeeds)newCurrentFanSpeeds
{
	if (MFpDebug) NSLog(@"--- ChartView 'setCurrentFanSpeeds' run\n");

	currentFanSpeeds = newCurrentFanSpeeds;
	[self setNeedsDisplay:YES];
}

// -----------------------------------------------------------------------------
- (void)setMinFanSpeeds:(fanSpeeds)newMinFanSpeeds
{
	if (MFpDebug) NSLog(@"--- ChartView 'setMinFanSpeeds' run\n");

	minFanSpeeds = newMinFanSpeeds;
	[self setNeedsDisplay:YES];
}

- (void)setMaxFanSpeeds:(fanSpeeds)newMaxFanSpeeds
{
	if (MFpDebug) NSLog(@"--- ChartView 'setMaxFanSpeeds' run\n");

	maxFanSpeeds = newMaxFanSpeeds;
	[self setNeedsDisplay:YES];
}

@end
