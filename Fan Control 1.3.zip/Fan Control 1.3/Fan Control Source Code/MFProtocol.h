//
// Fan Control
// Copyright 2006 Lobotomo Software
// Modifications by Derman Enterprises, 2016
//
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation; either version 2
// of the License, or (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software
// Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA

#import "MFDefinitions.h"

#define MFDaemonRegisteredName  @"com.derman.FanControlDaemon"

@protocol MFProtocol

// temperature threshold settings used to compute the wanted/target fan RPMs
- (float)lowerTempThreshold;
- (float)upperTempThreshold;
- (void)setLowerTempThreshold:(float)newLowerTempThreshold;
- (void)setUpperTempThreshold:(float)newUpperTempThreshold;

// whether all temps are to be shown in Fahrenheit
- (BOOL)showTempsAsFahrenheit;
- (void)setShowTempsAsFahrenheit:(BOOL)newShowTempsAsFahrenheit;

// the current high CPU/GPU-related temperatures
- (float) cpuTemp;
- (float) gpuTemp;

// the number of fas in this system as reported via smc
- (int)numFans;

// the descriptions/IDs for the fans
- (fanNames)systemFanNames;

// the slowest/lower-limit for fan speeds/RPMs
- (fanSpeeds)minFanSpeeds;
- (void)setMinFanSpeeds:(fanSpeeds)newMinFanSpeeds;

// the maximum fan speeds/RPMs reported via smc
- (fanSpeeds)maxFanSpeeds;

// the computed wanted/target fan speeds/RPMs based upon the pref settings
- (fanSpeeds)targetFanSpeeds;

// the current fan RPMs reported via smc
- (fanSpeeds)currentFanSpeeds;

@end
