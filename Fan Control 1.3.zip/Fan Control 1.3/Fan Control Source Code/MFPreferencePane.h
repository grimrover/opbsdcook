//
// Fan Control
// Copyright 2006 Lobotomo Software
// Modifications by Derman Enterprises, 2016
//
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation; either version 2
// of the License, or (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software
// Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA
//

#import <Cocoa/Cocoa.h>
#import <NSPreferencePane.h>
#import "MFDefinitions.h"

@class MFDaemon, MFChartView, MFTemperatureTransformer;

@interface MFPreferencePane : NSPreferencePane {
	// bindings controller
	IBOutlet NSObjectController *fileOwnerController;

	// slider controls
	IBOutlet NSSlider *lowerTempThresholdSlider;
	IBOutlet NSSlider *upperTempThresholdSlider;
	IBOutlet NSSlider *fan1minRPMslider;
	IBOutlet NSSlider *fan2minRPMslider;
	IBOutlet NSSlider *fan3minRPMslider;

	// text fields -- associated with "temperature threshold" sliders
	IBOutlet NSTextField *lowerTempThresholdSliderValueField;
	IBOutlet NSTextField *upperTempThresholdSliderValueField;

	// text fields -- associated with "slowest fan speed" sliders
	IBOutlet NSTextField *fan1minRPMsliderLabelfield;
	IBOutlet NSTextField *fan2minRPMsliderLabelfield;
	IBOutlet NSTextField *fan3minRPMsliderLabelfield;

	IBOutlet NSTextField *fan1minRPMsliderValueField;
	IBOutlet NSTextField *fan2minRPMsliderValueField;
	IBOutlet NSTextField *fan3minRPMsliderValueField;

	IBOutlet NSTextField *fan1minRPMsliderUnitsField;
	IBOutlet NSTextField *fan2minRPMsliderUnitsField;
	IBOutlet NSTextField *fan3minRPMsliderUnitsField;

	// text fields -- associated with "Fan Speeds" fields
	IBOutlet NSTextField *fan1RPMlabelField;
	IBOutlet NSTextField *fan2RPMlabelField;
	IBOutlet NSTextField *fan3RPMlabelField;

	IBOutlet NSTextField *fan1maxRPMfield;
	IBOutlet NSTextField *fan2maxRPMfield;
	IBOutlet NSTextField *fan3maxRPMfield;

	IBOutlet NSTextField *fan1slash1Field;
	IBOutlet NSTextField *fan2slash1Field;
	IBOutlet NSTextField *fan3slash1Field;

	IBOutlet NSTextField *fan1targetRPMfield;
	IBOutlet NSTextField *fan2targetRPMfield;
	IBOutlet NSTextField *fan3targetRPMfield;

	IBOutlet NSTextField *fan1slash2Field;
	IBOutlet NSTextField *fan2slash2Field;
	IBOutlet NSTextField *fan3slash2Field;

	IBOutlet NSTextField *fan1percentField;
	IBOutlet NSTextField *fan2percentField;
	IBOutlet NSTextField *fan3percentField;

	IBOutlet NSTextField *fan1percentCharField;
	IBOutlet NSTextField *fan2percentCharField;
	IBOutlet NSTextField *fan3percentCharField;

	IBOutlet NSTextField *fan1currRPMfield;
	IBOutlet NSTextField *fan2currRPMfield;
	IBOutlet NSTextField *fan3currRPMfield;

	IBOutlet NSTextField *fan1unitsField;
	IBOutlet NSTextField *fan2unitsField;
	IBOutlet NSTextField *fan3unitsField;

	// text fields -- associated with "Current Temperatures" fields
	IBOutlet NSTextField *cpuTempField;
	IBOutlet NSTextField *gpuTempField;

	// text field -- for showing error messages
	IBOutlet NSTextField *errorMsgField;

	// chart view
	IBOutlet MFChartView *chartView;

	// daemon proxy
	MFDaemon *daemon;

	// temperature converter
	MFTemperatureTransformer *transformer;

	// update timer
	NSTimer *timer;
}

// accessors, converters & setters
- (float)lowerTempThreshold;
- (void)setLowerTempThreshold:(float)newLowerTempThreshold;
- (float)upperTempThreshold;
- (void)setUpperTempThreshold:(float)newUpperTempThreshold;

- (float)cpuTemp;
- (float)gpuTemp;

- (BOOL)showTempsAsFahrenheit;
- (void)setShowTempsAsFahrenheit:(BOOL)newShowTempsAsFahrenheit;

- (fanSpeeds)minFanSpeeds;
- (void)setMinFanSpeeds:(fanSpeeds)newMinFanSpeeds;

- (int)fan1minRPM;
- (void)setFan1minRPM:(int)newFan1minRPM;
- (int)fan2minRPM;
- (void)setFan2minRPM:(int)newFan2minRPM;
- (int)fan3minRPM;
- (void)setFan3minRPM:(int)newFan3minRPM;

@end
