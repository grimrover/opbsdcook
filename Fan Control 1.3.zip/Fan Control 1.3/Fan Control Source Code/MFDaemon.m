//
// Fan Control
// Copyright 2006 Lobotomo Software
// Modifications by Derman Enterprises, 2016
//
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation; either version 2
// of the License, or (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software
// Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA

#import "MFDaemon.h"
#import "MFDefinitions.h"
#import "MFProtocol.h"
#import "smc.h"

@implementation MFDaemon

static float			lowerTempDefault;
static float			upperTempDefault;
static int				currFanRPMs[3] = { 0, 0, 0 };  // 0 = unused
static int				maxFanRPMs[3] = { 0, 0, 0 };  // 0 = unused
static int				minFanRPMs[3] = { 0, 0, 0 };  // 0 = unused
static int				prevTargetFanRPMs[3] = { 0, 0, 0 };  // 0 = unused
static int				smcMaxFanRPMs[3] = { 0, 0, 0 };  // 0 = unused
static int				smcMinFanRPMs[3] = { 0, 0, 0 };  // 0 = unused
static int				targetFanRPMs[3] = { 0, 0, 0 };  // 0 = unused
const int				halfSpeedStepRPM = MFspeedStepRPM / 2;
static BOOL				smcReadingsAreOK = YES;

// -----------------------------------------------------------------------------
- (id)init
{
	if (self = [super init])
	{
		if (MFdDebug) {
			NSLog(@"=====\n");
			NSLog(@"--- FanControlDaemon 'init' started\n");
		}

		io_connect_t	conn;

		// setup some defaults
		mustSavePrefs = NO;
		showTempsAsFahrenheit = NO;
		smcReadingsAreOK = YES;
		lowerTempDefault =
						MFlowerTempThresholdBottom +
						((MFlowerTempThresholdTop - MFlowerTempThresholdBottom) / 2);
		upperTempDefault =
						MFupperTempThresholdBottom +
						((MFupperTempThresholdTop - MFupperTempThresholdBottom) / 2);
		lowerTempThreshold = lowerTempDefault;
		upperTempThreshold = upperTempDefault;

		// init the smc tables and get the intial info that's required from smc
		smcOpen(&conn);
		smcInitPrioritizedTemperatureKeys(conn);//find applicable temperature keys
		cpuTemp = [self getHighestCPUtemperature:conn];  // -100.0 = failure
		gpuTemp = [self getHighestGPUtemperature:conn];  // -100.0 = failure
		numFans = smcGetNumFans(conn);  // -1 = failure
		[self getCurrFanRPMs:conn];  // fills the currFanRPMs array
		[self getSMCminFanRPMs:conn];   // fills the smcMinFanRPMs array
		[self getSMCmaxFanRPMs:conn];   // fills the smcMaxFanRPMs array
		smcClose(conn);

		if (MFdDebug) {
			NSLog(@"mustSavePrefs = %@\n", mustSavePrefs ? @"Yes" : @"No");
			NSLog(@"showTempsAsFahrenheit = %@\n",
													showTempsAsFahrenheit ? @"Yes" : @"No");
			NSLog(@"smcReadingsAreOK = %@\n", smcReadingsAreOK ? @"Yes" : @"No");
			NSLog(@"lowerTempDefault = %.3f\n", lowerTempDefault);
			NSLog(@"upperTempDefault = %.3f\n", upperTempDefault);
			NSLog(@"lowerTempThreshold = %.3f\n", lowerTempThreshold);
			NSLog(@"upperTempThreshold = %.3f\n", upperTempThreshold);
			NSLog(@"cpuTemp = %.3f\n", cpuTemp);
			NSLog(@"gpuTemp = %.3f\n", gpuTemp);
			NSLog(@"numFans = %d\n", numFans);

			NSLog(@"currFanRPMs[0] = %d\n", currFanRPMs[0]);
			if(numFans > 1) NSLog(@"currFanRPMs[1] = %d\n", currFanRPMs[1]);
			if(numFans > 2) NSLog(@"currFanRPMs[2] = %d\n", currFanRPMs[2]);

			NSLog(@"smcMinFanRPMs[0] = %d\n", smcMinFanRPMs[0]);
			if(numFans > 1) NSLog(@"smcMinFanRPMs[1] = %d\n", smcMinFanRPMs[1]);
			if(numFans > 2) NSLog(@"smcMinFanRPMs[2] = %d\n", smcMinFanRPMs[2]);

			NSLog(@"smcMaxFanRPMs[0] = %d\n", smcMaxFanRPMs[0]);
			if(numFans > 1) NSLog(@"smcMaxFanRPMs[1] = %d\n", smcMaxFanRPMs[1]);
			if(numFans > 2) NSLog(@"smcMaxFanRPMs[2] = %d\n", smcMaxFanRPMs[2]);
		}

		// ensure we can get the following from smc:
		// - the CPU/GPU-related temperatures
		// - the number of fans in this system
		// - the current fan speed for each fan in this system
		if ((cpuTemp == -100.0) || (gpuTemp == -100.0) || (numFans < 1) ||
			 (currFanRPMs[0] == 0) || (currFanRPMs[0] == -1) ||
			 ((numFans > 1) && (currFanRPMs[1] == -1)) ||
			 ((numFans > 2) && (currFanRPMs[2] == -1))) smcReadingsAreOK = NO;

		// ensure we can get the minimum fan speed(s) from smc
		if ((smcMinFanRPMs[0] == 0) || (smcMinFanRPMs[0] == -1) ||
			 ((numFans > 1) && (smcMinFanRPMs[1] == -1)) ||
			 ((numFans > 2) && (smcMinFanRPMs[2] == -1))) smcReadingsAreOK = NO;

		// ensure we can get the maximum fan speed(s) from smc
		if ((smcMaxFanRPMs[0] == 0) || (smcMaxFanRPMs[0] == -1) ||
			 ((numFans > 1) && (smcMaxFanRPMs[1] == -1)) ||
			 ((numFans > 2) && (smcMaxFanRPMs[2] == -1))) smcReadingsAreOK = NO;

		if (smcReadingsAreOK) {
			// we know we can get the minimum fan RPMs from smc but, since that
			// value is constantly (re)set to control the fan speeds, we now set
			// the minimum fan speed/RPMs to be a known-safe lowest-speed value
			smcMinFanRPMs[0] = MFminFanRPM;
			smcMinFanRPMs[1] = MFminFanRPM;
			smcMinFanRPMs[2] = MFminFanRPM;

			// during startup, we set the minimum fan RPM/speed for all fans to be
			// the known-safe lowest-speed value because the fan-speed adjustment
			// algorithm relies upon starting from that known minimum fan speed and
			// the current minimum-speed value given by smc may be "left over" from
			// a previous fan-control adjustment (e.g., if the Fan Control daemon
			// died)
			// NOTE: putting a system to sleep nearly always sets the minimum fan
			//       RPM/speed to the minimum speed known by the hardware/OS
			minFanRPMs[0] = MFminFanRPM;
			minFanRPMs[1] = MFminFanRPM;
			minFanRPMs[2] = MFminFanRPM;

			maxFanRPMs[0] = smcMaxFanRPMs[0];
			if (numFans > 1) maxFanRPMs[1] = smcMaxFanRPMs[1];
			if (numFans > 2) maxFanRPMs[2] = smcMaxFanRPMs[2];
		}

		if (MFdDebug) {
			NSLog(@"---\n");
			NSLog(@"smcReadingsAreOK = %@\n", smcReadingsAreOK ? @"Yes" : @"No");

			NSLog(@"minFanRPMs[0] = %d\n", minFanRPMs[0]);
			if(numFans > 1) NSLog(@"minFanRPMs[1] = %d\n", minFanRPMs[1]);
			if(numFans > 2) NSLog(@"minFanRPMs[2] = %d\n", minFanRPMs[2]);

			NSLog(@"maxFanRPMs[0] = %d\n", maxFanRPMs[0]);
			if(numFans > 1) NSLog(@"maxFanRPMs[1] = %d\n", maxFanRPMs[1]);
			if(numFans > 2) NSLog(@"maxFanRPMs[2] = %d\n", maxFanRPMs[2]);

			NSLog(@"--- FanControlDaemon 'init' completed\n");
		}
	}

	return self;
}

// -----------------------------------------------------------------------------
// this gets called when the FanControlDaemon starts (Du-Oh!)
- (void)start
{
	if (MFdDebug) NSLog(@"--- FanControlDaemon 'start' started\n");

	[self readPreferences];
	[NSTimer scheduledTimerWithTimeInterval:MFupdateInterval
				target:self selector:@selector(timer:) userInfo:nil repeats:YES];

	if (MFdDebug) NSLog(@"--- FanControlDaemon 'start' completed\n");
}

// -----------------------------------------------------------------------------
// save the preferences
- (void)storePreferences
{
	if (MFdDebug) NSLog(@"--- FanControlDaemon 'storePreferences' started\n");

	CFPreferencesSetValue(
					CFSTR("lowerTempThreshold"),
					(CFPropertyListRef)[NSNumber numberWithFloat:lowerTempThreshold],
					CFSTR(MFapplicationIdentifier),
					kCFPreferencesAnyUser,
					kCFPreferencesCurrentHost);
	CFPreferencesSetValue(
					CFSTR("upperTempThreshold"),
					(CFPropertyListRef)[NSNumber numberWithFloat:upperTempThreshold],
					CFSTR(MFapplicationIdentifier),
					kCFPreferencesAnyUser,
					kCFPreferencesCurrentHost);
	CFPreferencesSetValue(
				CFSTR("showTempsAsFahrenheit"),
				(CFPropertyListRef)[NSNumber numberWithBool:showTempsAsFahrenheit],
				CFSTR(MFapplicationIdentifier),
				kCFPreferencesAnyUser,
				kCFPreferencesCurrentHost);

	CFPreferencesSetValue(
							CFSTR("minFanRPMs[0]"),
							(CFPropertyListRef)[NSNumber numberWithInt:minFanRPMs[0]],
							CFSTR(MFapplicationIdentifier),
							kCFPreferencesAnyUser,
							kCFPreferencesCurrentHost);

	if(numFans > 1) {
		CFPreferencesSetValue(
							CFSTR("minFanRPMs[1]"),
							(CFPropertyListRef)[NSNumber numberWithInt:minFanRPMs[1]],
							CFSTR(MFapplicationIdentifier),
							kCFPreferencesAnyUser,
							kCFPreferencesCurrentHost);
	}

	if(numFans > 2) {
		CFPreferencesSetValue(
							CFSTR("minFanRPMs[2]"),
							(CFPropertyListRef)[NSNumber numberWithInt:minFanRPMs[2]],
							CFSTR(MFapplicationIdentifier),
							kCFPreferencesAnyUser,
							kCFPreferencesCurrentHost);
	}

	CFPreferencesSynchronize(CFSTR(MFapplicationIdentifier),
									 kCFPreferencesAnyUser,
									 kCFPreferencesCurrentHost);
	if (MFdDebug) NSLog(@"--- FanControlDaemon 'storePreferences' completed\n");
}

// -----------------------------------------------------------------------------
// retrieve the preferences
- (void)readPreferences
{
	if (MFdDebug) NSLog(@"--- FanControlDaemon 'readPreferences' started\n");

	CFPropertyListRef property;

	property = CFPreferencesCopyValue(CFSTR("lowerTempThreshold"),
												 CFSTR(MFapplicationIdentifier),
												 kCFPreferencesAnyUser,
												 kCFPreferencesCurrentHost);
	if (property) lowerTempThreshold = [(NSNumber *)property floatValue];
	else mustSavePrefs = YES;

	property = CFPreferencesCopyValue(CFSTR("upperTempThreshold"),
												 CFSTR(MFapplicationIdentifier),
												 kCFPreferencesAnyUser,
												 kCFPreferencesCurrentHost);
	if (property) upperTempThreshold = [(NSNumber *)property floatValue];
	else mustSavePrefs = YES;

	property = CFPreferencesCopyValue(CFSTR("showTempsAsFahrenheit"),
												 CFSTR(MFapplicationIdentifier),
												 kCFPreferencesAnyUser,
												 kCFPreferencesCurrentHost);
	if (property) showTempsAsFahrenheit = [(NSNumber *)property boolValue];
	else mustSavePrefs = YES;

	property = CFPreferencesCopyValue(CFSTR("minFanRPMs[0]"),
													 CFSTR(MFapplicationIdentifier),
													 kCFPreferencesAnyUser,
													 kCFPreferencesCurrentHost);
	if (property) minFanRPMs[0] = [(NSNumber *)property intValue];
	else mustSavePrefs = YES;

	if(numFans > 1) {
		property = CFPreferencesCopyValue(CFSTR("minFanRPMs[1]"),
													 CFSTR(MFapplicationIdentifier),
													 kCFPreferencesAnyUser,
													 kCFPreferencesCurrentHost);
		if (property) minFanRPMs[1] = [(NSNumber *)property intValue];
		else mustSavePrefs = YES;
	}

	if(numFans > 2) {
		property = CFPreferencesCopyValue(CFSTR("minFanRPMs[2]"),
													 CFSTR(MFapplicationIdentifier),
													 kCFPreferencesAnyUser,
													 kCFPreferencesCurrentHost);
		if (property) minFanRPMs[2] = [(NSNumber *)property intValue];
		else mustSavePrefs = YES;
	}

	//ensure that temperature-threshold preference values are not "out of bounds"
	if ((lowerTempThreshold < MFlowerTempThresholdBottom) ||
		 (lowerTempThreshold > MFlowerTempThresholdTop)) {
		lowerTempThreshold = lowerTempDefault;
		mustSavePrefs = YES;
	}

	if ((upperTempThreshold < MFupperTempThresholdBottom) ||
		 (upperTempThreshold > MFupperTempThresholdTop)) {
		upperTempThreshold = upperTempDefault;
		mustSavePrefs = YES;
	}

	// ensure that the minimum fan speed/RPM setting(s) are not "out of bounds"
	if ((minFanRPMs[0] < smcMinFanRPMs[0]) ||
		 (minFanRPMs[0] > smcMaxFanRPMs[0])) {
		minFanRPMs[0] = smcMinFanRPMs[0];
		mustSavePrefs = YES;
	}

	if ((numFans > 1) &&
		 ((minFanRPMs[1] < smcMinFanRPMs[1]) ||
		  (minFanRPMs[1] > smcMaxFanRPMs[1]))) {
		minFanRPMs[1] = smcMinFanRPMs[1];
		mustSavePrefs = YES;
	}

	if ((numFans > 2) &&
		 ((minFanRPMs[2] < smcMinFanRPMs[2]) ||
		  (minFanRPMs[2] > smcMaxFanRPMs[2]))) {
		minFanRPMs[2] = smcMinFanRPMs[2];
		mustSavePrefs = YES;
	}

	if (MFdDebug) {
		NSLog(@"lowerTempThreshold = %.3f\n", lowerTempThreshold);
		NSLog(@"upperTempThreshold = %.3f\n", upperTempThreshold);
		NSLog(@"showTempsAsFahrenheit = %@\n",
													showTempsAsFahrenheit ? @"Yes" : @"No");
		NSLog(@"smcMinFanRPMs[0] = %d\n", smcMinFanRPMs[0]);
		NSLog(@"smcMaxFanRPMs[0] = %d\n", smcMaxFanRPMs[0]);

		if(numFans > 1) {
			NSLog(@"smcMinFanRPMs[1] = %d\n", smcMinFanRPMs[1]);
			NSLog(@"smcMaxFanRPMs[1] = %d\n", smcMaxFanRPMs[1]);
		}

		if(numFans > 2) {
			NSLog(@"smcMinFanRPMs[2] = %d\n", smcMinFanRPMs[2]);
			NSLog(@"smcMaxFanRPMs[2] = %d\n", smcMaxFanRPMs[2]);
		}

		NSLog(@"mustSavePrefs = %@\n", mustSavePrefs ? @"Yes" : @"No");
	}

	// save preferences, if required
	if (mustSavePrefs) {
		[self storePreferences];
		mustSavePrefs = NO;
	}

	if (MFdDebug) NSLog(@"--- FanControlDaemon 'readPreferences' completed\n");
}

// -----------------------------------------------------------------------------
// control loop called by NSTimer at the specified interval
- (void)timer:(NSTimer *)aTimer
{
	if (MFdDebug) NSLog(@"--- FanControlDaemon 'timer' started\n");

	float				highTemp;
	int				adjustmentRPMs[3] = { 0, 0, 0 };  // 0 = unused
	int				alignmentRPMs[3] = { 0, 0, 0 };  // 0 = unused
	int				maxRPMspeedStep;
	io_connect_t	conn;

	smcOpen(&conn);
	cpuTemp = [self getHighestCPUtemperature:conn];  // -100.0 = failure
	gpuTemp = [self getHighestGPUtemperature:conn];  // -100.0 = failure
	[self getCurrFanRPMs:conn];  // fills the currFanRPMs array

	// do nothing if we can't get valid values from smc
	if ((cpuTemp == -100.0) || (gpuTemp == -100.0) || (currFanRPMs[0] == -1) ||
		 ((numFans > 1) && (currFanRPMs[1] == -1)) ||
		 ((numFans > 2) && (currFanRPMs[2] == -1))) {
		smcReadingsAreOK = NO;

		if (MFdDebug) {
			NSLog(@"smcReadingsAreOK = %@\n", smcReadingsAreOK ? @"Yes" : @"No");
			NSLog(@"cpuTemp = %.3f\n", cpuTemp);
			NSLog(@"gpuTemp = %.3f\n", gpuTemp);
			NSLog(@"numFans = %d\n", numFans);
			NSLog(@"currFanRPMs[0] = %d\n", currFanRPMs[0]);

			if(numFans > 1) NSLog(@"currFanRPMs[1] = %d\n", currFanRPMs[1]);
			if(numFans > 2) NSLog(@"currFanRPMs[2] = %d\n", currFanRPMs[2]);

			NSLog(@"--- FanControlDaemon 'timer' completed\n");
		}

		return;
	}

	// determine the highest temperature (i.e., the one that'll run the fans)
	if (cpuTemp > gpuTemp) highTemp = cpuTemp; else highTemp = gpuTemp;

	if (MFdDebug) {
		NSLog(@"\n");
		NSLog(@"smcReadingsAreOK = %@\n", smcReadingsAreOK ? @"Yes" : @"No");
		NSLog(@"cpuTemp = %.3f\n", cpuTemp);
		NSLog(@"gpuTemp = %.3f\n", gpuTemp);
		NSLog(@"highTemp = %.3f\n", highTemp);
	}

	// compute the wanted/target RPM(s) per the Users's preference settings

	if (highTemp < lowerTempThreshold) {
		targetFanRPMs[0] = smcMinFanRPMs[0];  // no fan-speed adjustment required
	} else if (highTemp > upperTempThreshold) {
		targetFanRPMs[0] = maxFanRPMs[0];  // set fan to highest possible speed
	} else if (minFanRPMs[0] > currFanRPMs[0]) {
		targetFanRPMs[0] = minFanRPMs[0];  // set fan to User-set "Min. Fan Speed"
	} else {
		// using the upper/lower temp thresholds, compute a wanted/target fan RPM
		targetFanRPMs[0] = roundf(smcMinFanRPMs[0] +
											(((highTemp - lowerTempThreshold) /
											  (upperTempThreshold - lowerTempThreshold)) *
											 (maxFanRPMs[0] - smcMinFanRPMs[0])));

		if (targetFanRPMs[0] < minFanRPMs[0]) targetFanRPMs[0] = minFanRPMs[0];
		if (targetFanRPMs[0] > maxFanRPMs[0]) targetFanRPMs[0] = maxFanRPMs[0];
	}

	if (numFans > 1) {
		// determine the wanted/target RPM indicated by the preference settings
		if (highTemp < lowerTempThreshold) {
			targetFanRPMs[1] = smcMinFanRPMs[1];  // no fan-speed adjustment req'd
		} else if (highTemp > upperTempThreshold) {
			targetFanRPMs[1] = maxFanRPMs[1];  // set fan to highest possible speed
		} else if (minFanRPMs[1] > currFanRPMs[1]) {
			targetFanRPMs[1] = minFanRPMs[1]; // set fan to User's "Min. Fan Speed"
		} else {
			// using the upper/lower temp thresholds, compute a wanted fan RPM
			targetFanRPMs[1] = roundf(smcMinFanRPMs[1] +
											(((highTemp - lowerTempThreshold) /
											  (upperTempThreshold - lowerTempThreshold)) *
											 (maxFanRPMs[1] - smcMinFanRPMs[1])));

			if (targetFanRPMs[1] < minFanRPMs[1]) targetFanRPMs[1] = minFanRPMs[1];
			if (targetFanRPMs[1] > maxFanRPMs[1]) targetFanRPMs[1] = maxFanRPMs[1];
		}
	}

	if (numFans > 2) {
		// determine the wanted/target RPM indicated by the preference settings
		if (highTemp < lowerTempThreshold) {
			targetFanRPMs[2] = smcMinFanRPMs[2];  // no fan-speed adjustment req'd
		} else if (highTemp > upperTempThreshold) {
			targetFanRPMs[2] = maxFanRPMs[2];  // set fan to highest possible speed
		} else if (minFanRPMs[2] > currFanRPMs[2]) {
			targetFanRPMs[2] = minFanRPMs[2]; // set fan to User's "Min. Fan Speed"
		} else {
			// using the upper/lower temp thresholds, compute a wanted fan RPM
			targetFanRPMs[2] = roundf(smcMinFanRPMs[2] +
											(((highTemp - lowerTempThreshold) /
											  (upperTempThreshold - lowerTempThreshold)) *
											 (maxFanRPMs[2] - smcMinFanRPMs[2])));

			if (targetFanRPMs[2] < minFanRPMs[2]) targetFanRPMs[2] = minFanRPMs[2];
			if (targetFanRPMs[2] > maxFanRPMs[2]) targetFanRPMs[2] = maxFanRPMs[2];
		}
	}

	if (MFdDebug) {
		NSLog(@"minFanRPMs[0] = %d\n", minFanRPMs[0]);
		NSLog(@"maxFanRPMs[0] = %d\n", maxFanRPMs[0]);
		NSLog(@"currFanRPMs[0] = %d\n", currFanRPMs[0]);
		NSLog(@"prevTargetFanRPMs[0] = %d\n", prevTargetFanRPMs[0]);
		NSLog(@"computed targetFanRPMs[0] = %d\n", targetFanRPMs[0]);

		if(numFans > 1) {
			NSLog(@"smcMinFanRPMs[1] = %d\n", smcMinFanRPMs[1]);
			NSLog(@"smcMaxFanRPMs[1] = %d\n", smcMaxFanRPMs[1]);
			NSLog(@"currFanRPMs[1] = %d\n", currFanRPMs[1]);
			NSLog(@"prevTargetFanRPMs[1] = %d\n", prevTargetFanRPMs[1]);
			NSLog(@"computed targetFanRPMs[1] = %d\n", targetFanRPMs[1]);
		}

		if(numFans > 2) {
			NSLog(@"smcMinFanRPMs[2] = %d\n", smcMinFanRPMs[2]);
			NSLog(@"smcMaxFanRPMs[2] = %d\n", smcMaxFanRPMs[2]);
			NSLog(@"currFanRPMs[2] = %d\n", currFanRPMs[2]);
			NSLog(@"prevTargetFanRPMs[2] = %d\n", prevTargetFanRPMs[2]);
			NSLog(@"computed targetFanRPMs[2] = %d\n", targetFanRPMs[2]);
		}
	}

	// compute difference between each fan's wanted/target RPM & the current RPM
	adjustmentRPMs[0] = targetFanRPMs[0] - currFanRPMs[0];

	if (abs(adjustmentRPMs[0]) < halfSpeedStepRPM) {
		adjustmentRPMs[0] = 0;  // it's within 1/2 of an RPM step, so leave it
	} else { // ensure the +/- difference is not greater than the maximum allowed
		if (maxFanRPMs[0] > 2500) maxRPMspeedStep = MFmaxRPMspeedStep + 100;
		else maxRPMspeedStep = MFmaxRPMspeedStep;

		// increase the fan speed twice as quickly at high temperatures
		if (highTemp > 70.0) maxRPMspeedStep = maxRPMspeedStep * 2;

		if (adjustmentRPMs[0] < -maxRPMspeedStep) {
			adjustmentRPMs[0] = -maxRPMspeedStep;
		}

		if (adjustmentRPMs[0] > maxRPMspeedStep) {
			adjustmentRPMs[0] = maxRPMspeedStep;
		}
	}

	if (MFdDebug) NSLog(@"adjustmentRPMs[0] = %d\n", adjustmentRPMs[0]);

	if (numFans > 1) {
		// determine difference between fan's wanted/target RPM & the current RPM
		adjustmentRPMs[1] = targetFanRPMs[1] - currFanRPMs[1];

		if (abs(adjustmentRPMs[1]) < halfSpeedStepRPM) {
			adjustmentRPMs[1] = 0;  // it's within 1/2 of an RPM step, so leave it
		} else { // ensure the +/- difference is not greater than the max allowed
			if (maxFanRPMs[1] > 2500) maxRPMspeedStep = MFmaxRPMspeedStep + 100;
			else maxRPMspeedStep = MFmaxRPMspeedStep;

		// increase the fan speed twice as quickly at high temperatures
			if (highTemp > 70.0) maxRPMspeedStep = maxRPMspeedStep * 2;

			if (adjustmentRPMs[1] < -maxRPMspeedStep) {
				adjustmentRPMs[1] = -maxRPMspeedStep;
			}

			if (adjustmentRPMs[1] > maxRPMspeedStep) {
				adjustmentRPMs[1] = maxRPMspeedStep;
			}
		}

		if (MFdDebug) NSLog(@"adjustmentRPMs[1] = %d\n", adjustmentRPMs[1]);
	}

	if (numFans > 2) {
		// determine difference between fan's wanted/target RPM & the current RPM
		adjustmentRPMs[2] = targetFanRPMs[2] - currFanRPMs[2];

		if (abs(adjustmentRPMs[2]) < halfSpeedStepRPM) {
			adjustmentRPMs[2] = 0;  // it's within 1/2 of an RPM step, so leave it
		} else { // ensure the +/- difference is not greater than the max allowed
			if (maxFanRPMs[2] > 2500) maxRPMspeedStep = MFmaxRPMspeedStep + 100;
			else maxRPMspeedStep = MFmaxRPMspeedStep;

		// increase the fan speed twice as quickly at high temperatures
			if (highTemp > 70.0) maxRPMspeedStep = maxRPMspeedStep * 2;

			if (adjustmentRPMs[2] < -maxRPMspeedStep) {
				adjustmentRPMs[2] = -maxRPMspeedStep;
			}

			if (adjustmentRPMs[2] > maxRPMspeedStep) {
				adjustmentRPMs[2] = maxRPMspeedStep;
			}
		}

		if (MFdDebug) NSLog(@"adjustmentRPMs[2] = %d\n", adjustmentRPMs[2]);
	}

	// compute the new wanted/target RPM for each fan
	targetFanRPMs[0] = currFanRPMs[0] + adjustmentRPMs[0];

	if (MFdDebug) NSLog(@"new targetFanRPMs[0] = %d\n", targetFanRPMs[0]);

	if (numFans > 1) {
		// compute the new wanted/target RPM
		targetFanRPMs[1] = currFanRPMs[1] + adjustmentRPMs[1];

		if (MFdDebug) NSLog(@"new targetFanRPMs[1] = %d\n", targetFanRPMs[1]);
	}

	if (numFans > 2) {
		// compute the new wanted/target RPM
		targetFanRPMs[2] = currFanRPMs[2] + adjustmentRPMs[2];

		if (MFdDebug) NSLog(@"new targetFanRPMs[2] = %d\n", targetFanRPMs[2]);
	}

	// set each fan's wanted/target RPM to the nearest MFspeedStepRPM boundary
	targetFanRPMs[0] += halfSpeedStepRPM;
	alignmentRPMs[0] = targetFanRPMs[0] % MFspeedStepRPM;
	targetFanRPMs[0] = targetFanRPMs[0] - alignmentRPMs[0];

	if (alignmentRPMs[0] > (MFspeedStepRPM / 2)) {
		targetFanRPMs[0] = targetFanRPMs[0] + MFspeedStepRPM;
	}

	if (MFdDebug) NSLog(@"%d RPM-aligned next targetFanRPMs[0] = %d\n",
															MFspeedStepRPM, targetFanRPMs[0]);

	if (numFans > 1) {
		// set the wanted/target RPM to the nearest MFspeedStepRPM boundary
		targetFanRPMs[1] += halfSpeedStepRPM;
		alignmentRPMs[1] = targetFanRPMs[1] % MFspeedStepRPM;
		targetFanRPMs[1] = targetFanRPMs[1] - alignmentRPMs[1];

		if (alignmentRPMs[1] > (MFspeedStepRPM / 2)) {
			targetFanRPMs[1] = targetFanRPMs[1] + MFspeedStepRPM;
		}

		if (MFdDebug) NSLog(@"%d RPM-aligned next targetFanRPMs[1] = %d\n",
															MFspeedStepRPM, targetFanRPMs[1]);
	}

	if (numFans > 2) {
		// set the wanted/target RPM to the nearest MFspeedStepRPM boundary
		targetFanRPMs[2] += halfSpeedStepRPM;
		alignmentRPMs[2] = targetFanRPMs[2] % MFspeedStepRPM;
		targetFanRPMs[2] = targetFanRPMs[2] - alignmentRPMs[2];

		if (alignmentRPMs[2] > (MFspeedStepRPM / 2)) {
			targetFanRPMs[2] = targetFanRPMs[2] + MFspeedStepRPM;
		}

		if (MFdDebug) NSLog(@"%d RPM-aligned next targetFanRPMs[2] = %d\n",
															MFspeedStepRPM, targetFanRPMs[2]);
	}

	// for each fan, ensure that we don't target a fan speed that's below the set
	// "slowest fan speed" or above the "maximum safe fan speed"
	if (targetFanRPMs[0] < minFanRPMs[0]) targetFanRPMs[0] = minFanRPMs[0];
	if (targetFanRPMs[0] > maxFanRPMs[0]) targetFanRPMs[0] = maxFanRPMs[0];
	if (MFdDebug) NSLog(@"final next targetFanRPMs[0] = %d\n", targetFanRPMs[0]);

	if (numFans > 1) {
		if (targetFanRPMs[1] < minFanRPMs[1]) targetFanRPMs[1] = minFanRPMs[1];
		if (targetFanRPMs[1] > maxFanRPMs[1]) targetFanRPMs[1] = maxFanRPMs[1];
		if (MFdDebug) NSLog(@"final next targetFanRPMs[1] = %d\n",
																				targetFanRPMs[1]);
	}

	if (numFans > 2) {
		if (targetFanRPMs[2] < minFanRPMs[2]) targetFanRPMs[2] = minFanRPMs[2];
		if (targetFanRPMs[2] > maxFanRPMs[2]) targetFanRPMs[2] = maxFanRPMs[2];
		if (MFdDebug) NSLog(@"final next targetFanRPMs[2] = %d\n",
																				targetFanRPMs[2]);
	}

	// if required, "request"/set the "target" fan speeds
	if (smcReadingsAreOK) {
		if ((targetFanRPMs[0] != prevTargetFanRPMs[0]) ||
			 ((numFans > 1) && ((targetFanRPMs[1] != prevTargetFanRPMs[1]))) || 
			 ((numFans > 2) && ((targetFanRPMs[2] != prevTargetFanRPMs[2])))) {
			[self setMinFanRPMs:conn];
		}
	}

	smcClose(conn);

	prevTargetFanRPMs[0] = targetFanRPMs[0];

	if (MFdDebug) NSLog(@"prevTargetFanRPMs[0] = %d\n", prevTargetFanRPMs[0]);

	if (numFans > 1) {
		prevTargetFanRPMs[1] = targetFanRPMs[1];

		if (MFdDebug) NSLog(@"prevTargetFanRPMs[1] = %d\n", prevTargetFanRPMs[1]);
	}

	if (numFans > 2) {
		prevTargetFanRPMs[2] = targetFanRPMs[2];

		if (MFdDebug) NSLog(@"prevTargetFanRPMs[2] = %d\n", prevTargetFanRPMs[2]);
	}

	// save preferences, if required
	if (mustSavePrefs) {
		[self storePreferences];
		mustSavePrefs = NO;
	}

	if (MFdDebug) NSLog(@"--- FanControlDaemon 'timer' completed\n");
}

//==============================================================================
// getters and setters

// -----------------------------------------------------------------------------
- (float)lowerTempThreshold
{
	if (MFdDebug) NSLog(@"--- FanControlDaemon 'lowerTempThreshold' run\n");

	return lowerTempThreshold;
}

- (void)setLowerTempThreshold:(float)newLowerTempThreshold
{
	if (MFdDebug) NSLog(@"--- FanControlDaemon 'setLowerTempThreshold' run\n");

	lowerTempThreshold = newLowerTempThreshold;
	mustSavePrefs = YES;
}

// -----------------------------------------------------------------------------
- (float)upperTempThreshold
{
	if (MFdDebug) NSLog(@"--- FanControlDaemon 'upperTempThreshold' run\n");

	return upperTempThreshold;
}

- (void)setUpperTempThreshold:(float)newUpperTempThreshold
{
	if (MFdDebug) NSLog(@"--- FanControlDaemon 'setUpperTempThreshold' run\n");

	upperTempThreshold = newUpperTempThreshold;
	mustSavePrefs = YES;
}

// -----------------------------------------------------------------------------
- (float) cpuTemp
{
	if (MFdDebug) NSLog(@"--- FanControlDaemon 'cpuTemp' run\n");

	return cpuTemp;
}

// -----------------------------------------------------------------------------
- (float) gpuTemp
{
	if (MFdDebug) NSLog(@"--- FanControlDaemon 'gpuTemp' run\n");

	return gpuTemp;
}

// -----------------------------------------------------------------------------
- (BOOL)showTempsAsFahrenheit
{
	if (MFdDebug) NSLog(@"--- FanControlDaemon 'showTempsAsFahrenheit' run\n");

	return showTempsAsFahrenheit;
}

- (void)setShowTempsAsFahrenheit:(BOOL)newShowTempsAsFahrenheit
{
	if (MFdDebug) {
		NSLog(@"--- FanControlDaemon 'setShowTempsAsFahrenheit' run\n");
	}

	showTempsAsFahrenheit = newShowTempsAsFahrenheit;
	mustSavePrefs = YES;
}

// -----------------------------------------------------------------------------
- (int)numFans
{
	if (MFdDebug) NSLog(@"--- FanControlDaemon 'numFans' run\n");

	return numFans;
}

// -----------------------------------------------------------------------------
- (fanNames)systemFanNames
{
	if (MFdDebug) NSLog(@"--- FanControlDaemon 'systemFanNames' run\n");

	int				i;
	io_connect_t	conn;

	smcOpen(&conn);

	if (numFans == 1) {
		smcGetFanID(SMC_KEY_FAN1_ID, systemFanNames.fanName[0], conn);
		strcpy(systemFanNames.fanName[1], "");
		strcpy(systemFanNames.fanName[2], "");
	}

	if (numFans == 2) {
		smcGetFanID(SMC_KEY_FAN1_ID, systemFanNames.fanName[0], conn);
		smcGetFanID(SMC_KEY_FAN2_ID, systemFanNames.fanName[1], conn);
		strcpy(systemFanNames.fanName[2], "");
	}

	// for 3 fans, we reverse the order in which we fill the arrays so the order
	// of presentation in the UI is "better"
	if (numFans == 3) {
		smcGetFanID(SMC_KEY_FAN3_ID, systemFanNames.fanName[0], conn);
		smcGetFanID(SMC_KEY_FAN2_ID, systemFanNames.fanName[1], conn);
		smcGetFanID(SMC_KEY_FAN1_ID, systemFanNames.fanName[2], conn);
	}

	smcClose(conn);

	// re-map the fan names -- this is a simple mapping based upon experience
	// with only a small number of systems (also removes trailing spaces)
	if (numFans > 1) {
		for (i = 0; i < numFans; i++)
		{
			if (strstr(systemFanNames.fanName[i], "Main") != NULL) {
				strcpy(systemFanNames.fanName[i], "Main");
			} else if (strstr(systemFanNames.fanName[i], "CPU") != NULL) {
				strcpy(systemFanNames.fanName[i], "CPU");
			} else if (strstr(systemFanNames.fanName[i], "Exhaust") != NULL) {
				strcpy(systemFanNames.fanName[i], "Main");
			} else if (strstr(systemFanNames.fanName[i], "HDD") != NULL) {
				strcpy(systemFanNames.fanName[i], "HD");
			} else if (strstr(systemFanNames.fanName[i], "Left") != NULL) {
				strcpy(systemFanNames.fanName[i], "Left");
			} else if (strstr(systemFanNames.fanName[i], "ODD") != NULL) {
				strcpy(systemFanNames.fanName[i], "DVD");
			} else if (strstr(systemFanNames.fanName[i], "Right") != NULL) {
				strcpy(systemFanNames.fanName[i], "Right");
			} else sprintf(systemFanNames.fanName[i], "#%d", i);  // convert to a #
		}
	} else strcpy(systemFanNames.fanName[0], "Main");

	return systemFanNames;
}

// -----------------------------------------------------------------------------
- (fanSpeeds)targetFanSpeeds
{
	if (MFdDebug) NSLog(@"--- FanControlDaemon 'targetFanSpeeds' run\n");

	targetFanSpeeds.fanRPMs[0] = targetFanRPMs[0];
	targetFanSpeeds.fanRPMs[1] = targetFanRPMs[1];
	targetFanSpeeds.fanRPMs[2] = targetFanRPMs[2];
	return targetFanSpeeds;
}

// -----------------------------------------------------------------------------
- (fanSpeeds)currentFanSpeeds
{
	if (MFdDebug) NSLog(@"--- FanControlDaemon 'currentFanSpeeds' run\n");

	currentFanSpeeds.fanRPMs[0] = currFanRPMs[0];
	currentFanSpeeds.fanRPMs[1] = currFanRPMs[1];
	currentFanSpeeds.fanRPMs[2] = currFanRPMs[2];
	return currentFanSpeeds;
}

// -----------------------------------------------------------------------------
- (fanSpeeds)minFanSpeeds
{
	if (MFdDebug) NSLog(@"--- FanControlDaemon 'minFanSpeeds' run\n");

	minFanSpeeds.fanRPMs[0] = minFanRPMs[0];
	minFanSpeeds.fanRPMs[1] = minFanRPMs[1];
	minFanSpeeds.fanRPMs[2] = minFanRPMs[2];
	return minFanSpeeds;
}

- (void)setMinFanSpeeds:(fanSpeeds)newMinFanSpeeds
{
	if (MFdDebug) NSLog(@"--- FanControlDaemon 'setMinFanSpeeds' run\n");

	minFanRPMs[0] = newMinFanSpeeds.fanRPMs[0];

	if (numFans > 1) minFanRPMs[1] = newMinFanSpeeds.fanRPMs[1];
	if (numFans > 2) minFanRPMs[2] = newMinFanSpeeds.fanRPMs[2];

	mustSavePrefs = YES;
}

// -----------------------------------------------------------------------------
- (fanSpeeds)maxFanSpeeds
{
	if (MFdDebug) NSLog(@"--- FanControlDaemon 'maxFanSpeeds' run\n");

	maxFanSpeeds.fanRPMs[0] = maxFanRPMs[0];
	maxFanSpeeds.fanRPMs[1] = maxFanRPMs[1];
	maxFanSpeeds.fanRPMs[2] = maxFanRPMs[2];
	return maxFanSpeeds;
}

//==============================================================================
// internal utility functions

// -----------------------------------------------------------------------------
- (void)getCurrFanRPMs:(io_connect_t)conn
{
	if (MFdDebug) NSLog(@"--- FanControlDaemon 'getCurrFanRPMs' run\n");

	// NOTE: for 3 fans, we reverse the order in which we fill the arrays so
	// that the UI items are in a better "top down" order
	if (numFans == 3) {
		currFanRPMs[2] = smcGetFanRPM(SMC_KEY_FAN1_RPM, conn);  // -1 = failure
		currFanRPMs[1] = smcGetFanRPM(SMC_KEY_FAN2_RPM, conn);  // -1 = failure
		currFanRPMs[0] = smcGetFanRPM(SMC_KEY_FAN3_RPM, conn);  // -1 = failure
	} else if (numFans == 2) {
		currFanRPMs[0] = smcGetFanRPM(SMC_KEY_FAN1_RPM, conn);  // -1 = failure
		currFanRPMs[1] = smcGetFanRPM(SMC_KEY_FAN2_RPM, conn);  // -1 = failure
	} else currFanRPMs[0] = smcGetFanRPM(SMC_KEY_FAN1_RPM, conn); // -1 = failure
}

// -----------------------------------------------------------------------------
- (void)getSMCminFanRPMs:(io_connect_t)conn
{
	if (MFdDebug) NSLog(@"--- FanControlDaemon 'getSMCminFanRPMs' run\n");

	// NOTE: for 3 fans, we reverse the order in which we fill the arrays so
	// that the UI items are in a better "top down" order
	if (numFans == 3) {
		smcMinFanRPMs[2] = smcGetFanRPM(SMC_KEY_FAN1_RPM_MIN, conn); // -1=fail
		smcMinFanRPMs[1] = smcGetFanRPM(SMC_KEY_FAN2_RPM_MIN, conn); // -1=fail
		smcMinFanRPMs[0] = smcGetFanRPM(SMC_KEY_FAN3_RPM_MIN, conn); // -1=fail
	} else if (numFans == 2) {
		smcMinFanRPMs[0] = smcGetFanRPM(SMC_KEY_FAN1_RPM_MIN, conn); // -1=fail
		smcMinFanRPMs[1] = smcGetFanRPM(SMC_KEY_FAN2_RPM_MIN, conn); // -1=fail
	} else smcMinFanRPMs[0] = smcGetFanRPM(SMC_KEY_FAN1_RPM_MIN, conn); //-1=fail
}

// -----------------------------------------------------------------------------
- (void)getSMCmaxFanRPMs:(io_connect_t)conn
{
	if (MFdDebug) NSLog(@"--- FanControlDaemon 'getSMCmaxFanRPMs' run\n");

	// NOTE: for 3 fans, we reverse the order in which we fill the arrays so
	// that the UI items are in a better "top down" order
	if (numFans == 3) {
		smcMaxFanRPMs[2] = smcGetFanRPM(SMC_KEY_FAN1_RPM_MAX, conn); // -1=fail
		smcMaxFanRPMs[1] = smcGetFanRPM(SMC_KEY_FAN2_RPM_MAX, conn); // -1=fail
		smcMaxFanRPMs[0] = smcGetFanRPM(SMC_KEY_FAN3_RPM_MAX, conn); // -1=fail
	} else if (numFans == 2) {
		smcMaxFanRPMs[0] = smcGetFanRPM(SMC_KEY_FAN1_RPM_MAX, conn); // -1=fail
		smcMaxFanRPMs[1] = smcGetFanRPM(SMC_KEY_FAN2_RPM_MAX, conn); // -1=fail
	} else smcMaxFanRPMs[0] = smcGetFanRPM(SMC_KEY_FAN1_RPM_MAX, conn); //-1=fail
}

// -----------------------------------------------------------------------------
- (void)setMinFanRPMs:(io_connect_t)conn
{
	if (MFdDebug) NSLog(@"--- FanControlDaemon 'setMinFanRPMs' run\n");

	// NOTE: for 3 fans, we reverse the order in which we fill the arrays so
	// that the UI items are in a better "top down" order
	if (numFans == 3) {
		smcSetMinFanRPM(SMC_KEY_FAN1_RPM_MIN, targetFanRPMs[2], conn);
		smcSetMinFanRPM(SMC_KEY_FAN2_RPM_MIN, targetFanRPMs[1], conn);
		smcSetMinFanRPM(SMC_KEY_FAN3_RPM_MIN, targetFanRPMs[0], conn);
	} else if (numFans == 2) {
		smcSetMinFanRPM(SMC_KEY_FAN1_RPM_MIN, targetFanRPMs[0], conn);
		smcSetMinFanRPM(SMC_KEY_FAN2_RPM_MIN, targetFanRPMs[1], conn);
	} else smcSetMinFanRPM(SMC_KEY_FAN1_RPM_MIN, targetFanRPMs[0], conn);
}

// -----------------------------------------------------------------------------
// returns the highest temperature using the CPU temperature keys from those
// having the highest 2 priority categories
- (float)getHighestCPUtemperature:(io_connect_t) conn
{
	if (MFdDebug) {
		NSLog(@"--- FanControlDaemon 'getHighestCPUtemperature' started\n");
	}

	int		i;
	int		numPriorities = 0;
	int		prevPriority = 0;
	int		currPriority;
	float		currTemperature = -100.0;
	float		highTemperature = -100.0;

	for (i = 0; i < cpuTemperatureKeysCount; i++) {
		currPriority = theCPUtemperatureKeys[i].priority;

		if (MFdDebug) {
			NSLog(@"numPriorities = %d\n", numPriorities);
			NSLog(@"prevPriority = %d\n", prevPriority);
			NSLog(@"highTemperature = %.3f\n", highTemperature);
			NSLog(@"temperature key = %s\n", theCPUtemperatureKeys[i].key);
			NSLog(@"currPriority = %d\n", currPriority);
		}

		if (currPriority == 0) continue;

		// determine whether this is a new priority category
		if (currPriority != prevPriority) {
			numPriorities++;
			prevPriority = currPriority;
		}

		if (MFdDebug) NSLog(@"numPriorities = %d\n", numPriorities);

		if (numPriorities > 2) break;  // only use temps in the top 2 priorities

		currTemperature = smcGetTemperature(theCPUtemperatureKeys[i].key, conn);

		if (MFdDebug) NSLog(@"currTemperature = %.3f\n", currTemperature);

		if (currTemperature < 0.0) continue;

		if (currTemperature > highTemperature) highTemperature = currTemperature;

		if (MFdDebug) NSLog(@"highTemperature = %.3f\n", highTemperature);
	}

	if (MFdDebug) {
		NSLog(@"final highTemperature = %.3f\n", highTemperature);
		NSLog(@"--- FanControlDaemon 'getHighestCPUtemperature' completed\n");
	}

	return highTemperature;
}

// -----------------------------------------------------------------------------
// returns the highest temperature using the GPU temperature keys from those
// having the highest 2 priority categories
- (float)getHighestGPUtemperature:(io_connect_t) conn
{
	if (MFdDebug) {
		NSLog(@"--- FanControlDaemon 'getHighestGPUtemperature' started\n");
	}

	int		i;
	int		numPriorities = 0;
	int		prevPriority = 0;
	int		currPriority;
	float		currTemperature = -100.0;
	float		highTemperature = -100.0;

	for (i = 0; i < gpuTemperatureKeysCount; i++) {
		currPriority = theGPUtemperatureKeys[i].priority;

		if (MFdDebug) {
			NSLog(@"numPriorities = %d\n", numPriorities);
			NSLog(@"prevPriority = %d\n", prevPriority);
			NSLog(@"highTemperature = %.3f\n", highTemperature);
			NSLog(@"temperature key = %s\n", theGPUtemperatureKeys[i].key);
			NSLog(@"currPriority = %d\n", currPriority);
		}

		if (currPriority == 0) continue;

		// determine whether this is a new priority category
		if (currPriority != prevPriority) {
			numPriorities++;
			prevPriority = currPriority;
		}

		if (MFdDebug) NSLog(@"numPriorities = %d\n", numPriorities);

		if (numPriorities > 2) break;  // only use temps in the top 2 priorities

		currTemperature = smcGetTemperature(theGPUtemperatureKeys[i].key, conn);

		if (MFdDebug) NSLog(@"currTemperature = %.3f\n", currTemperature);

		if (currTemperature < 0.0) continue;

		if (currTemperature > highTemperature) highTemperature = currTemperature;

		if (MFdDebug) NSLog(@"highTemperature = %.3f\n", highTemperature);
	}

	if (MFdDebug) {
		NSLog(@"highTemperature = %.3f\n", highTemperature);
		NSLog(@"--- FanControlDaemon 'getHighestGPUtemperature' completed\n");
	}

	return highTemperature;
}

@end
